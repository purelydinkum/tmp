﻿using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Configuration;
using System.Xml.XPath; 
/// <summary>
/// CommonInfo 的摘要描述
/// </summary>
public class CommonInfo
{

    //public static decimal BaseAvgAssetsOne { get { return SessionPag; } }
    //public static decimal BaseAvgAssetsSecond { get { return 90; } }

    //public static decimal BaseTradeAmountOne = 0;
    //public static decimal BaseTradeAmountSecond = 0;

    public static decimal BaseDaysOne { get { return 90; } }
    public static decimal BaseDaysSecond { get { return 365; } }
    //public static string sccm_dblinkstr { get { return @"[VICKY-TCB-VM\SQLEXPRESS].SCCM_DB.dbo."; } }
    
    //正式機字串
    public static string sccm_dblinkstr { get { return @"SCCM.CM_CHB.dbo."; } }
    //public static string sccm_dblinkstr = @"[VICKY-TCB-VM\SQLEXPRESS].CM_HQS.dbo.";
    
    public CommonInfo()
    {

    }


    /// <summary>
    /// 傳回程式權限資料
    /// </summary>
    /// <returns></returns>
    public static DataView GetRoleFunction(string roleId)
    {
        const string strSql = @"SELECT A.ProgramId 
                                                ,ISNULL(FUN01,'')+','+ISNULL(FunId01,'') AS FUN01_ID 
                                                ,ISNULL(FUN02,'')+','+ISNULL(FunId02,'') AS FUN02_ID 
                                                ,ISNULL(FUN03,'')+','+ISNULL(FunId03,'') AS FUN03_ID 
                                                ,ISNULL(FUN04,'')+','+ISNULL(FunId04,'') AS FUN04_ID 
                                                ,ISNULL(FUN05,'')+','+ISNULL(FunId05,'') AS FUN05_ID 
                                                ,ISNULL(FUN06,'')+','+ISNULL(FunId06,'') AS FUN06_ID 
                                                ,ISNULL(FUN07,'')+','+ISNULL(FunId07,'') AS FUN07_ID 
                                                ,ISNULL(FUN08,'')+','+ISNULL(FunId08,'') AS FUN08_ID 
                                                ,ISNULL(FUN09,'')+','+ISNULL(FunId09,'') AS FUN09_ID 
                                                ,ISNULL(FUN10,'')+','+ISNULL(FunId10,'') AS FUN10_ID 
                                                ,ISNULL(FUN11,'')+','+ISNULL(FunId11,'') AS FUN11_ID 
                                                ,ISNULL(FUN12,'')+','+ISNULL(FunId12,'') AS FUN12_ID 
                                                ,ISNULL(FUN13,'')+','+ISNULL(FunId13,'') AS FUN13_ID 
                                                ,ISNULL(FUN14,'')+','+ISNULL(FunId14,'') AS FUN14_ID 
                                                ,ISNULL(FUN15,'')+','+ISNULL(FunId15,'') AS FUN15_ID 
                                                ,ISNULL(FUN16,'')+','+ISNULL(FunId16,'') AS FUN16_ID 
                                                ,ISNULL(FUN17,'')+','+ISNULL(FunId17,'') AS FUN17_ID 
                                                ,ISNULL(FUN18,'')+','+ISNULL(FunId18,'') AS FUN18_ID 
                                                ,ISNULL(FUN19,'')+','+ISNULL(FunId19,'') AS FUN19_ID 
                                                ,ISNULL(FUN20,'')+','+ISNULL(FunId20,'') AS FUN20_ID 
                                    FROM ProgramRole A,Program B
                                                WHERE A.ProgramId=B.ProgramId
                                                AND A.RoleId=@RoleId ";

        //var da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
        var da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
        var objParams = new ParameterCollection { { "RoleId", DbType.String, roleId } };

        return da.ExecuteDataTable(strSql, objParams).DefaultView;
    }

    

    public static DataTable GetFirstMenu()
    {
        const string sql = @"SELECT MenuId,MenuDesc
                                FROM Menu 
                                WHERE MenuLevel='1' ";
        var da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
        var dtb = da.ExecuteDataTable(sql);
        return dtb;
    }
    public static DataTable GetSecondMenu(string menuId)
    {
        const string sql = @"SELECT MenuId,MenuDesc
                                FROM Menu 
                                WHERE MenuLevel='2' AND MenuParent=@MENU_PARENT ";
        var da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
        var objParams = new ParameterCollection();
        objParams.Add("MENU_PARENT", DbType.String, menuId);
        var dtb = da.ExecuteDataTable(sql, objParams);
        return dtb;
    }
    public static DataTable GetThirdMenu(string menuId)
    {
        const string sql = @"SELECT MenuId,MenuDesc
                                FROM Menu 
                                WHERE MenuLevel='3' AND MenuParent=@MENU_PARENT ";
        var da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
        var objParams = new ParameterCollection { { "MENU_PARENT", DbType.String, menuId } };
        var dtb = da.ExecuteDataTable(sql, objParams);
        return dtb;
    }

    public static DataTable GetSystemCode(string Class)
    {
        const string sql = @"SELECT ClassType,ClassDescription FROM SystemCodes_Config WHERE Class=@Class Order by Seq";
        var da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
        var objParams = new ParameterCollection { { "Class", DbType.String, Class } };
        var dtb = da.ExecuteDataTable(sql, objParams);
        return dtb;
    }

    
    public static DataTable GetHour()
    {
        DataTable dtb = new DataTable();
        dtb.Columns.Add("Text");
        dtb.Columns.Add("Value");

        for (int i = 0; i < 24; i++)
        {
            dtb.Rows.Add(new object[] { i.ToString().PadLeft(2, '0'), i.ToString().PadLeft(2, '0') });
        }

        return dtb;
    }

    
    /// <summary>
    /// 取得所有角色
    /// </summary>
    /// <returns></returns>
    public static DataTable GetAllRole()
    {
        const string sql = @"SELECT RoleId,RoleName
	                            FROM Roles ";
        var da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
        var dtb = da.ExecuteDataTable(sql);
        return dtb;
    }
    /// <summary>
    /// 取得角色(不包括簽核人員)
    /// </summary>
    /// <returns></returns>
    public static DataTable GetRoleNotCheck()
    {
        const string sql = @"SELECT RoleId,RoleName
	                            FROM Roles WHERE IsCheck!='Y'";
        var da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
        var dtb = da.ExecuteDataTable(sql);
        return dtb;
    }
    /// <summary>
    /// 取得角色(只有簽核人員)
    /// </summary>
    /// <returns></returns>
    public static DataTable GetRoleOnlyCheck()
    {
        const string sql = @"SELECT RoleId,RoleName+'('+RoleId+')' RoleName
	                            FROM Roles WHERE IsCheck='Y' Order by RoleId desc";
        var da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
        var dtb = da.ExecuteDataTable(sql);
        return dtb;
    }

    
    /// <summary>
    /// 取得所有系統代碼類別
    /// </summary>
    /// <returns></returns>
    public static DataTable GetAllSystemClass_Config()
    {
        const string sql = @"SELECT 
                                Class,
                                Class+'-'+ClassDescript ClassDescript         
                                FROM SystemClass_Config";
        var da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
        var dtb = da.ExecuteDataTable(sql);
        return dtb;
    }


    /// <summary>
    /// 取得所有部門
    /// </summary>
    /// <returns></returns>
    public static DataTable GetAllSubDepartment()
    {
        const string sql = @"SELECT SubDepartment,SubDepartment+'-'+SubDepartmentDescription 
                             FROM SubDepartments 
                             ORDER BY SubDepartment";
        var da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
        var dtb = da.ExecuteDataTable(sql);
        return dtb;
    }

    public static bool GCB_isAbnormal(string val, string std_val, string Policy)
    {
        bool isAbnormal = false;
        string comparetype = "default";
        int v;
        switch (Policy)
        {
            case "AIX_MinWeeks":
            case "Linux_MinDays":
            case "Solaris_MinWeeks":
            case "SUSE_MinDays":
            case "Linux_MaxHistories":
            case "Solaris_MaxHistories":
            case "AIX_MaxHistories":
            case "SUSE_MaxHistories":
            case "Linux_MinLength":
            case "Solaris_MinLength":
            case "AIX_MinLength":
            case "SUSE_MinLength":
            case "Solaris_min_diff":
            case "Solaris_min_alpha":
            case "Solaris_min_digit":
            case "Solaris_min_upper":
            case "Solaris_min_lower":
            case "AIX_histexpire":
            case "AIX_minother":
            case "AIX_minalpha":
            case "AIX_mindiff":
            case "AIX_logininterval":
            case "AIX_loginreenable":
            case "AIX_logindelay":
            case "AIX_mindigit":
            case "AIX_minupperalpha":
            case "AIX_minloweralpha":
            case "Linux_difok":
            case "Linux_fail_interval":
            case "Linux_unlock_time":
            case "Linux_delay":
            case "SUSE_difok":
            case "SUSE_fail_interval":
            case "SUSE_unlock_time":
            case "SUSE_delay":
            case "Solaris_min_nonalpha":
            case "Solaris_disabletime":
            case "Solaris_sleeptime":
                //若沒設設定值則無異常;
                //若盤點值為空白則異常;
                //若盤出來的數字有多個則異常;
                //0則異常
                //若盤點值小於設定值則異常
                //越大越好擺這
                comparetype = "gt";
                if (string.IsNullOrEmpty(std_val))
                    isAbnormal = false;
                else if (string.IsNullOrEmpty(val))
                    isAbnormal = true;
                else if (val.Split(' ').Count() > 1)
                    isAbnormal = true;
                else if (!int.TryParse(val, out v) || !int.TryParse(std_val, out v))
                    isAbnormal = true;
                else if (int.Parse(val) == 0)
                    isAbnormal = true;
                else
                    isAbnormal = int.Parse(val) < int.Parse(std_val);
                break;
            case "AIX_MaxWeeks":
            case "Linux_MaxDays":
            case "SUSE_MaxDays":
            case "Solaris_MaxWeeks":
            case "Linux_retries":
            case "Solaris_retries":
            case "AIX_retries":
            case "SUSE_retries":
            case "Linux_dcredit":
            case "Linux_ucredit":
            case "Linux_lcredit":
            case "AIX_logindisable":
            case "AIX_logintimeout":
            case "AIX_tmout":
            case "Linux_deny":
            case "Linux_ServerAliveInterval":
            case "Linux_tmout":
            case "SUSE_dcredit":
            case "SUSE_ucredit":
            case "SUSE_lcredit":
            case "SUSE_deny":
            case "SUSE_LOGIN_TIMEOUT":
            case "SUSE_tmout":
            case "Solaris_logingracetime":
            case "Solaris_clientaliveinterval":
                //若沒設設定值則無異常;
                //若盤點值為空白則異常;
                //若盤出來的數字有多個則異常;
                //0則異常
                //若盤點值大於設定值則異常
                //越小越好擺這
                comparetype = "lt";
                if (string.IsNullOrEmpty(std_val))
                    isAbnormal = false;
                else if (string.IsNullOrEmpty(val))
                    isAbnormal = true;
                else if (val.Split(' ').Count() > 1)
                    isAbnormal = true;
                else if (!int.TryParse(val, out v) || !int.TryParse(std_val, out v))
                    isAbnormal = true;
                else if (int.Parse(val) == 0)
                    isAbnormal = true;
                else
                    isAbnormal = int.Parse(val) > int.Parse(std_val);
                break;
            case "SUSE_dictpath":
            case "Linux_dictpath":
                comparetype = "Empty";
                //若沒設設定值則無異常;
                //若盤點有值則異常:
                if (string.IsNullOrEmpty(std_val))
                {
                    isAbnormal = false;
                    break;
                }
                if (!string.IsNullOrEmpty(val))
                {
                    isAbnormal = true;
                    break;
                }
                break;
            case "AIX_binmode":
                comparetype = "binmode";
                if (string.IsNullOrEmpty(std_val))
                {
                    isAbnormal = false;
                    break;
                }
                if (string.IsNullOrEmpty(val))
                {
                    isAbnormal = true;
                    break;
                }
                if (val.Split(',').Count() != 2)
                {
                    isAbnormal = true;
                    break;
                }
                foreach (var item in std_val.Split(';'))
                {
                    if (item.Trim().Equals(val.Trim().Replace(" ", "")))
                    {
                        isAbnormal = false;
                        break;
                    }
                }
                break;
            case "AIX_guest":
                comparetype = "guest";
                isAbnormal = true;
                if (string.IsNullOrEmpty(std_val))
                {
                    isAbnormal = false;
                    break;
                }
                if (string.IsNullOrEmpty(val))
                {
                    isAbnormal = true;
                    break;
                }
                string[] guestR = val.Split(',');
                if (guestR.Count() != 3)
                {
                    isAbnormal = true;
                    break;
                }
                if (guestR[0].Trim() == "true")
                {
                    isAbnormal = false;
                    break;
                }
                else if (guestR[1].Trim() != "false" || guestR[2].Trim() != "false")
                {
                    isAbnormal = true;
                    break;
                }
                break;
            case "AIX_superuser":
            case "Linux_superuser":
            case "SUSE_superuser":
            case "Solaris_superuser":
                comparetype = "usereq";
                isAbnormal = true;
                if (string.IsNullOrEmpty(std_val))
                {
                    isAbnormal = false;
                    break;
                }
                if (string.IsNullOrEmpty(val))
                {
                    isAbnormal = true;
                    break;
                }
                List<string> superuser = val.Split(',').ToList();
                superuser.Sort();
                string[] std_val_Arr = std_val.Split(';');

                isAbnormal = true;
                foreach (var item in std_val_Arr)
                {
                    List<string> std_superuser = item.Split(',').ToList();
                    std_superuser.Sort();
                    if (std_superuser.SequenceEqual(superuser))
                    {
                        isAbnormal = false;
                        break;
                    }
                }

                break;
            case "AIX_pwd_algo_info":
            case "Linux_pwd_algo_info":
            case "SUSE_pwd_algo_info":
            case "Solaris_pwd_algo_info":
                //設定值以分號隔開，有一項符合及無異常
                comparetype = "or";
                if (string.IsNullOrEmpty(std_val))
                    isAbnormal = false;
                else if (string.IsNullOrEmpty(val))
                    isAbnormal = true;
                else
                    isAbnormal = true;
                    foreach (var item in std_val.Split(';'))
                    {
                        if (item.Trim().Equals(val.Trim()))
                        {
                            isAbnormal = false;
                            break;
                        }
                    }
                break;
            default:
                //若沒設設定值則無異常;
                //若比對不相符則異常
                comparetype = "eq";
                if (string.IsNullOrEmpty(std_val))
                    isAbnormal = false;
                else
                    isAbnormal = !(val.Trim().Equals(std_val.Trim()));
                break;
        }
        return isAbnormal;
    }

    #region 選單


    /// <summary>
    /// 回傳選單資料
    /// </summary>
    /// <returns></returns>
    public static DataTable GetMenuData(UserInfo userInfo)
    {
        if (userInfo == null)
            return null;
        string strSql = @"SELECT MenuLevel,MenuParent,MenuId,ProgramId,MenuDesc,'' AS RoleId,'' AS ProgramPath,Seq
	                                FROM Menu WHERE VersionNo=@APPID and ProgramId=''
                                UNION ALL                
                                SELECT A.MenuLevel,A.MenuParent,A.MenuId,A.ProgramId,B.ProgramTChineseName,C.RoleId,B.ProgramPath,A.SEQ
	                                FROM MENU A
	                                LEFT JOIN PROGRAM B
		                                ON A.ProgramId=B.ProgramId
		                                AND B.STATUS='A'
	                                INNER JOIN ProgramRole C
		                                ON B.ProgramId=C.ProgramId
		                                AND C.RoleId=@RoleId
	                                WHERE VersionNo=@APPID
                                ORDER BY MenuLevel,SEQ";

        //var da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
        var da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);

        var objParams = new ParameterCollection();
        objParams.Add("APPID", DbType.String, userInfo.AppLibName);
        objParams.Add("RoleId", DbType.String, userInfo.RoleId);
        return da.ExecuteDataTable(strSql, objParams);
    }

    /// <summary>
    /// 建立TreeView XML
    /// </summary>
    public static XmlDocument CreateSiteMapTree(DataTable dtMenu)
    {
        var drRoot = dtMenu.Select("MenuLevel='0'");

        var xmlDoc = new XmlDocument();

        foreach (var rowItem in drRoot)
        {
            var key = rowItem["MenuId"].ToString();
            var title = rowItem["MenuDesc"].ToString();
            if (!string.IsNullOrEmpty(Resources.Language.ResourceManager.GetString("MENU_" + key)))
                title = Resources.Language.ResourceManager.GetString("MENU_" + key);
            var xmlRoot = xmlDoc.CreateElement(key);
            var attSelect = xmlDoc.CreateAttribute("title");
            attSelect.Value = title;
            xmlRoot.SetAttributeNode(attSelect);
            AddNode(xmlDoc, xmlRoot, dtMenu);
            xmlDoc.AppendChild(xmlRoot);
        }

        return xmlDoc;
    }

    /// <summary>
    /// 新增xml Node
    /// </summary>
    /// <param name="xmlDoc"></param>
    /// <param name="parentNode"></param>
    /// <param name="dtMenu"></param>
    private static void AddNode(XmlDocument xmlDoc, XmlNode parentNode, DataTable dtMenu)
    {
        var menuParent = parentNode.Name;
        var drItems = dtMenu.Select("MenuParent='" + menuParent + "'");

        foreach (var rowItem in drItems)
        {
            var key = (!string.IsNullOrEmpty(rowItem["MenuId"].ToString()) ? rowItem["MenuId"].ToString() : rowItem["ProgramId"].ToString());
            var title = rowItem["MenuDesc"].ToString();
            string url = null;

            if (!string.IsNullOrEmpty(Resources.Language.ResourceManager.GetString("MENU_" + key)))
                title = Resources.Language.ResourceManager.GetString("MENU_" + key);
            if (!string.IsNullOrEmpty(rowItem["ProgramPath"].ToString()))
                url = rowItem["ProgramPath"].ToString();

            var nodeName = key;

            var childNode = xmlDoc.CreateElement(nodeName);
            var attSelect = xmlDoc.CreateAttribute("title");
            attSelect.Value = title;
            childNode.SetAttributeNode(attSelect);
            attSelect = xmlDoc.CreateAttribute("url");
            attSelect.Value = url;
            childNode.SetAttributeNode(attSelect);

            AddNode(xmlDoc, childNode, dtMenu);
            if (!string.IsNullOrEmpty(rowItem["ProgramId"].ToString()))
                parentNode.AppendChild(childNode);
            else if (childNode.ChildNodes.Count > 0)
                parentNode.AppendChild(childNode);
        }
    }

    #endregion
    private string _formTitle = string.Empty;
    //public string GetFormTitle(string progrmaId)
    //{
    //    string sql = @"SELECT 
	   //                     A.MenuLevel,A.MenuParent,A.MenuId,A.ProgramId,MenuDesc,B.ProgramPath,A.Seq
    //                    FROM MENU A
    //                    LEFT JOIN PROGRAM B ON A.ProgramId=B.ProgramId                                          
    //                    ORDER BY MenuLevel,SEQ";
    //    var da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
    //    DataTable dt = da.ExecuteDataTable(sql);
    //    XmlDocument xmlMenu = CommonInfo.CreateSiteMapTree(dt);
    //    XmlNode currentMapNode = xmlMenu.SelectSingleNode("//" + progrmaId);

    //    if (currentMapNode != null)
    //    {
    //        return SetPathTitle(currentMapNode);
    //    }
    //    else
    //    {
    //        return "";
    //    }
    //}

    private string SetPathTitle(XmlNode currentMapNode)
    {

        if (currentMapNode.NodeType == XmlNodeType.Element)
        {
            if (currentMapNode.ParentNode != null && currentMapNode.ParentNode.NodeType == XmlNodeType.Element)
            {
                SetPathTitle(currentMapNode.ParentNode);
                _formTitle += " > ";
            }
            var title = currentMapNode.Attributes["title"].Value;
            _formTitle += title;
        }

        return _formTitle;
    }
}
