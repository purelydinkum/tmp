call_sh=`ps -p $$ -ocomm=`
test_bash=`echo ${call_sh} | grep bash`
test_ksh=`echo ${call_sh} | grep ksh`
if [ -z "${test_bash}" ] && [ -z "${test_ksh}" ]; then
  if [ -f "/bin/bash" ]; then
    exec bash "$0" "$@"
  fi
  if [ -f "/bin/ksh" ]; then
    exec ksh "$0" "$@"
  fi
fi

# Oracle Linux
os_ol_5="EnterpriseLinux_5"
os_ol_6="OracleLinux_6"
os_ol_7="OracleLinux_7"

# Solaris
os_solaris_11="Solaris_11"
os_solaris_10="Solaris_10"

# Red Hat Enterprise Linux
os_rhel_7="RedHat_7"
os_rhel_6="RedHat_6"

# SUSE Linux Enterprise Server 
os_suse_15="SUSE_15"
os_suse_12="SuSE_12"
os_suse_11="SUSE_11"

# CentOS
os_centos_7="CentOS_7"

# IBM AIX
os_aix_7_5="AIX_7_5"

os_ol=${os_ol_7}
os_solaris=${os_solaris_11}
os_rh=${os_rhel_7}
os_suse=${os_suse_15}
os_centos=${os_centos_7}
os_aix=${os_aix_7_5}

# release file
rel_ol=/etc/oracle-release
rel_osol=/etc/release
rel_rh=/etc/redhat-release
rel_suse=/etc/SuSE-release
rel_centos=/etc/centos-release
rel_common=/etc/os-release

awk_cmd="awk"
grep_cmd="grep"
os=""

gen_sys_info(){
  os_name=""
  os_info_file=""
  if [ -f "${rel_osol}" ]; then
    os_info_file="${rel_osol}"
    os_name=$(echo $(cat ${os_info_file} | head -n 1))
    if [ ! -z "$(echo ${os_name} | ${grep_cmd} ' 10')" ]; then
      os=${os_solaris_10}
      awk_cmd="nawk"
    else
      os=${os_solaris}
      awk_cmd="gawk"
    fi
    grep_cmd="/usr/xpg4/bin/grep"
  elif [ -f "${rel_ol}" ]; then
    os_info_file="${rel_ol}"
    os_name=$(echo $(cat ${os_info_file} | head -n 1))
    if [ ! -z "$(echo ${os_name} | ${grep_cmd} ' 6.')" ]; then
      os=${os_ol_6}
    elif [ ! -z "$(echo ${os_name} | ${grep_cmd} ' 7.')" ]; then
      os=${os_ol_7}
    else
      os=${os_ol}
    fi
  elif [ -f "${rel_rh}" ]; then
    os_info_file="${rel_rh}"
    os_name=$(echo $(cat ${os_info_file} | head -n 1))
    if [ ! -z "$(echo ${os_name} | ${grep_cmd} ' 6.')" ]; then
      os=${os_rhel_6}
    elif [ ! -z "$(echo ${os_name} | ${grep_cmd} ' 7.')" ]; then
      os=${os_rhel_7}
    else
      os=${os_rh}
    fi
  elif [ -f "${rel_suse}" ]; then
    os_info_file="${rel_suse}"
    os_name=$(echo $(cat ${os_info_file} | head -n 1))
    if [ ! -z "$(echo ${os_name} | ${grep_cmd} ' 11 ')" ]; then
      os=${os_suse_11}
    elif [ ! -z "$(echo ${os_name} | ${grep_cmd} ' 12 ')" ]; then
      os=${os_suse_12}
    else
      os=${os_suse}
    fi
  elif [ -f "${rel_centos}" ]; then
    os_info_file="${rel_centos}"
    os_name=$(echo $(cat ${os_info_file} | head -n 1))
    os=${os_centos}
  elif [ -f "${rel_common}" ]; then
    os_info_file="${rel_common}"
    os=""
  else
    os_info_file=""
    os=""
  fi
  if [ ! -z "${os_info_file}" ]; then
    if [ -z "${os_name}" ]; then
      os_name=$(cat ${os_info_file} | ${grep_cmd} PRETTY_NAME | ${awk_cmd} -F'"' '{print $2}')
      if [ ! -z "$(echo ${os_name} | ${grep_cmd} 'SUSE Linux Enterprise Server')" ]; then
        if [ ! -z "$(echo ${os_name} | ${grep_cmd} ' 11 ')" ]; then
          os=${os_suse_11}
        elif [ ! -z "$(echo ${os_name} | ${grep_cmd} ' 12 ')" ]; then
          os=${os_suse_12}
        else
          os=${os_suse}
        fi
      elif [ ! -z "$(echo ${os_name} | ${grep_cmd} 'Enterprise Linux Enterprise Linux Server')" ]; then
        if [ ! -z "$(echo ${os_name} | ${grep_cmd} ' 5.')" ]; then
          os=${os_ol_5}
        else
          os=${os_ol}
        fi
      elif [ ! -z "$(echo ${os_name} | ${grep_cmd} 'Oracle Linux')" ]; then
        if [ ! -z "$(echo ${os_name} | ${grep_cmd} ' 6.')" ]; then
          os=${os_ol_6}
        elif [ ! -z "$(echo ${os_name} | ${grep_cmd} ' 7.')" ]; then
          os=${os_ol_7}
        else
          os=${os_ol}
        fi
      elif [ ! -z "$(echo ${os_name} | ${grep_cmd} 'Red Hat Enterprise Linux')" ]; then
        if [ ! -z "$(echo ${os_name} | ${grep_cmd} ' 6.')" ]; then
          os=${os_rhel_6}
        elif [ ! -z "$(echo ${os_name} | ${grep_cmd} ' 7.')" ]; then
          os=${os_rhel_7}
        else
          os=${os_rh}
        fi
      elif [ ! -z "$(echo ${os_name} | ${grep_cmd} 'CentOS Linux')" ]; then
        os=${os_centos}
      else
        echo "[SYS] release info found, but disto is unrecognized."
        echo "[SYS] os_name: ${os_name}"
        exit 1
      fi
    fi
  else
    os_name=$(uname -s)
    if [ ! -z $(echo ${os_name} | ${grep_cmd} 'AIX') ]; then
      os_name=$(echo "${os_name} $(oslevel)")
      os=${os_aix}
    else
      printf "[SYS] release info not found."
      exit 1
    fi
  fi
}
#Linux
pam_sys_auth=/etc/pam.d/system-auth
pam_passwd_auth=/etc/pam.d/password-auth
pam_common_passwd=/etc/pam.d/common-password
pam_pwquality=/etc/security/pwquality.conf
sys_login_defs=/etc/login.defs
sys_profile=/etc/profile
sys_bashrc=/etc/bashrc
#Unix
sys_passwd=/etc/default/passwd
sys_login=/etc/default/login
#AIX
sec_user=/etc/security/user

hostname=`hostname`
gen_policies_info(){
  if [ "${os}" = "${os_aix}" ]; then
    max_histories=$(echo $(lssec -f /etc/security/user -s default -a histsize | ${awk_cmd} -F'=' '{print $2}'))
    max_days=$(echo $(lssec -f /etc/security/user -s default -a maxage | ${awk_cmd} -F'=' '{print $2}'))
    min_days=$(echo $(lssec -f /etc/security/user -s default -a minage | ${awk_cmd} -F'=' '{print $2}'))
    min_len=$(echo $(lssec -f /etc/security/user -s default -a minlen | ${awk_cmd} -F'=' '{print $2}'))
    warn_time=$(echo $(lssec -f /etc/security/user -s default -a pwdwarntime | ${awk_cmd} -F'=' '{print $2}'))
    retries=$(echo $(lssec -f /etc/security/user -s default -a loginretries | ${awk_cmd} -F'=' '{print $2}'))
    AIX_histexpire=$(echo $(lssec -f /etc/security/user -s default -a histexpire | ${awk_cmd} -F'=' '{print $2}'))
    AIX_minother=$(echo $(lssec -f /etc/security/user -s default -a minother | ${awk_cmd} -F'=' '{print $2}'))
    AIX_minalpha=$(echo $(lssec -f /etc/security/user -s default -a minalpha | ${awk_cmd} -F'=' '{print $2}'))
    AIX_mindiff=$(echo $(lssec -f /etc/security/user -s default -a mindiff | ${awk_cmd} -F'=' '{print $2}'))
    AIX_mindigit=$(echo $(lssec -f /etc/security/user -s default -a mindigit | ${awk_cmd} -F'=' '{print $2}'))
    AIX_minupperalpha=$(echo $(lssec -f /etc/security/user -s default -a minupperalpha | ${awk_cmd} -F'=' '{print $2}'))
    AIX_minloweralpha=$(echo $(lssec -f /etc/security/user -s default -a minloweralpha | ${awk_cmd} -F'=' '{print $2}'))
    AIX_dictionlist=$(echo $(lssec -f /etc/security/user -s default -a dictionlist | ${awk_cmd} -F'=' '{print $2}'))

    AIX_pwd_algo_info=$(echo $(cat /etc/security/login.cfg | ${grep_cmd} -v "^ *\*" | ${grep_cmd} pwd_algorithm | ${grep_cmd} = | ${awk_cmd} -F'=' '{print $2}'))
    AIX_logininterval=$(echo $(cat /etc/security/login.cfg | ${grep_cmd} -v "^ *\*" | ${grep_cmd} logininterval  | ${grep_cmd} = | ${awk_cmd} -F'=' '{print $2}'))
    AIX_loginreenable=$(echo $(cat /etc/security/login.cfg | ${grep_cmd} -v "^ *\*" | ${grep_cmd} loginreenable  | ${grep_cmd} = | ${awk_cmd} -F'=' '{print $2}'))
    AIX_logindisable=$(echo $(cat /etc/security/login.cfg | ${grep_cmd} -v "^ *\*" | ${grep_cmd} logindisable  | ${grep_cmd} = | ${awk_cmd} -F'=' '{print $2}'))
    AIX_logintimeout=$(echo $(cat /etc/security/login.cfg | ${grep_cmd} -v "^ *\*" | ${grep_cmd} logintimeout  | ${grep_cmd} = | ${awk_cmd} -F'=' '{print $2}'))
    AIX_logindelay=$(echo $(cat /etc/security/login.cfg | ${grep_cmd} -v "^ *\*" | ${grep_cmd} logindelay  | ${grep_cmd} = | ${awk_cmd} -F'=' '{print $2}'))
    AIX_tmout=$(echo $(cat /etc/profile | ${grep_cmd} -v "^ *#" | ${grep_cmd} TMOUT  | ${grep_cmd} = | ${awk_cmd} -F'[=;&]' '{print $2}' | ${awk_cmd} '{print $1}'))
    AIX_auditstart=$(echo $(cat /etc/inittab | ${grep_cmd} -v "^ *#" | ${grep_cmd} -v "^ *:" | ${grep_cmd} -e "audit:2:once:/home/SCOMUser/scom/audit.sh" -e "audit:2:once:/usr/sbin/audit start 1>&- 2>&-"))
    if [ -z "${AIX_auditstart}" ]; then
      AIX_auditstart=$(echo false)
    else
      AIX_auditstart=$(echo true)
    fi
    AIX_auditshutdown=$(echo $(cat /etc/rc.shutdown | ${grep_cmd} -v "^ *#" | ${grep_cmd} /usr/sbin/audit | ${awk_cmd} -F' ' '{print $2}'))
    AIX_ignorerhosts=$(echo $(cat /etc/ssh/sshd_config | ${grep_cmd} -v "^ *#" | ${grep_cmd} IgnoreRhosts | ${awk_cmd} -F' ' '{print $2}'))
    AIX_binmode=$(echo $(cat /etc/security/audit/config | ${grep_cmd} binmode | ${awk_cmd} -F'=' '{print $2}'),$(cat /etc/security/audit/config | ${grep_cmd} streammode | ${awk_cmd} -F'=' '{print $2}'))
    guest_user=$(cat /etc/passwd | ${grep_cmd} -v "^ *#" | ${awk_cmd} -F':' '{print $1}' | ${grep_cmd} "guest")
    if [ -z "${guest_user}" ]; then
      AIX_guest_account_locked=$(echo true)
    else
      AIX_guest_account_locked=$(echo $(lssec -f /etc/security/user -s guest -a account_locked | ${awk_cmd} -F'=' '{print $2}'))
    fi
    AIX_ip_forward=$(echo $(no -a | ${grep_cmd} ipforwarding | ${awk_cmd} -F'= ' '{print $2}'))
    AIX_send_redirects=$(echo $(no -a | ${grep_cmd} ipsendredirects | ${awk_cmd} -F'= ' '{print $2}'))
    AIX_guest_login=$(echo $(lssec -f /etc/security/user -s guest -a login | ${awk_cmd} -F'=' '{print $2}'))
    AIX_guest_rlogin=$(echo $(lssec -f /etc/security/user -s guest -a rlogin | ${awk_cmd} -F'=' '{print $2}'))
    AIX_guest=$(echo $AIX_guest_account_locked,$AIX_guest_login,$AIX_guest_rlogin)
    umask=$(echo $(lssec -f /etc/security/user -s default -a umask | ${awk_cmd} -F'=' '{print $2}'))
    if [ ${#umask} = 1 ]; then
    umask=$(echo 00${umask})
    elif [ ${#umask} = 2 ]; then
    umask=$(echo 0${umask})
    fi
    
    root_pw_expired=$(echo $(lssec -f /etc/security/user -s root -a maxage | ${awk_cmd} -F'=' '{print $2}'))
    if [ -z "${root_pw_expired}" ]; then
      root_pw_expired=${max_days}
    fi
    root_pw_inactive=$(echo $(lssec -f /etc/security/user -s root -a account_locked | ${awk_cmd} -F':' '{print $2}'))
    if [ -z "${root_pw_inactive}" ]; then
      root_pw_inactive=$(echo $(lssec -f /etc/security/user -s default -a account_locked | ${awk_cmd} -F':' '{print $2}'))
    fi
    root_acc_expired=$(echo $(lssec -f /etc/security/user -s root -a expires | ${awk_cmd} -F'=' '{print $2}'))
    if [ -z "${root_acc_expired}" ]; then
      root_acc_expired=$(echo $(lssec -f /etc/security/user -s default -a expires | ${awk_cmd} -F'=' '{print $2}'))
    fi
    superuser_list=$(cat /etc/passwd | ${grep_cmd} -v "^ *#" | ${awk_cmd} -F':' '{print $1","$3}' | ${grep_cmd} ",0" | ${awk_cmd} -F',' '{print $1}')
    superuser=$(echo "${superuser_list}" | ${awk_cmd} '{print}' ORS=',' | sed '$s/.$//')
    NonAuditSuperuser=''
      for usr_name in ${superuser_list}
      do
        audit_tmp=$(echo $(cat /etc/security/audit/config | ${grep_cmd} "${usr_name} ="))
        if [ -z "${audit_tmp}" ]; then
          NonAuditSuperuser=$(echo ${NonAuditSuperuser},${usr_name})
        fi
      done
    if [ -z "${NonAuditSuperuser}"  ]; then
      NonAuditSuperuser=$(echo true)
    else 
      NonAuditSuperuser=$(echo ${NonAuditSuperuser} | sed 's/^.//')
    fi
  elif [ -f "${rel_osol}" ]; then
    max_histories=$(echo $(cat /etc/default/passwd | ${grep_cmd} -v "^ *#" | ${grep_cmd} HISTORY | ${awk_cmd} -F'=' '{print $2}'))
    max_days=$(echo $(cat /etc/default/passwd | ${grep_cmd} -v "^ *#" | ${grep_cmd} MAXWEEKS | ${awk_cmd} -F'=' '{print $2}'),$(cat /etc/default/passwd | ${grep_cmd} -v "^ *#" | ${grep_cmd} MAXDAYS | ${awk_cmd} -F'=' '{print $2}'))
    min_days=$(echo $(cat /etc/default/passwd | ${grep_cmd} -v "^ *#" | ${grep_cmd} MINWEEKS | ${awk_cmd} -F'=' '{print $2}'),$(cat /etc/default/passwd | ${grep_cmd} -v "^ *#" | ${grep_cmd} MINDAYS | ${awk_cmd} -F'=' '{print $2}'))
    min_len=$(echo $(cat /etc/default/passwd | ${grep_cmd} -v "^ *#" | ${grep_cmd} PASSLENGTH | ${awk_cmd} -F'=' '{print $2}'))
    warn_time=$(echo $(cat /etc/default/passwd | ${grep_cmd} -v "^ *#" | ${grep_cmd} WARNWEEKS | ${awk_cmd} -F'=' '{print $2}'))
    min_diff=$(echo $(cat /etc/default/passwd | ${grep_cmd} -v "^ *#" | ${grep_cmd} MINDIFF | ${awk_cmd} -F'=' '{print $2}'))
    min_alpha=$(echo $(cat /etc/default/passwd | ${grep_cmd} -v "^ *#" | ${grep_cmd} MINALPHA | ${awk_cmd} -F'=' '{print $2}'))
    min_digit=$(echo $(cat /etc/default/passwd | ${grep_cmd} -v "^ *#" | ${grep_cmd} MINDIGIT | ${awk_cmd} -F'=' '{print $2}'))
    min_upper=$(echo $(cat /etc/default/passwd | ${grep_cmd} -v "^ *#" | ${grep_cmd} MINUPPER | ${awk_cmd} -F'=' '{print $2}'))
    min_lower=$(echo $(cat /etc/default/passwd | ${grep_cmd} -v "^ *#" | ${grep_cmd} MINLOWER | ${awk_cmd} -F'=' '{print $2}'))
    retries=$(echo $(cat /etc/default/login | ${grep_cmd} -v "^ *#" | ${grep_cmd} RETRIES | ${awk_cmd} -F'=' '{print $2}'))
    umask_ALL=$(cat /etc/profile | ${grep_cmd} -v "^ *#" | ${grep_cmd} umask | ${awk_cmd} -F' ' '{print $2}')
    umask_uniq=$(echo $(echo "${umask_ALL}" | sort | uniq))
    if [ ${#umask_uniq} -eq 3 ]; then
    umask=${umask_uniq}
    else
    umask=$(echo ${umask_ALL})
    fi
    
    root_pw_expired=$(echo $(cat /etc/shadow | ${grep_cmd} -v "^ *#" | ${grep_cmd} root | ${awk_cmd} -F':' '{print $5}'))
    if [ -z "${root_pw_expired}" ]; then
      root_pw_expired=${max_days}
    fi
    root_pw_inactive=$(echo $(cat /etc/shadow | ${grep_cmd} -v "^ *#" | ${grep_cmd} root | ${awk_cmd} -F':' '{print $7}'))
    root_acc_expired=$(echo $(cat /etc/shadow | ${grep_cmd} -v "^ *#" | ${grep_cmd} root | ${awk_cmd} -F':' '{print $8}'))
    superuser_list=$(cat /etc/passwd | ${grep_cmd} -v "^ *#" | ${awk_cmd} -F':' '{print $1","$3}' | ${grep_cmd} ",0" | ${awk_cmd} -F',' '{print $1}')
    superuser=$(echo $(echo "${superuser_list}" | ${awk_cmd} 'BEGIN{ORS=","}1') | sed '$s/.$//')

    Solaris_min_nonalpha=$(echo $(cat /etc/default/passwd | ${grep_cmd} -v "^ *#" | ${grep_cmd} MINNONALPHA | ${awk_cmd} -F'=' '{print $2}'))
    Solaris_dictionlist=$(echo $(cat /etc/default/passwd | ${grep_cmd} -v "^ *#" | ${grep_cmd} DICTIONLIST | ${awk_cmd} -F'=' '{print $2}'))
    Solaris_pwd_algo_info=$(echo $(cat /etc/security/policy.conf | ${grep_cmd} -v "^ *#" | ${grep_cmd} CRYPT_DEFAULT | ${awk_cmd} -F'=' '{print $2}'))
    Solaris_disabletime=$(echo $(cat /etc/default/login | ${grep_cmd} -v "^ *#" | ${grep_cmd} DISABLETIME | ${awk_cmd} -F'=' '{print $2}'))
    Solaris_logingracetime=$(echo $(cat /etc/ssh/sshd_config | ${grep_cmd} -v "^ *#" | ${grep_cmd} LoginGraceTime | ${awk_cmd} -F' ' '{print $2}'))
    Solaris_sleeptime=$(echo $(cat /etc/default/login | ${grep_cmd} -v "^ *#" | ${grep_cmd} SLEEPTIME | ${awk_cmd} -F'=' '{print $2}'))
    Solaris_clientaliveinterval=$(echo $(cat /etc/ssh/sshd_config | ${grep_cmd} -v "^ *#" | ${grep_cmd} ClientAliveInterval | ${awk_cmd} -F' ' '{print $2}'))
    Solaris_ignorerhosts=$(echo $(cat /etc/ssh/sshd_config | ${grep_cmd} -v "^ *#" | ${grep_cmd} IgnoreRhosts | ${awk_cmd} -F' ' '{print $2}'))
    Solaris_forward_src_routed=$(echo $(ipadm show-prop -p _forward_src_routed ipv4 | ${grep_cmd} _forward_src_routed | ${awk_cmd} -F' ' '{print $4}'))
    if [ -z "${Solaris_forward_src_routed}" ]; then
      Solaris_forward_src_routed=$(echo $(ndd /dev/ip ip_forward_src_routed))
    fi
    Solaris_ignore_redirect=$(echo $(ipadm show-prop -p _ignore_redirect ipv4 | ${grep_cmd} _ignore_redirect | ${awk_cmd} -F' ' '{print $4}'))
    if [ -z "${Solaris_ignore_redirect}" ]; then
      Solaris_ignore_redirect=$(echo $(ndd /dev/ip ip_ignore_redirect))
    fi
    Solaris_redirects=$(echo $(ipadm show-prop -p send-redirects ipv4 | ${grep_cmd} send-redirects | ${awk_cmd} -F' ' '{print $4}'))
    if [ -z "${Solaris_redirects}" ] || [ "${Solaris_redirects}" = "?" ] || [ "${Solaris_redirects}" = "y" ]; then
      Solaris_redirects=$(echo $(ipadm show-prop -p send_redirects ipv4 | ${grep_cmd} send_redirects | ${awk_cmd} -F' ' '{print $4}'))
    fi
    if [ -z "${Solaris_redirects}" ] || [ "${Solaris_redirects}" = "?" ] || [ "${Solaris_redirects}" = "y" ]; then
      Solaris_redirects=$(echo $(ndd /dev/ip ip_send_redirects))
    fi
    Solaris_send_redirects=$(echo ${Solaris_ignore_redirect},${Solaris_redirects})
  elif [ -f "${rel_suse}" ]; then
    max_histories=$(echo $(cat /etc/pam.d/common-password | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "remember=[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    max_histories_is_duplicate=$(echo $(echo ${max_histories} | tr ' ' '\n' | ${grep_cmd} -v '^$' | sort | uniq -c | sort -k1,1nr)| ${awk_cmd} -F' ' '{print $3}')
    if [ -z "${max_histories_is_duplicate}" ]; then
      max_histories=$(echo ${max_histories} | ${awk_cmd} -F' ' '{print $1}')
    fi
    max_days=$(echo $(cat /etc/login.defs | ${grep_cmd} -v "^\s*#" | ${grep_cmd} PASS_MAX_DAYS | ${awk_cmd} -F' ' '{print $2}'))
    min_days=$(echo $(cat /etc/login.defs | ${grep_cmd} -v "^\s*#" | ${grep_cmd} PASS_MIN_DAYS | ${awk_cmd} -F' ' '{print $2}'))
    min_len=$(echo $(cat /etc/pam.d/common-password | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "minlen=[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    if [ -z "${min_len}" ]; then
      min_len=$(echo $(cat /etc/security/pwquality.conf | ${grep_cmd} "^\s*minlen" | ${grep_cmd} -o "minlen=[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    fi
    if [ -z "${min_len}" ]; then
      min_len=$(echo $(cat /etc/login.defs | ${grep_cmd} -v "^\s*#" | ${grep_cmd} PASS_MIN_LEN | ${awk_cmd} -F' ' '{print $2}'))
    fi
    warn_time=$(echo $(cat /etc/login.defs | ${grep_cmd} -v "^\s*#" | ${grep_cmd} PASS_WARN_AGE | ${awk_cmd} -F' ' '{print $2}'))
    retries=$(echo $(cat /etc/pam.d/common-password | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "retry=[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    retries_is_duplicate=$(echo $(echo ${retries} | tr ' ' '\n' | ${grep_cmd} -v '^$' | sort | uniq -c | sort -k1,1nr)| ${awk_cmd} -F' ' '{print $3}')
    if [ -z "${retries_is_duplicate}" ]; then
      retries=$(echo ${retries} | ${awk_cmd} -F' ' '{print $1}')
    fi
    umask_ALL=$(cat /etc/login.defs | ${grep_cmd} -v "^\s*#" | ${grep_cmd} UMASK | ${awk_cmd} -F' ' '{print $2}')
    if [ -z "${umask_ALL}" ]; then
      umask_ALL=$(cat /etc/profile | ${grep_cmd} -v "^\s*#" | ${grep_cmd} umask | ${awk_cmd} -F' ' '{print $2}')
    fi
    umask_uniq=$(echo $(echo "${umask_ALL}" | sort | uniq))
    if [ ${#umask_uniq} -eq 3 ]; then
    umask=${umask_uniq}
    else
    umask=$(echo ${umask_ALL})
    fi

    root_pw_expired=$(echo $(cat /etc/shadow | ${grep_cmd} -v "^\s*#" | ${grep_cmd} root | ${awk_cmd} -F':' '{print $5}'))
    root_pw_inactive=$(echo $(cat /etc/shadow | ${grep_cmd} -v "^\s*#" | ${grep_cmd} root | ${awk_cmd} -F':' '{print $7}'))
    root_acc_expired=$(echo $(cat /etc/shadow | ${grep_cmd} -v "^\s*#" | ${grep_cmd} root | ${awk_cmd} -F':' '{print $8}'))
    superuser_list=$(cat /etc/passwd | ${grep_cmd} -v "^ *#" | ${awk_cmd} -F':' '{print $1","$3}' | ${grep_cmd} ",0" | ${awk_cmd} -F',' '{print $1}')
    superuser=$(echo "${superuser_list}" | ${awk_cmd} '{print}' ORS=',' | sed '$s/.$//')

    SUSE_dcredit=$(echo $(cat /etc/pam.d/common-password | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "dcredit=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    SUSE_ucredit=$(echo $(cat /etc/pam.d/common-password | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "ucredit=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    SUSE_lcredit=$(echo $(cat /etc/pam.d/common-password | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "lcredit=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    SUSE_difok=$(echo $(cat /etc/pam.d/common-password | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "difok=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    SUSE_dictpath=$(echo $(cat /etc/security/pwquality.conf | ${grep_cmd} -v "^\s*#" | ${grep_cmd} dictpath | ${awk_cmd} -F'=' '{print $2}'))
    SUSE_pwd_algo_info=$(echo $(cat /etc/login.defs | ${grep_cmd} -v "^\s*#" | ${grep_cmd} "ENCRYPT_METHOD " | ${awk_cmd} -F' ' '{print $2}'))
    SUSE_fail_interval=$(echo $(cat /etc/pam.d/common-auth | ${grep_cmd} "^\s*auth" | ${grep_cmd} -o "fail_interval=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    SUSE_deny=$(echo $(cat /etc/pam.d/common-auth | ${grep_cmd} "^\s*auth" | ${grep_cmd} -o "deny=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    SUSE_unlock_time=$(echo $(cat /etc/pam.d/common-auth | ${grep_cmd} "^\s*auth" | ${grep_cmd} -o "unlock_time=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    SUSE_LOGIN_TIMEOUT=$(echo $(cat /etc/login.defs | ${grep_cmd} -v "^\s*#" | ${grep_cmd} "LOGIN_TIMEOUT" | ${awk_cmd} -F' ' '{print $2}'))
    SUSE_delay=$(echo $(cat /etc/login.defs | ${grep_cmd} -v "^\s*#" | ${grep_cmd} "FAIL_DELAY" | ${awk_cmd} -F' ' '{print $2}'))
    SUSE_tmout=$(echo $(cat /etc/ssh/sshd_config | ${grep_cmd} -v "^\s*#" | ${grep_cmd} "ClientAliveInterval" | ${awk_cmd} -F' ' '{print $2}'))
    SUSE_ignorerhosts=$(echo $(cat /etc/ssh/sshd_config | ${grep_cmd} -v "^\s*#" | ${grep_cmd} "IgnoreRhosts" | ${awk_cmd} -F' ' '{print $2}'))
    SUSE_martians=$(echo $(cat /proc/sys/net/ipv4/conf/all/log_martians))
    SUSE_ip_forward=$(echo $(cat /proc/sys/net/ipv4/ip_forward))
    SUSE_send_redirects=$(echo $(cat /proc/sys/net/ipv4/conf/default/send_redirects))
  else
    max_histories=$(echo $(cat /etc/pam.d/system-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "remember=[0-9]*" | ${awk_cmd} -F'=' '{print $2}' ))
    if [ -z "${max_histories}" ]; then
      max_histories=$(echo $(cat /etc/pam.d/password-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "remember=[0-9]*" | ${awk_cmd} -F'=' '{print $2}' ))
    fi
    max_days=$(echo $(cat /etc/login.defs | ${grep_cmd} -v "^\s*#" | ${grep_cmd} PASS_MAX_DAYS | ${awk_cmd} -F' ' '{print $2}'))
    min_days=$(echo $(cat /etc/login.defs | ${grep_cmd} -v "^\s*#" | ${grep_cmd} PASS_MIN_DAYS | ${awk_cmd} -F' ' '{print $2}'))
	min_len=$(echo $(cat /etc/pam.d/system-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "minlen=[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    if [ -z "${min_len}" ]; then
      min_len=$(echo $(cat /etc/security/pwquality.conf | ${grep_cmd} "^\s*minlen" | ${grep_cmd} -o "minlen=[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    fi
    if [ -z "${min_len}" ]; then
      min_len=$(echo $(cat /etc/pam.d/password-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "minlen=[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    fi
    if [ -z "${min_len}" ]; then
      min_len=$(echo $(cat /etc/login.defs | ${grep_cmd} -v "^\s*#" | ${grep_cmd} PASS_MIN_LEN | ${awk_cmd} -F' ' '{print $2}'))
    fi
    warn_time=$(echo $(cat /etc/login.defs | ${grep_cmd} -v "^\s*#" | ${grep_cmd} PASS_WARN_AGE | ${awk_cmd} -F' ' '{print $2}'))
    retries=$(echo $(cat /etc/pam.d/system-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "retry=[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    if [ -z "${retries}" ]; then
      retries=$(echo $(cat /etc/pam.d/password-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "retry=[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    fi
    umask=$(echo $(cat /etc/bashrc | ${grep_cmd} -v "^ *#" | ${grep_cmd} umask | ${awk_cmd} -F' ' '{print $2}'))
    
	dcredit=$(echo $(cat /etc/pam.d/system-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "dcredit=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
	if [ -z "${dcredit}" ]; then
      dcredit=$(echo $(cat /etc/pam.d/password-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "dcredit=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}' ))
    fi
	ucredit=$(echo $(cat /etc/pam.d/system-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "ucredit=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
	if [ -z "${ucredit}" ]; then
      ucredit=$(echo $(cat /etc/pam.d/password-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "ucredit=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}' ))
    fi
	lcredit=$(echo $(cat /etc/pam.d/system-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "lcredit=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
	if [ -z "${lcredit}" ]; then
      lcredit=$(echo $(cat /etc/pam.d/password-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "lcredit=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}' ))
    fi
	martians=$(echo $(cat /etc/sysctl.conf | ${grep_cmd} -v "^ *#" | ${grep_cmd}  net.ipv4.conf.all.log_martians | ${awk_cmd} -F'=' '{print $2}'))
	ip_forward=$(echo $(cat /etc/sysctl.conf | ${grep_cmd} -v "^ *#" | ${grep_cmd}  net.ipv4.ip_forward | ${awk_cmd} -F'=' '{print $2}'))
	send_redirects=$(echo $(cat /etc/sysctl.conf | ${grep_cmd} -v "^ *#" | ${grep_cmd}  net.ipv4.conf.default.send_redirects | ${awk_cmd} -F'=' '{print $2}'))
	
    root_pw_expired=$(echo $(cat /etc/shadow | ${grep_cmd} -v "^\s*#" | ${grep_cmd} root | ${awk_cmd} -F':' '{print $5}'))
    root_pw_inactive=$(echo $(cat /etc/shadow | ${grep_cmd} -v "^\s*#" | ${grep_cmd} root | ${awk_cmd} -F':' '{print $7}'))
    root_acc_expired=$(echo $(cat /etc/shadow | ${grep_cmd} -v "^\s*#" | ${grep_cmd} root | ${awk_cmd} -F':' '{print $8}'))
    superuser_list=$(cat /etc/passwd | ${grep_cmd} -v "^ *#" | ${awk_cmd} -F':' '{print $1","$3}' | ${grep_cmd} ",0" | ${awk_cmd} -F',' '{print $1}')
    superuser=$(echo "${superuser_list}" | ${awk_cmd} '{print}' ORS=',' | sed '$s/.$//')

    Linux_difok=$(echo $(cat /etc/pam.d/system-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "difok=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    if [ -z "${Linux_difok}" ]; then
      Linux_difok=$(echo $(cat /etc/pam.d/password-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "difok=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}' ))
    fi
    
    Linux_fail_interval=$(echo $(cat /etc/pam.d/system-auth | ${grep_cmd} "^\s*auth" | ${grep_cmd} -o "fail_interval=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    if [ -z "${Linux_fail_interval}" ]; then
      Linux_fail_interval=$(echo $(cat /etc/pam.d/password-auth | ${grep_cmd} "^\s*auth" | ${grep_cmd} -o "fail_interval=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}' ))
    fi
    Linux_fail_interval_is_duplicate=$(echo $(echo ${Linux_fail_interval} | tr ' ' '\n' | ${grep_cmd} -v '^$' | sort | uniq -c | sort -k1,1nr)| ${awk_cmd} -F' ' '{print $3}')
    if [ -z "${Linux_fail_interval_is_duplicate}" ]; then
      Linux_fail_interval=$(echo ${Linux_fail_interval} | ${awk_cmd} -F' ' '{print $1}')
    fi

    Linux_deny=$(echo $(cat /etc/pam.d/system-auth | ${grep_cmd} "^\s*auth" | ${grep_cmd} -o "deny=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    if [ -z "${Linux_deny}" ]; then
      Linux_deny=$(echo $(cat /etc/pam.d/password-auth | ${grep_cmd} "^\s*auth" | ${grep_cmd} -o "deny=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}' ))
    fi
    Linux_deny_is_duplicate=$(echo $(echo ${Linux_deny} | tr ' ' '\n' | ${grep_cmd} -v '^$' | sort | uniq -c | sort -k1,1nr)| ${awk_cmd} -F' ' '{print $3}')
    if [ -z "${Linux_deny_is_duplicate}" ]; then
      Linux_deny=$(echo ${Linux_deny} | ${awk_cmd} -F' ' '{print $1}')
    fi
    
    Linux_unlock_time=$(echo $(cat /etc/pam.d/system-auth | ${grep_cmd} "^\s*auth" | ${grep_cmd} -o "unlock_time=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    if [ -z "${Linux_unlock_time}" ]; then
      Linux_unlock_time=$(echo $(cat /etc/pam.d/password-auth | ${grep_cmd} "^\s*auth" | ${grep_cmd} -o "unlock_time=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}' ))
    fi
    Linux_unlock_time_is_duplicate=$(echo $(echo ${Linux_unlock_time} | tr ' ' '\n' | ${grep_cmd} -v '^$' | sort | uniq -c | sort -k1,1nr)| ${awk_cmd} -F' ' '{print $3}')
    if [ -z "${Linux_unlock_time_is_duplicate}" ]; then
      Linux_unlock_time=$(echo ${Linux_unlock_time} | ${awk_cmd} -F' ' '{print $1}')
    fi
    
    Linux_delay=$(echo $(cat /etc/pam.d/system-auth | ${grep_cmd} "^\s*auth" | ${grep_cmd} -o "delay=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    if [ -z "${Linux_delay}" ]; then
      Linux_delay=$(echo $(cat /etc/pam.d/password-auth | ${grep_cmd} "^\s*auth" | ${grep_cmd} -o "delay=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}' ))
    fi
    Linux_dictpath=$(echo $(cat /etc/security/pwquality.conf | ${grep_cmd} -v "^\s*#" | ${grep_cmd} dictpath | ${awk_cmd} -F'=' '{print $2}'))
    Linux_pwd_algo_info=$(echo $(cat /etc/login.defs | ${grep_cmd} -v "^\s*#" | ${grep_cmd} ENCRYPT_METHOD | ${awk_cmd} -F' ' '{print $2}'))
    Linux_ServerAliveInterval=$(echo $(cat /etc/ssh/ssh_config | ${grep_cmd} -v "^\s*#" | ${grep_cmd} ServerAliveInterval | ${awk_cmd} -F' ' '{print $2}'))
    Linux_tmout=$(echo $(cat /etc/ssh/sshd_config | ${grep_cmd} -v "^\s*#" | ${grep_cmd} ClientAliveInterval | ${awk_cmd} -F' ' '{print $2}'))
    Linux_ignorerhosts=$(echo $(cat /etc/ssh/sshd_config | ${grep_cmd} -v "^\s*#" | ${grep_cmd} IgnoreRhosts | ${awk_cmd} -F' ' '{print $2}'))
  fi
  if [ -z "${root_pw_expired}" ]; then
    root_pw_expired="never"
  fi
  if [ -z "${root_pw_inactive}" ]; then
    root_pw_inactive="never"
  fi
  if [ -z "${root_acc_expired}" ]; then
    root_acc_expired="never"
  fi
}
gen_sys_info
gen_policies_info

echo ${hostname}
echo ${os_name}
  if [ "${os}" = "${os_aix}" ]; then
    echo ${max_histories}
    echo ${max_days}
    echo ${min_days}
    echo ${min_len}
#   echo ${warn_time}
    echo ${retries}
    echo ${AIX_histexpire}
    echo ${AIX_minother}
    echo ${AIX_minalpha}
    echo ${AIX_mindigit}
    echo ${AIX_minupperalpha}
    echo ${AIX_minloweralpha}
    echo ${AIX_mindiff}
    echo ${AIX_dictionlist}
    echo ${AIX_pwd_algo_info}
    echo ${umask}
    echo ${AIX_logininterval}
    echo ${AIX_logindisable}
    echo ${AIX_loginreenable}
    echo ${AIX_logintimeout}
    echo ${AIX_logindelay}
    echo ${AIX_tmout}
    echo ${AIX_auditstart}
    echo ${AIX_auditshutdown}
    echo ${AIX_ignorerhosts}
    echo ${AIX_binmode}
    echo ${AIX_ip_forward}
    echo ${AIX_send_redirects}
#   echo ${AIX_guest}
    echo ${superuser}
    echo ${NonAuditSuperuser}
  elif [ -f "${rel_osol}" ]; then
    echo ${max_histories}
    echo ${max_days}
    echo ${min_days}
    echo ${min_len}
#   echo ${warn_time}
    echo ${retries}
    echo ${Solaris_min_nonalpha}
    echo ${min_alpha}
#   echo ${min_digit}
    echo ${min_upper}
    echo ${min_lower}
    echo ${min_diff}
    echo ${Solaris_dictionlist}
    echo ${Solaris_pwd_algo_info}
    echo ${umask}
    echo ${Solaris_disabletime}
    echo ${Solaris_logingracetime}
    echo ${Solaris_sleeptime}
    echo ${Solaris_clientaliveinterval}
    echo ${Solaris_ignorerhosts}
    echo ${Solaris_forward_src_routed}
    echo ${Solaris_send_redirects}
    echo ${superuser}
  elif [ -f "${rel_suse}" ]; then
    echo ${max_histories}
    echo ${max_days}
    echo ${min_days}
    echo ${min_len}
#   echo ${warn_time}
    echo ${retries}
    echo ${SUSE_dcredit}
    echo ${SUSE_ucredit}
    echo ${SUSE_lcredit}
    echo ${SUSE_difok}
    echo ${SUSE_dictpath}
    echo ${SUSE_pwd_algo_info}
    echo ${umask}
    echo ${SUSE_fail_interval}
    echo ${SUSE_deny}
    echo ${SUSE_unlock_time}
    echo ${SUSE_LOGIN_TIMEOUT}
    echo ${SUSE_delay}
    echo ${SUSE_tmout}
    echo ${SUSE_ignorerhosts}
    echo ${SUSE_martians}
    echo ${SUSE_ip_forward}
    echo ${SUSE_send_redirects}
    echo ${superuser}
  else
    echo ${max_histories}
    echo ${max_days}
    echo ${min_days}
    echo ${min_len}
#   echo ${warn_time}
    echo ${retries}
    echo ${dcredit}
    echo ${ucredit}
    echo ${lcredit}
    echo ${Linux_difok}
    echo ${Linux_dictpath}
    echo ${Linux_pwd_algo_info}
    echo ${umask}
    echo ${Linux_fail_interval}
    echo ${Linux_deny}
    echo ${Linux_unlock_time}
    echo ${Linux_ServerAliveInterval}
    echo ${Linux_delay}
    echo ${Linux_tmout}
    echo ${Linux_ignorerhosts}
    echo ${martians}
    echo ${ip_forward}
    echo ${send_redirects}
    echo ${superuser}
  fi
echo ${root_pw_expired}
echo ${root_pw_inactive}
echo ${root_acc_expired}