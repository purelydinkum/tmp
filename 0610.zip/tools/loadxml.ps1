﻿param(
  [Parameter(Mandatory=$true)]
  [string]$Hostname
)
BEGIN {
  Set-Variable -Name g_tag -Value "[SYS]" -Scope Private;
  Set-Variable -Name g_abs_origin_dir -Value (Get-Item -Path ".\").FullName -Scope Private;
  Set-Variable -Name g_tool_dir -Value "C:\SecurityScan\Tools" -Scope Private;
  Set-Variable -Name g_url -Value "" -Scope Private;
  Set-Variable -Name g_sh -Value "showinfo.sh" -Scope Private;
  Set-Variable -Name g_cfg -Value "Collect-SystemInfo.cfg" -Scope Private;
  Set-Variable -Name g_xml -Value "sysdata.xml" -Scope Private;
  Set-Variable -Name g_data_dir -Value "C:\SecurityScan\Data" -Scope Private;
  Set-Variable -Name g_retval -Value "" -Scope Private;
  Set-Variable -Name g_upload_proxy -Value "" -Scope Private;
  Set-Variable -Name g_target_hostname -Value "" -Scope Private;
  Set-Variable -Name g_phase -Value "" -Scope Private;
  Write-Host "## Begin of function: $($MyInvocation.MyCommand)" -ForegroundColor Green;
}
PROCESS {
  try {
    $env:Path += ";$g_tool_dir\putty"
    $g_phase=
    Write-Host -NoNewline "$g_tag Check configuration ... "
    if (Test-Path "$g_tool_dir\$g_cfg") {
      $g_url=(Get-Content "$g_tool_dir\$g_cfg") | Select-String "^ServiceURL=" | %{ $_.ToString().Split("=")[1] }
    }
    if ([string]::IsNullOrEmpty($g_url)) { throw "ServiceURL should not be empty. Check configuration: $g_tool_dir\$g_cfg" }
    Write-Host "Done"
	
    Write-Host -NoNewline "$g_tag Check web service SecurityScan ..."
    [System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}
    $g_upload_proxy=New-WebServiceProxy $g_url
    Write-Host "Done"

    $datafile="${Hostname}.xml"
    cd "${g_data_dir}"
    
    Write-Host -NoNewline "$g_tag Upload $datafile ... "
    if (Test-Path $datafile) {
      $upload_xmldata=Get-Content -Encoding utf8 "$datafile"
      $g_retval=$g_upload_proxy.UploadFile($Hostname, $upload_xmldata)
      if ($g_retval -ne "000") {
        Write-Host "Failed to upload: $g_retval" -BackgroundColor Red -ForegroundColor White
        exit 1
      }
      Write-Host "Done"
    }
    else {
      throw "Failed to upload data file: Data file not found."
    }
  }
  catch {
    if (!$g_upload_proxy) {
      Write-Host "Failed to initialize web proxy." -BackgroundColor Red -ForegroundColor White
      Write-Host "$($_.Exception.Message)" -BackgroundColor Red -ForegroundColor White
    }
    else {
      Write-Host "[$($_.InvocationInfo.ScriptLineNumber)] $($_.Exception.Message)" -BackgroundColor Red -ForegroundColor White
    }
    exit 1
  }
  finally {
    cd $g_abs_origin_dir;
  }
}
END {
  Write-Host "## End of function: $($MyInvocation.MyCommand)" -ForegroundColor Green;
  Remove-Variable -Name g_tag -Scope Private;
  Remove-Variable -Name g_abs_origin_dir -Scope Private;
  Remove-Variable -Name g_url -Scope Private;
  Remove-Variable -Name g_sh -Scope Private;
  Remove-Variable -Name g_tool_dir -Scope Private;
  Remove-Variable -Name g_data_dir -Scope Private;
  Remove-Variable -Name g_retval -Scope Private;
  Remove-Variable -Name g_upload_proxy -Scope Private;
  Remove-Variable -Name g_target_hostname -Scope Private;
  Remove-Variable -Name g_xml -Scope Private;
  Remove-Variable -Name g_phase -Scope Private;
}