﻿param(
  [string]$IPaddr,
  [string]$Account,
  [string]$Password,
  [string]$Port="22",
  [ValidateSet("Local","Remote")]
  [string]$DataMode="Remote"
)
BEGIN {
  Set-Variable -Name g_tag -Value "[SYS]" -Scope Private;
  Set-Variable -Name g_abs_origin_dir -Value (Get-Item -Path ".\").FullName -Scope Private;
  Set-Variable -Name g_tool_dir -Value "C:\SecurityScan\Tools" -Scope Private;
  Set-Variable -Name g_url -Value "" -Scope Private;
  Set-Variable -Name g_sh -Value "showinfo.sh" -Scope Private;
  Set-Variable -Name g_cfg -Value "Collect-SystemInfo.cfg" -Scope Private;
  Set-Variable -Name g_xml -Value "sysdata.xml" -Scope Private;
  Set-Variable -Name g_data_dir -Value "C:\SecurityScan\Data" -Scope Private;
  Set-Variable -Name g_retval -Value "" -Scope Private;
  Set-Variable -Name g_upload_proxy -Value "" -Scope Private;
  Set-Variable -Name g_target_hostname -Value "" -Scope Private;
  Set-Variable -Name g_phase -Value "" -Scope Private;
  Write-Host "## Begin of function: $($MyInvocation.MyCommand)" -ForegroundColor Green;
}
PROCESS {
  try {
    $env:Path += ";$g_tool_dir\putty"
    $g_phase=
    Write-Host -NoNewline "$g_tag Check configuration ... "
    if (Test-Path "$g_tool_dir\$g_cfg") {
      $g_url=(Get-Content "$g_tool_dir\$g_cfg") | Select-String "^ServiceURL=" | %{ $_.ToString().Split("=")[1] }
    }
    if ([string]::IsNullOrEmpty($g_url)) { throw "ServiceURL should not be empty. Check configuration: $g_tool_dir\$g_cfg" }
    Write-Host "Done"
	
    Write-Host -NoNewline "$g_tag Check web service SecurityScan ..."
    [System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}
    $g_upload_proxy=New-WebServiceProxy $g_url
    Write-Host "Done"

    Write-Host -NoNewline "$g_tag Check arguments ... "
    if ([string]::IsNullOrEmpty($IPaddr)) { throw "IPaddr should not be empty." }
    if ([string]::IsNullOrEmpty($Account)) { throw "Account should not be empty." }
    if ([string]::IsNullOrEmpty($Password)) { throw "Password should not be empty." }
    Write-Host "Done"

    cd "${g_tool_dir}"
    Write-Host -NoNewline "$g_tag Send shell script to ${IPaddr} ... "
    $g_retval=Write-Output y | PSCP.EXE -pw ${Password} -P $Port .\${g_sh} ${Account}@${IPaddr}:/tmp 2>&1
    if ($LASTEXITCODE -ne 0) { throw "Failed to send file: ${g_retval}" }
    Write-Host "Done"
	
    Write-Host -NoNewline "$g_tag Get remote hostname ... "
	
    $g_retval=PLINK.EXE -batch -ssh $IPaddr -l $Account -pw $Password -P $Port "hostname" 2>&1
    if ($LASTEXITCODE -ne 0) { throw "Failed to get remote hostname: ${g_retval}" }
    Write-Host "Done"
    $g_target_hostname=$g_retval
	
    Write-Host -NoNewline "$g_tag Change file access and get system info ... "
    if ($DataMode -eq "Local") {
      $g_retval=PLINK.EXE $IPaddr -batch -ssh -l $Account -pw $Password -P $Port "chmod 700 /tmp/${g_sh};/tmp/${g_sh}" 2>&1
    }
	else {
      $g_retval=PLINK.EXE $IPaddr -batch -ssh -l $Account -pw $Password -P $Port "chmod 700 /tmp/${g_sh};/tmp/${g_sh}>/tmp/${g_xml}" 2>&1
    }
    if ($LASTEXITCODE -ne 0) { throw "Failed to get info: ${g_retval}" }
    Write-Host "Done"
    $data=$g_retval
	
    $datafile="${g_target_hostname}.xml"
    cd "${g_data_dir}"
    Write-Host -NoNewline "$g_tag Write system info to $datafile ... "
    if ($DataMode -eq "Local") {
      $data | Out-File "$datafile" -Encoding utf8
    }
	else {
      PSCP.EXE -pw ${Password} -P $Port ${Account}@${IPaddr}:/tmp/sysdata.xml ${datafile} 2>&1
      PLINK.EXE $IPaddr -batch -ssh -l $Account -pw $Password -P $Port "cd /tmp; rm ${g_xml}; rm ${g_sh}" 2>&1
    }
    Write-Host "Done"

    Write-Host -NoNewline "$g_tag Upload $datafile ... "
    if (Test-Path $datafile) {
      $upload_xmldata=Get-Content -Encoding utf8 "$datafile"
      $g_retval=$g_upload_proxy.UploadFile($g_target_hostname, $upload_xmldata)
      if ($g_retval -ne "000") {
        Write-Host "Failed to upload: $g_retval" -BackgroundColor Red -ForegroundColor White
        exit 1
      }
      Write-Host "Done"
    }
    else {
      throw "Failed to upload data file: Data file not found."
    }
  }
  catch {
    if (!$g_upload_proxy) {
      Write-Host "Failed to initialize web proxy." -BackgroundColor Red -ForegroundColor White
      Write-Host "$($_.Exception.Message)" -BackgroundColor Red -ForegroundColor White
    }
    else {
      $retval=$g_upload_proxy.UploadError(`
        @{$True="${IPaddr}";$False="${g_target_hostname}"}[[string]::IsNullOrEmpty($g_target_hostname)],`
        "[$($_.InvocationInfo.ScriptLineNumber)] $($_.Exception.Message)")
      Write-Host "[$($_.InvocationInfo.ScriptLineNumber)] $($_.Exception.Message)" -BackgroundColor Red -ForegroundColor White
    }
    exit 1
  }
  finally {
    cd $g_abs_origin_dir;
  }
}
END {
  Write-Host "## End of function: $($MyInvocation.MyCommand)" -ForegroundColor Green;
  Remove-Variable -Name g_tag -Scope Private;
  Remove-Variable -Name g_abs_origin_dir -Scope Private;
  Remove-Variable -Name g_url -Scope Private;
  Remove-Variable -Name g_sh -Scope Private;
  Remove-Variable -Name g_tool_dir -Scope Private;
  Remove-Variable -Name g_data_dir -Scope Private;
  Remove-Variable -Name g_retval -Scope Private;
  Remove-Variable -Name g_upload_proxy -Scope Private;
  Remove-Variable -Name g_target_hostname -Scope Private;
  Remove-Variable -Name g_xml -Scope Private;
  Remove-Variable -Name g_phase -Scope Private;
}