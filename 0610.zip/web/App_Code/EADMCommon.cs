﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Net.Mail;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.Web.UI;


/// <summary>
/// EADMCommon 的摘要描述
/// </summary>
public class EADMCommon
{
    static string key = "HADMSKEY";
    static string iv = "HADMSIIV";
    public static void add_ERROR_LOG(string ERROR_TYPE, string LOG_TEXT)
    {


        try
        {
            string log = DateTime.Now.ToString() + "\t" + LOG_TEXT + Environment.NewLine;
            string[] lines = { log };
            string EventFilePath_txt = AppDomain.CurrentDomain.BaseDirectory + @"Log\" + DateTime.Now.ToString("yyyyMMdd") + ".txt";
            try
            {
                File.AppendAllText(EventFilePath_txt, log, System.Text.Encoding.GetEncoding("big5"));

            }
            catch (IOException exception)
            {

            }

        }
        catch(Exception ex)
        {

        }


    }
    /// <summary> 
    /// 取得序號
    /// </summary>
    /// <param name="Type"></param>
    /// <returns>Type+yyyyMMdd+001</returns>
    public static string getSerialNum(string Type)
    {
        DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
        ParameterCollection objParams = new ParameterCollection();
        string SerialNum = string.Empty;

        string sql = "SELECT SerialNo AS SerialNum FROM SerialNum_Config WHERE Type = @Type";
        objParams.Add("Type", DbType.String, Type);

        object obj = da.ExecuteScalar(sql, objParams);

        if (obj != null)
            SerialNum = obj.ToString();

        objParams.Clear();
        //判斷Type類別資料是否第一次新增
        if (string.IsNullOrEmpty(SerialNum))
        {
            SerialNum = DateTime.Now.ToString("yyyyMMdd") + "001";
            sql = "INSERT INTO SerialNum_Config (Type, SerialNo) VALUES (@Type, @SerialNum)";
            objParams.Add("Type", DbType.String, Type);
            objParams.Add("SerialNum", DbType.String, SerialNum);
        }
        else
        {
            if (DateTime.Parse(DateTime.Now.ToString("yyyy/MM/dd")) >
                DateTime.Parse(Utility.GetDateFormat(SerialNum.Substring(0, 8))))
            {
                SerialNum = DateTime.Now.ToString("yyyyMMdd") + "001";
                sql = "UPDATE SerialNum_Config SET SerialNo=@SerialNum WHERE Type=@Type";
                objParams.Add("Type", DbType.String, Type);
                objParams.Add("SerialNum", DbType.String, DateTime.Now.ToString("yyyyMMdd") + "002");
            }
            else
            {
                SerialNum = (Int64.Parse(SerialNum) + 1).ToString();
                sql = "UPDATE SerialNum_Config SET SerialNo=@SerialNum WHERE Type=@Type";
                objParams.Add("Type", DbType.String, Type);
                objParams.Add("SerialNum", DbType.String, SerialNum);
            }
        }
        da.ExecuteNonQuery(sql, objParams);

        return Type + SerialNum;
    }

    /// <summary> 
    /// 取得序號
    /// </summary>
    /// <param name="Type"></param>
    /// <returns>0001</returns>
    public static string getSerialOnlyNum(string Type)
    {
        DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
        ParameterCollection objParams = new ParameterCollection();
        string SerialNum = string.Empty;

        string sql = "SELECT SerialNo AS SerialNum FROM SerialNum_Config WHERE Type =@Type";
        objParams.Add("Type", DbType.String, Type);

        object obj = da.ExecuteScalar(sql, objParams);

        if (obj != null)
            SerialNum = obj.ToString().Trim();

        objParams.Clear();
        //判斷Type類別資料是否第一次新增
        if (string.IsNullOrEmpty(SerialNum))
        {
            SerialNum = "1";
            sql = "INSERT INTO SerialNum_Config (Type, SerialNo) VALUES (@Type, @SerialNum)";
            objParams.Add("Type", DbType.String, Type);
            objParams.Add("SerialNum", DbType.String, SerialNum);
        }
        else
        {
            SerialNum = (Int64.Parse(SerialNum) + 1).ToString();
            sql = "UPDATE SerialNum_Config SET SerialNo=@SerialNum WHERE Type=@Type";
            objParams.Add("Type", DbType.String, Type);
            objParams.Add("SerialNum", DbType.String, SerialNum);
        }
        da.ExecuteNonQuery(sql, objParams);

        return SerialNum;
    }

   

    #region 登入取得身分函式
    //public static string RenderHtml(HtmlControl ctrl)
    //{
    //    StringBuilder sb = new StringBuilder();
    //    StringWriter sw = new StringWriter(sb);
    //    HtmlTextWriter htw = new HtmlTextWriter(sw);

    //    ctrl.RenderControl(htw);

    //    return sb.ToString();
    //}
    #endregion

    #region 密碼
    /// <summary>
    /// 取得密碼
    /// </summary>
    /// <returns></returns>
    //public static string getPassword()
    //{
    //    string Password = string.Empty;
    //    while (!ComparePassword(Password))
    //        Password = GeneratePassword();

    //    return Encrypt(Password);
    //}

    /// <summary>
    /// 產生密碼
    /// </summary>
    /// <returns></returns>
    //private static string GeneratePassword()
    //{
    //    const string sql = @"SELECT ParameterId,ParameterValue FROM PasswordPolicy_Config WHERE ParameterId='PwdChar' OR ParameterId='PwdLength'";
    //    var da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
    //    var dtb = da.ExecuteDataTable(sql);

    //    string PwdChar = string.Empty;
    //    int PwdLength = 0;
    //    for (int i = 0; i < dtb.Rows.Count; i++)
    //    {
    //        if (dtb.Rows[i]["ParameterId"].ToString() == "PwdChar")
    //            PwdChar = dtb.Rows[i]["ParameterValue"].ToString();
    //        else
    //            PwdLength = Convert.ToInt32(dtb.Rows[i]["ParameterValue"].ToString());
    //    }

    //    System.Text.StringBuilder sb = new System.Text.StringBuilder();
    //    //take out char: 190 giloq IO 
    //    char[] chars = PwdChar.ToCharArray();

    //    Dictionary<int, char[]> Dic = new Dictionary<int, char[]>();
    //    for (int i = 0; i < PwdChar.Split(';').Count(); i++)
    //        Dic.Add(i, PwdChar.Split(';')[i].ToCharArray());

    //    int length = RNG.Next(PwdLength, PwdLength);
    //    for (int i = 0; i < length; i++)
    //        sb.Append(Dic[(i % 3)][RNG.Next(Dic[(i % 3)].Length - 1)]);

    //    return sb.ToString();
    //}

    /// <summary>
    /// 比對是否符合密碼規則
    /// </summary>
    /// <param name="Password"></param>
    /// <returns></returns>
    private static bool ComparePassword(string Password)
    {
        const string sql = @"SELECT ParameterId,ParameterValue FROM PasswordPolicy_Config WHERE ParameterId='PwdChar' ";
        var da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
        var dtb = da.ExecuteDataTable(sql);

        string strLowerLetter = dtb.Rows[0]["ParameterValue"].ToString();
        bool Result = false;

        foreach (char c in Password)
        {
            foreach (char charLowerLetter in strLowerLetter)
            {
                if (charLowerLetter.Equals(c))
                {
                    Result = true;
                    break;
                }
            }
        }

        return Result;
    }

    ///// <summary> 將文字加密回傳暗碼
    ///// 
    ///// </summary>
    ///// <param name="data"></param>
    ///// <returns></returns>
    //public static string Encrypt(string data)
    //{
    //    byte[] buffer = System.Text.Encoding.Default.GetBytes(data);
    //    MemoryStream ms = new MemoryStream();
    //    DESCryptoServiceProvider des = new DESCryptoServiceProvider();
    //    CryptoStream encStream = new CryptoStream(ms, des.CreateEncryptor(Encoding.Default.GetBytes(key), Encoding.Default.GetBytes(iv)), CryptoStreamMode.Write);
    //    encStream.Write(buffer, 0, buffer.Length);
    //    encStream.FlushFinalBlock();
    //    return Convert.ToBase64String(ms.ToArray());
    //}

    ///// <summary> 將暗碼轉成明碼
    ///// 
    ///// </summary>
    ///// <param name="data"></param>
    ///// <returns></returns>
    //public static string Decrypt(string data)
    //{

    //    byte[] buffer = Convert.FromBase64String(data);
    //    MemoryStream ms = new MemoryStream();
    //    DESCryptoServiceProvider des = new DESCryptoServiceProvider();
    //    CryptoStream encStream = new CryptoStream(ms, des.CreateDecryptor(Encoding.Default.GetBytes(key), Encoding.Default.GetBytes(iv)), CryptoStreamMode.Write);
    //    encStream.Write(buffer, 0, buffer.Length);
    //    encStream.FlushFinalBlock();
    //    return Encoding.Default.GetString(ms.ToArray());
    //}

    //public static string EncryptBase64(string data)
    //{
    //    string encrypt = "";
    //    encrypt = data;
    //    if (data != null)
    //    {
    //        DESCryptoServiceProvider des = new DESCryptoServiceProvider();
    //        byte[] key = Encoding.ASCII.GetBytes("12345678");
    //        byte[] iv = Encoding.ASCII.GetBytes("87654321");
    //        byte[] dataByteArray = Encoding.UTF8.GetBytes(data);

    //        des.Key = key;
    //        des.IV = iv;
            
    //        using (MemoryStream ms = new MemoryStream())
    //        using (CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(), CryptoStreamMode.Write))
    //        {
    //            cs.Write(dataByteArray, 0, dataByteArray.Length);
    //            cs.FlushFinalBlock();
    //            encrypt = Convert.ToBase64String(ms.ToArray());
    //        }
    //    }
    //    return encrypt;
    //}

    //public static string DecryptBase64(string encrypt)
    //{
    //    DESCryptoServiceProvider des = new DESCryptoServiceProvider();
    //    if (encrypt != null)
    //    {
    //        byte[] key = Encoding.ASCII.GetBytes("12345678");
    //        byte[] iv = Encoding.ASCII.GetBytes("87654321");
    //        des.Key = key;
    //        des.IV = iv;

    //        byte[] dataByteArray = Convert.FromBase64String(encrypt);
    //        using (MemoryStream ms = new MemoryStream())
    //        {
    //            using (CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(), CryptoStreamMode.Write))
    //            {
    //                cs.Write(dataByteArray, 0, dataByteArray.Length);
    //                cs.FlushFinalBlock();
    //                return Encoding.UTF8.GetString(ms.ToArray());
    //            }
    //        }
    //    }
    //    else
    //    {
    //        return encrypt;
    //    }
    //}

    #endregion
    
    
    
    /// <summary>
    /// 由IP規則轉換成電腦名稱
    /// </summary>
    /// <param name="ip">IP</param>
    /// <param name="PCtype">電腦類型</param>
    /// <param name="DepId">登入者部門編號</param>
    /// <returns></returns>
    public static string IPJudge(string ip, string PCtype, string DepId)
    {
        int Flag = 0;
        string PCName = string.Empty;
        //10.48.46.56→B046C056
        string[] listIP = ip.Split(new char[] { '.', ':' });
        if (listIP.Count() < 4)
        {
            Flag = 1;
        }
        else
        {
            //稽核處
            if (DepId == "145")
            {
                switch (listIP[1])
                {
                    case "64":
                        PCName = "B" + listIP[2].PadLeft(3, '0') + "C" + listIP[3].PadLeft(3, '0') + "C";
                        break;
                    case "80":
                        PCName = "B" + listIP[2].PadLeft(3, '0') + "C" + listIP[3].PadLeft(3, '0') + "S";
                        break;
                }
            }
            else if (DepId == "102")
            {
                if (listIP[1] == "2")
                {
                    switch (listIP[2])
                    {
                        case "33":
                            PCName = "P102C" + listIP[3].PadLeft(3, '0');
                            break;
                        case "34":
                            PCName = "P102D" + listIP[3].PadLeft(3, '0');
                            break;
                        case "35":
                            PCName = "P102E" + listIP[3].PadLeft(3, '0');
                            break;
                        case "36":
                            PCName = "P102F" + listIP[3].PadLeft(3, '0');
                            break;
                        case "37":
                            PCName = "P102H" + listIP[3].PadLeft(3, '0');
                            break;
                        case "41":
                            PCName = "P102J" + listIP[3].PadLeft(3, '0');
                            break;
                        case "42":
                            PCName = "P102K" + listIP[3].PadLeft(3, '0');
                            break;
                        case "43":
                            PCName = "P102L" + listIP[3].PadLeft(3, '0');
                            break;
                        case "44":
                            PCName = "P102M" + listIP[3].PadLeft(3, '0');
                            break;
                        case "45":
                            PCName = "P102N" + listIP[3].PadLeft(3, '0');
                            break;
                        case "46":
                            PCName = "P102O" + listIP[3].PadLeft(3, '0');
                            break;
                        case "47":
                            PCName = "P102P" + listIP[3].PadLeft(3, '0');
                            break;
                        case "53":
                            PCName = "P102Y" + listIP[3].PadLeft(3, '0');
                            break;
                        case "54":
                            PCName = "P102Z" + listIP[3].PadLeft(3, '0');
                            break;
                        case "55":
                            PCName = "P102X" + listIP[3].PadLeft(3, '0');
                            break;
                    }
                }
                else if (listIP[1] == "24")
                {
                    switch (listIP[2])
                    {
                        case "1":
                            PCName = "B102C" + listIP[3].PadLeft(3, '0') + "X";
                            break;
                        case "2":
                            PCName = "B102C" + listIP[3].PadLeft(3, '0') + "X1";
                            break;
                    }
                }
            }


            if (string.IsNullOrEmpty(PCName))
            {
                switch (listIP[1])
                {
                    case "32":
                    case "48":
                    case "64":
                    case "80":
                    case "112":
                        if (PCtype == "General")
                            PCName = "B" + listIP[2].PadLeft(3, '0') + "C" + listIP[3].PadLeft(3, '0');
                        else
                            PCName = "B" + listIP[2].PadLeft(3, '0') + "C" + listIP[3].PadLeft(3, '0') + "M";
                        break;
                    case "36":
                    case "52":
                    case "68":
                    case "84":
                    case "116":
                        PCName = "B" + listIP[2].PadLeft(3, '0') + "C" + listIP[3].PadLeft(3, '0') + "-1";
                        break;
                    case "40":
                    case "56":
                    case "72":
                    case "88":
                    case "120":
                        PCName = "B" + listIP[2].PadLeft(3, '0') + "D" + listIP[3].PadLeft(3, '0');
                        break;
                    //分行250之後
                    case "33":
                    case "49":
                    case "65":
                    case "81":
                    case "113":
                        if (PCtype == "General")
                            PCName = "B" + (Convert.ToInt32(listIP[2]) + 250) + "C" + listIP[3].PadLeft(3, '0');
                        else
                            PCName = "B" + (Convert.ToInt32(listIP[2]) + 250) + "C" + listIP[3].PadLeft(3, '0') + "M";
                        break;
                    case "37":
                    case "53":
                    case "69":
                    case "85":
                    case "117":
                        PCName = "B" + (Convert.ToInt32(listIP[2]) + 250) + "C" + listIP[3].PadLeft(3, '0') + "-1";
                        break;
                    case "41":
                    case "57":
                    case "73":
                    case "89":
                    case "121":
                        PCName = "B" + (Convert.ToInt32(listIP[2]) + 250) + "D" + listIP[3].PadLeft(3, '0');
                        break;
                    case "99":
                        PCName = "B" + listIP[2].PadLeft(3, '0') + "C" + listIP[3].PadLeft(3, '0') + "X";
                        break;
                    case "100":
                        PCName = "B" + listIP[2].PadLeft(3, '0') + "C" + listIP[3].PadLeft(3, '0') + "X1";
                        break;
                    case "104":
                        PCName = "B" + listIP[2].PadLeft(3, '0') + "C" + listIP[3].PadLeft(3, '0') + "X2";
                        break;
                    case "108":
                        PCName = "B" + listIP[2].PadLeft(3, '0') + "C" + listIP[3].PadLeft(3, '0') + "X3";
                        break;
                    case "186":
                        PCName = "B" + listIP[2].PadLeft(3, '0') + "C" + listIP[3].PadLeft(3, '0') + "X4";
                        break;
                }
            }
        }

        if (Flag == 1 || string.IsNullOrEmpty(PCName))
        {
            if (ip == "10.1.3.125")
                PCName = "TP102H001";
            else if (ip == "10.1.3.126")
                PCName = "TP102H002";
            else
                PCName = "";
        }

        return PCName;
    }

    public bool IsExistGroup(string strGroupList, string strGroupId)
    {
        return strGroupList.IndexOf(strGroupId) > 0;
    }

    public string ChkAuth(string userid)
    {
        string returns;
        //ServiceClient SC = new ServiceClient();
        //returns = SC.GetData("BDMS");
        returns = "BDMS";        
        return returns;
    }

    /*BASE64編碼*/
    public static String getBASE64(String s)
    {
        if (s == null)
            return null;

        byte[] bytes = System.Text.Encoding.GetEncoding("utf-8").GetBytes(s);
        return (Convert.ToBase64String(bytes));
    }

    /*BASE64解碼*/

    public static String getFromBASE64(String s)
    {
        if (s == null)
            return null;

        try
        {
            return System.Text.Encoding.GetEncoding("utf-8").GetString(Convert.FromBase64String(s));

        }
        catch (Exception e)
        {
            return null;
        }
    }
    public DataTable init_layout(string ostype)
    {
        string osname = "";
        DataRow dr;
        using (DataTable dt = new DataTable("Layout"))
        {
            dt.Columns.Add("OSNAME");
            dt.Columns.Add("type");
            dt.Columns.Add("columnname");
            dt.Columns.Add("columndesc");
            dt.Columns.Add("columndwidth");
            dt.Columns.Add("columnsplit");
            dt.Columns.Add("columnalign");
            #region Disks
            if (ostype.ToLower().Contains("solaris"))
            {
                osname = "Solaris";
                //DISKS
                dr = dt.NewRow();
                dr["OSNAME"] = osname;
                dr["type"] = "Disks";
                dr["columnname"] = "mountpt,name,total,free,usedpcnt";
                dr["columndesc"] = "檔案系統,磁碟,容量,可用空間,已使用百分比(%)";
                dr["columndwidth"] = "10%,15%,10%,10%,12%";
                dr["columnalign"] = "L,L,R,R,R";
                
                dt.Rows.Add(dr);
            }
            else if (ostype.ToLower().Contains("linux"))
            {
                osname = "linux";
                dr = dt.NewRow();
                dr["OSNAME"] = osname;
                dr["type"] = "Disks";
                dr["columnname"] = "mountpt,name,total,free,usedpcnt";
                dr["columndesc"] = "檔案系統,磁碟,容量,可用空間,已使用百分比(%)";
                dr["columndwidth"] = "10%,15%,10%,10%,12%";
                dr["columnalign"] = "L,L,R,R,R";
                dt.Rows.Add(dr);
            }
            else
            {
                osname = "Default";
                dr = dt.NewRow();
                dr["OSNAME"] = osname;
                dr["type"] = "Disks";
                dr["columnname"] = "mountpt,name,total,free,usedpcnt";
                dr["columndesc"] = "檔案系統,磁碟,容量,可用空間,已使用百分比(%)";
                dr["columndwidth"] = "10%,15%,10%,10%,12%";
                dr["columnalign"] = "L,L,R,R,R";
                dt.Rows.Add(dr);
            }
            #endregion
            #region Services
            osname = "Default";
            dr = dt.NewRow();
            dr["OSNAME"] = osname;
            dr["type"] = "Services";
            dr["columnname"] = "name,desc,runtype";
            dr["columndesc"] = "服務名稱,說明,啟動類型";
            dr["columndwidth"] = "20%,40%,10%";
            dt.Rows.Add(dr);
            #endregion
            #region ServicesNecessary
            osname = "Default";
            dr = dt.NewRow();
            dr["OSNAME"] = osname;
            dr["type"] = "ServicesNecessary";
            dr["columnname"] = "ServicesName";
            dr["columndesc"] = "服務名稱";
            dr["columndwidth"] = "50%";
            dt.Rows.Add(dr);
            #endregion
            #region Process
            osname = "Default";
            dr = dt.NewRow();
            dr["OSNAME"] = osname;
            dr["type"] = "Process";
            dr["columnname"] = "ProcessName,status";
            dr["columndesc"] = "程序,是否啟動";
            dr["columndwidth"] = "40%,10%";
            dt.Rows.Add(dr);
            #endregion
            #region Schedule
            osname = "Default";
            dr = dt.NewRow();
            dr["OSNAME"] = osname;
            dr["type"] = "Schedule";
            dr["columnname"] = "exectime,cmds,owner,userfor";
            dr["columndesc"] = "啟動時間,執行程式,執行帳戶,用途";
            dr["columndwidth"] = "20%,40%,15%,20%";
            dt.Rows.Add(dr);
            #endregion
            #region WebServerInfo
            osname = "Default";
            dr = dt.NewRow();
            dr["OSNAME"] = osname;
            dr["type"] = "WebServerInfo";
            dr["columnname"] = "type,desc";
            dr["columndesc"] = "名稱,說明";
            dr["columndwidth"] = "20%,20%";
            dt.Rows.Add(dr);
            #endregion
            #region WebServerInfoN
            osname = "Default";
            dr = dt.NewRow();
            dr["OSNAME"] = osname;
            dr["type"] = "WebServerInfoN";
            dr["columnname"] = "type,conf,desc";
            dr["columndesc"] = "名稱,路徑,說明";
            dr["columndwidth"] = "10%,20%,10%";
            dt.Rows.Add(dr);
            #endregion
            #region SystemConfigs
            osname = "Default";
            dr = dt.NewRow();
            dr["OSNAME"] = osname;
            dr["type"] = "SystemConfigs";
            dr["columnname"] = "path,access,owner";
            dr["columndesc"] = "檔案路徑,存取權限,擁有者";
            dr["columndwidth"] = "30%,20%,13%";
            dt.Rows.Add(dr);
            #endregion
            #region Packages
            osname = "Default";
            dr = dt.NewRow();
            dr["OSNAME"] = osname;
            dr["type"] = "Packages";
            dr["columnname"] = "name,ver,status";
            dr["columndesc"] = "名稱,版本,是否符合";
            dr["columndwidth"] = "40%,20%,10%";
            dt.Rows.Add(dr);
            #endregion
            #region Policie
            osname = "Default";
            dr = dt.NewRow();
            dr["OSNAME"] = osname;
            dr["type"] = "Policie_root";
            dr["columnname"] = "name,value";
            dr["columndesc"] = "原則,最低限度設定";
            dr["columndwidth"] = "50%,50%";
            dt.Rows.Add(dr);

            osname = "Default";
            dr = dt.NewRow();
            dr["OSNAME"] = osname;
            dr["type"] = "Policie_important";
            dr["columnname"] = "name,value";
            dr["columndesc"] = "原則,系統現況";
            dr["columndwidth"] = "50%,50%";
            dt.Rows.Add(dr);

            osname = "Default";
            dr = dt.NewRow();
            dr["OSNAME"] = osname;
            dr["type"] = "Policie_guest";
            dr["columnname"] = "name,value";
            dr["columndesc"] = "原則,狀態";
            dr["columndwidth"] = "50%,50%";
            dt.Rows.Add(dr);
            #endregion
            #region Users
            osname = "Default";
            dr = dt.NewRow();
            dr["OSNAME"] = osname;
            dr["type"] = "Users";
            dr["columnname"] = "name,id,sh,grps";
            dr["columndesc"] = "使用者,ID,登入Shell,所屬使用者群組";
            dr["columndwidth"] = "20%,20%,30%,30%";
            dr["columnalign"] = "L,R,L,L";
            dt.Rows.Add(dr);
            #endregion
            #region Groups
            osname = "Default";
            dr = dt.NewRow();
            dr["OSNAME"] = osname;
            dr["type"] = "Groups";
            dr["columnname"] = "name,id,users";
            dr["columndesc"] = "使用者群組,ID,群組成員";
            dr["columndwidth"] = "20%,10%,30%";
            dr["columnsplit"] = "users";
            dr["columnalign"] = "L,R,L";
            dt.Rows.Add(dr);
            #endregion
            #region RootAccess
            osname = "Default";
            dr = dt.NewRow();
            dr["OSNAME"] = osname;
            dr["type"] = "RootAccess";
            dr["columnname"] = "name,type,access,owner,userfor";
            dr["columndesc"] = "檔案路徑,type,權限,擁有者,用途";
            dr["columndwidth"] = "30%,15%,20%,20%,20%";
            dt.Rows.Add(dr);
            #endregion

            return dt;
        }

    }

}

/// <summary>
/// 使用 RNGCryptoServiceProvider 產生由密碼編譯服務供應者 (CSP) 提供的亂數產生器。
/// </summary>
public static class RNG
{
    private static RNGCryptoServiceProvider rngp = new RNGCryptoServiceProvider();
    private static byte[] rb = new byte[4];

    /// <summary>
    /// 產生一個非負數的亂數
    /// </summary>
    public static int Next()
    {
        rngp.GetBytes(rb);
        int value = BitConverter.ToInt32(rb, 0);
        if (value < 0) value = -value;
        return value;
    }
    /// <summary>
    /// 產生一個非負數且最大值 max 以下的亂數
    /// </summary>
    /// <param name="max">最大值</param>
    public static int Next(int max)
    {
        rngp.GetBytes(rb);
        int value = BitConverter.ToInt32(rb, 0);
        value = value % (max + 1);
        if (value < 0) value = -value;
        return value;
    }
    /// <summary>
    /// 產生一個非負數且最小值在 min 以上最大值在 max 以下的亂數
    /// </summary>
    /// <param name="min">最小值</param>
    /// <param name="max">最大值</param>
    public static int Next(int min, int max)
    {
        int value = Next(max - min) + min;
        return value;
    }
}