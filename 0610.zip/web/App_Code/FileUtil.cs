﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;


using NPOI.XSSF.UserModel;
using NPOI.XSSF.Util;
using NPOI.SS.UserModel;
//using LinqToExcel;
//using Remotion;
using System.Text;
using NPOI.HSSF.UserModel;

/// <summary>
/// FileUtil 的摘要描述
/// </summary>
public class FileUtil
{
    //public static void DownloadFile(string FileApplicationPath, string FileName)
    //{
    //    try
    //    {
    //        HttpContext.Current.Response.ClearHeaders();
    //        HttpContext.Current.Response.Clear();
    //        HttpContext.Current.Response.Expires = 0;
    //        HttpContext.Current.Response.Buffer = true;
    //        //HttpContext.Current.Response.AddHeader("content-disposition", "attachment; filename="
    //        //    + Convert.ToChar(34)
    //        //    + System.Web.HttpUtility.UrlPathEncode(FileName)
    //        //    + Convert.ToChar(34));
    //        HttpContext.Current.Response.AddHeader("Content-Disposition", string.Format("attachment;filename={0}", FileName));
    //        HttpContext.Current.Response.Charset = "utf-8";
    //        HttpContext.Current.Response.ContentType = "application/vnd.ms-excel";
    //        HttpContext.Current.Response.WriteFile(HttpUtility.HtmlEncode((FileApplicationPath)));
    //        HttpContext.Current.Response.Flush();
    //        HttpContext.Current.Response.End();
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }

    //}
    //public void CreateExcel(DataTable Dt, string excelName, string ReportName, string ReportID, string DEPT, string User)
    //{
    //    var workbook = new HSSFWorkbook();
    //    var sheetReportResult = workbook.CreateSheet("Report");
    //    try
    //    {
    //        //表頭
    //        sheetReportResult.CreateRow(0).CreateCell(7).SetCellValue("彰化銀行");
    //        sheetReportResult.CreateRow(1).CreateCell(7).SetCellValue(ReportName);
    //        //
    //        sheetReportResult.CreateRow(2).CreateCell(0).SetCellValue("分行代號 ");
    //        sheetReportResult.GetRow(2).CreateCell(1).SetCellValue(DEPT);
    //        sheetReportResult.GetRow(2).CreateCell(15).SetCellValue("印表日期");
    //        sheetReportResult.GetRow(2).CreateCell(16).SetCellValue(DateTime.Now.ToString("yyyy/MM/dd"));
    //        //
    //        sheetReportResult.CreateRow(3).CreateCell(0).SetCellValue("印表人員 ");
    //        sheetReportResult.GetRow(3).CreateCell(1).SetCellValue(User);
    //        sheetReportResult.GetRow(3).CreateCell(15).SetCellValue("印表時間");
    //        sheetReportResult.GetRow(3).CreateCell(16).SetCellValue(DateTime.Now.ToString("HH:mm:ss"));
    //        //
    //        sheetReportResult.CreateRow(4).CreateCell(0).SetCellValue("報表代號 ");
    //        sheetReportResult.GetRow(4).CreateCell(1).SetCellValue(ReportID);


    //        //資料欄位名稱
    //        int k = 0;
    //        foreach (DataColumn Columns in Dt.Columns)
    //        {
    //            string key;
    //            key = Resources.Language.ResourceManager.GetString(Columns.ColumnName.Replace("_", ""));
    //            if (k == 0)
    //            {
    //                sheetReportResult.CreateRow(6).CreateCell(k).SetCellValue(key);
    //            }
    //            else
    //            {
    //                sheetReportResult.GetRow(6).CreateCell(k).SetCellValue(key);
    //            }
    //            k++;
    //        }

    //        int j = 7;
    //        string str_col = "";


    //        foreach (DataRow DR in Dt.Rows)
    //        {
    //            for (int i = 0; i < Dt.Columns.Count; i++)
    //            {
    //                str_col = DR[i].ToString();
    //                if (i == 0)
    //                {
    //                    sheetReportResult.CreateRow(j).CreateCell(i).SetCellValue(str_col);
    //                }
    //                else
    //                {
    //                    sheetReportResult.GetRow(j).CreateCell(i).SetCellValue(str_col);
    //                }

    //            }
    //            j++;
    //        }

    //        string file_path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "export", excelName);
    //        MemoryStream file = new MemoryStream();
    //        workbook.Write(file);
            
    //        FileStream fs = new FileStream(file_path, FileMode.Create, FileAccess.Write);
    //        byte[] data = file.ToArray();

    //        fs.Write(data, 0, data.Length);
    //        fs.Flush();
    //        fs.Close();

    //        data = null;
    //        file = null;
    //        fs = null;

    //        //DownloadFile(FileName, "123");
            
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }



    //}
    public static DataTable ReadExcelAsTableNPOI(string fileName)
    {
        using (FileStream fs = new FileStream(fileName, FileMode.Open))
        {
            IWorkbook wb;
            if (fileName.Split('.').Last().ToLower() == "xls")
            {
                wb = new HSSFWorkbook(fs);
            }
            else
            {
                wb = new XSSFWorkbook(fs);
            }
            ISheet sheet = wb.GetSheetAt(0);
            DataTable table = new DataTable();
            //由第一列取標題做為欄位名稱
            IRow headerRow = sheet.GetRow(0);
            int cellCount = headerRow.LastCellNum;
            for (int i = headerRow.FirstCellNum; i < cellCount; i++)
                //以欄位文字為名新增欄位，此處全視為字串型別以求簡化
                table.Columns.Add(
                    new DataColumn(headerRow.GetCell(i).StringCellValue));

            //略過第零列(標題列)，一直處理至最後一列
            for (int i = (sheet.FirstRowNum + 1); i <= sheet.LastRowNum; i++)
            {
                IRow row = sheet.GetRow(i);
                if (row == null) continue;
                DataRow dataRow = table.NewRow();
                //依先前取得的欄位數逐一設定欄位內容
                for (int j = row.FirstCellNum; j < cellCount; j++)
                    if (row.GetCell(j) != null)
                        //如要針對不同型別做個別處理，可善用.CellType判斷型別
                        //再用.StringCellValue, .DateCellValue, .NumericCellValue...取值
                        //此處只簡單轉成字串
                        dataRow[j] = row.GetCell(j).ToString();
                table.Rows.Add(dataRow);
            }
            return table;
        }
    }
}