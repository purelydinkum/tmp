﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using System.Configuration;
using System.Data;
using System.IO;
using System.Resources;

public partial class Comm_PrintPdf_Unix : CallbackPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["DataKey"] == null)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Comm_OutputExcel", "alert('查詢資料不存在！');window.close()", true);
            return;
        }


        string Datakey = Session["DataKey"].ToString();
        try
        {
            
            CreatePDF(Datakey);
        }
        catch (Exception ex)
        {
            //base.JsAlert(ex.Message);
            Response.Write(ex.Message);
            Response.Flush();
            Response.End();
            
        }
    }

    public string OSNAME = "";
    public string IS_Process = "", IS_ServicesNecessary = "", IS_TaskList = "", IS_WebServerInfo = "";
    protected void CreatePDF(string DataKey)
    {

        try
        {
            //更新Print Date
            string strMessage;
            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection Params = new ParameterCollection();
            string strSQL = @"UPDATE [dbo].[SecurityScanUList]
                               SET [PrintDate] = getdate()
                                  ,[UpdUser] = @UpdUser
                                  ,[UpdDateTime] = getdate()
                       where DataKey = @DataKey";
            Params.Add("DataKey", DbType.String, DataKey);
            Params.Add("UpdUser", DbType.String, GUserInfo.UserId);
            da.AddSql(strSQL, Params);
            if (da.ExecuteNonQueryTrans())
            {
                strMessage = string.Format(Resources.Language.MSG0026, Resources.Language.Updated);

            }
            else
            {
                strMessage = string.Format(Resources.Language.MSG0009, Resources.Language.Updated);
            }

            string[] Header = new string[10];
            Header = GetHeader(DataKey);


            Document doc1 = new Document(PageSize.A4, 5, 5, 25, 35);

            MemoryStream Memory = new MemoryStream();
            PdfWriter writer = PdfWriter.GetInstance(doc1, Memory);

            string fontPath = Environment.GetFolderPath(Environment.SpecialFolder.System) + @"\..\Fonts\kaiu.ttf";
            BaseFont bfChinese = BaseFont.CreateFont(
                fontPath,
                BaseFont.IDENTITY_H, //橫式中文
                BaseFont.NOT_EMBEDDED
                );

            Font ChFontHead = new Font(bfChinese, 36, Font.BOLD, Color.BLACK);
            Font ChREAD = new Font(bfChinese, 10, Font.NORMAL, Color.RED);
            Font ChFont = new Font(bfChinese, 7);

            TwoColumnHeaderFooter PageEventHandler = new TwoColumnHeaderFooter();
            writer.PageEvent = PageEventHandler;

            // Define the page header
            PageEventHandler.Title = Title;
            //需加判斷登入者為管理者才有footer ，且需重參數檔帶入
            if (base.GUserInfo.RoleId == "admins")
            {
                PageEventHandler.FooterText = Header[3];
            }
            else
            {
                PageEventHandler.FooterText = "";
            }
            ChFontHead = new Font(bfChinese, 36, Font.BOLD, Color.BLACK);

            //PageEventHandler.HeaderFont = FontFactory.GetFont(BaseFont.COURIER_BOLD, 10, Font.BOLD);
            //PageEventHandler.HeaderLeft = "Group";
            //PageEventHandler.HeaderRight = "1";

            doc1.Open();

            Paragraph alignAndLeadingPara = new Paragraph();
            alignAndLeadingPara.Leading = 20; //設定行距（每行之間的距離） 
            alignAndLeadingPara.Alignment = Element.ALIGN_CENTER;

            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            ChFontHead = new Font(bfChinese, 36, Font.BOLD, Color.BLACK);
            alignAndLeadingPara.Add(new Phrase("台灣土地銀行", ChFontHead));
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");

            ChFontHead = new Font(bfChinese, 30);
            alignAndLeadingPara.Add(new Phrase(Header[1], ChFontHead));
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add(new Phrase("作業環境安全控管設定說明文件", ChFontHead));
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add(new Phrase("主機名稱：" + Header[0], ChFontHead));
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            alignAndLeadingPara.Add("\n");
            doc1.Add(alignAndLeadingPara);
            alignAndLeadingPara = new Paragraph();
            alignAndLeadingPara.IndentationLeft = 160f;
            alignAndLeadingPara.Add(new Phrase("回報時間：" + Header[2], new Font(bfChinese, 16)));
            alignAndLeadingPara.Add(Chunk.NEWLINE);
            doc1.Add(alignAndLeadingPara);
            alignAndLeadingPara = new Paragraph();
            alignAndLeadingPara.IndentationLeft = 160f;
            alignAndLeadingPara.Add(new Phrase("列印時間：" + Header[4], new Font(bfChinese, 16)));
            doc1.Add(alignAndLeadingPara);

            
            doc1.NewPage();
            alignAndLeadingPara = new Paragraph();
            alignAndLeadingPara.Leading = 20; //設定行距（每行之間的距離） 
            alignAndLeadingPara.Alignment = Element.ALIGN_LEFT;

            ChFontHead = new Font(bfChinese, 16);
            alignAndLeadingPara.Add(new Phrase("一、基本安全設定原則", new Font(bfChinese, 16)));
            
            doc1.Add(alignAndLeadingPara);


            Paragraph p = new Paragraph();
            
            //碟磁分割資訊
            alignAndLeadingPara = new Paragraph();
            alignAndLeadingPara.Leading = 16; //設定行距（每行之間的距離） 
            alignAndLeadingPara.Alignment = Element.ALIGN_LEFT;
            ChFontHead = new Font(bfChinese, 16);
            
            alignAndLeadingPara.Add("\n");
            doc1.Add(alignAndLeadingPara);

            p = new Paragraph();
            
            p.IndentationLeft = 10f;
            p.Add(new Phrase("(一) 作業系統資訊", new Font(bfChinese, 14)));
            p.Add(Chunk.NEWLINE);
            p.Add(Chunk.NEWLINE);
            doc1.Add(p);
           
            p = new Paragraph();
            p.IndentationLeft = 8;
            p.Add(OS(DataKey));
            doc1.Add(p);

            p = new Paragraph();

            //碟磁分割資訊
            alignAndLeadingPara = new Paragraph();
            alignAndLeadingPara.Leading = 16; //設定行距（每行之間的距離） 
            alignAndLeadingPara.Alignment = Element.ALIGN_LEFT;
            ChFontHead = new Font(bfChinese, 16);

            alignAndLeadingPara.Add("\n");
            doc1.Add(alignAndLeadingPara);

            p = new Paragraph();

            p.IndentationLeft = 10f;
            p.Add(new Phrase("(二) 磁碟分割資訊", new Font(bfChinese, 14)));
            p.Add(Chunk.NEWLINE);
            p.Add(Chunk.NEWLINE);
            doc1.Add(p);

            p = new Paragraph();
            p.IndentationLeft = 8;
            p.Add(Disk(DataKey));
            doc1.Add(p);


            ////doc1.NewPage();
            //4主機服務及排程工作資訊
            //服務
           
            p = new Paragraph();
            p.IndentationLeft = 10f;
            p.Add(new Phrase("(二) 主機服務及排程工作資訊", new Font(bfChinese, 14)));
            p.Add(Chunk.NEWLINE);
            p.Add(Chunk.NEWLINE);
            doc1.Add(p);
            
            p = new Paragraph();
            p.IndentationLeft = 20f;
            p.Add(new Phrase("※服務清單", new Font(bfChinese, 12)));
            p.Add(Chunk.NEWLINE);
            p.Add(Chunk.NEWLINE);
            doc1.Add(p);
            p = new Paragraph();
            p.IndentationLeft = 8;
            p.Add(ServiceList(DataKey));
            doc1.Add(p);


            //未安裝必要服務
            PdfPTable ServicesNecessary_P = ServicesNecessary(DataKey);
            if (IS_ServicesNecessary == "Y")
            {
                p = new Paragraph();
                p.Add(Chunk.NEWLINE);
                p.Add(Chunk.NEWLINE);
                p.IndentationLeft = 20f;
                p.Add(new Phrase("※未安裝必要服務", new Font(bfChinese, 12)));
                p.Add(Chunk.NEWLINE);
                p.Add(Chunk.NEWLINE);
                doc1.Add(p);
                p = new Paragraph();
                p.IndentationLeft = 8;
                p.Add(ServicesNecessary_P);
                doc1.Add(p);      
            }
            
                  
            //正在執行程序查詢
            PdfPTable Process_P = ProcesseList(DataKey);
            if (IS_Process == "Y")
            {
                p = new Paragraph();
                p.Add(Chunk.NEWLINE);
                p.Add(Chunk.NEWLINE);
                p.IndentationLeft = 20f;
                p.Add(new Phrase("※正在執行程式", new Font(bfChinese, 12)));
                p.Add(Chunk.NEWLINE);
                p.Add(Chunk.NEWLINE);
                doc1.Add(p);
                p = new Paragraph();
                p.IndentationLeft = 8;
                p.Add(Process_P);
                doc1.Add(p);
            }


            //工作排程清單
            //PdfPTable TaskList_P = TaskList(DataKey);
            PdfPTable TaskList_P = TaskList_New(DataKey);
            p = new Paragraph();
            p.IndentationLeft = 20f;
            p.Add(new Phrase("※排程清單", new Font(bfChinese, 12)));
            p.Add(Chunk.NEWLINE);
            p.Add(Chunk.NEWLINE);
            doc1.Add(p);
            p = new Paragraph();
            p.IndentationLeft = 8;
            p.Add(TaskList_P);
            doc1.Add(p);


            //WEB應用程式
            PdfPTable WebServerInfo_P = WebServerInfo(DataKey);
            p = new Paragraph();
            p.IndentationLeft = 20f;
            p.Add(new Phrase("※網站服務", new Font(bfChinese, 12)));
            p.Add(Chunk.NEWLINE);
            p.Add(Chunk.NEWLINE);
            doc1.Add(p);
            if (IS_WebServerInfo == "Y")
            {
                p = new Paragraph();
                p.IndentationLeft = 8;
                p.Add(WebServerInfo_P);
                doc1.Add(p);
            }
            else
            {
                p = new Paragraph();
                p.IndentationLeft = 8;
                p.IndentationLeft = 20f;
                p.Add(new Phrase("***無WebSphere或Apache服務", ChREAD));
                p.Add(Chunk.NEWLINE);
                p.Add(Chunk.NEWLINE);
                doc1.Add(p);
            }

            //3保護檔案及目錄
            p = new Paragraph();
            p.IndentationLeft = 10f;
            p.Add(new Phrase("(三) 系統檔案存取權限管理", new Font(bfChinese, 14)));
            p.Add(Chunk.NEWLINE);
            p.Add(Chunk.NEWLINE);
            doc1.Add(p);

            PdfPTable ShareFolders_p = SystemConfigs(DataKey);
            p = new Paragraph();
            p.IndentationLeft = 8;
            p.Add(ShareFolders_p);
            doc1.Add(p);

            p = new Paragraph();
            p.IndentationLeft = 10f;
            p.Add(new Phrase("(四) 已安裝套件資訊", new Font(bfChinese, 14)));
            p.Add(Chunk.NEWLINE);
            p.Add(Chunk.NEWLINE);
            doc1.Add(p);
                        
            p = new Paragraph();
            p.IndentationLeft = 20f;
            p.Add(new Phrase("※已安裝套件", new Font(bfChinese, 12)));
            p.Add(Chunk.NEWLINE);
            p.Add(Chunk.NEWLINE);
            doc1.Add(p);
            
            p = new Paragraph();
            p.IndentationLeft = 8;
            p.Add(Package(DataKey));
            doc1.Add(p);

            p = new Paragraph();
            p.IndentationLeft = 10f;
            p.Add(new Phrase("(五) 作業系統安全性設定", new Font(bfChinese, 14)));
            p.Add(Chunk.NEWLINE);
            p.Add(Chunk.NEWLINE);
            doc1.Add(p);

            p = new Paragraph();
            p.IndentationLeft = 20f;
            p.Add(new Phrase("※重要系統參數檢查項目", new Font(bfChinese, 12)));
            p.Add(Chunk.NEWLINE);
            p.Add(Chunk.NEWLINE);
            doc1.Add(p);

            PdfPTable Policy_p = Policy(DataKey, "important");
            doc1.Add(Policy_p);

            p = new Paragraph();
            p.IndentationLeft = 20f;
            p.Add(new Phrase("※ROOT 管控原則", new Font(bfChinese, 12)));
            p.Add(Chunk.NEWLINE);
            p.Add(Chunk.NEWLINE);
            doc1.Add(p);

            p = new Paragraph();
            p.IndentationLeft = 8;
            Policy_p = Policy(DataKey, "root");
            doc1.Add(Policy_p);

            Policy_p = Policy(DataKey, "guest");
            if(Policy_p.Rows.Count != 0)
            {
                p = new Paragraph();
                p.IndentationLeft = 20f;
                p.Add(new Phrase("※Guest帳戶狀態", new Font(bfChinese, 12)));
                p.Add(Chunk.NEWLINE);
                p.Add(Chunk.NEWLINE);
                doc1.Add(p);

                p = new Paragraph();
                p.IndentationLeft = 8;
                doc1.Add(Policy_p);
            }


            doc1.NewPage();

            //5本機使用者及群組清單
            p = new Paragraph();
            p.Add(Chunk.NEWLINE);
            p.Add(new Phrase("二、本機使用者及群組清單", new Font(bfChinese, 16)));
            p.Add(Chunk.NEWLINE);
            p.Add(Chunk.NEWLINE);
            doc1.Add(p);

            p = new Paragraph();
            p.IndentationLeft = 10f;
            p.Add(new Phrase("※使用者清單", new Font(bfChinese, 14)));
            p.Add(Chunk.NEWLINE);
            p.Add(Chunk.NEWLINE);
            doc1.Add(p);
            
            p = new Paragraph();
            p.IndentationLeft = 8;
            p.Add(UserList(DataKey));
            doc1.Add(p);

            //使用者群組清單
            p = new Paragraph();
            p.IndentationLeft = 10f;
            p.Add(new Phrase("※使用者群組", new Font(bfChinese, 14)));
            p.Add(Chunk.NEWLINE);
            p.Add(Chunk.NEWLINE);
            doc1.Add(p);
                        
            p = new Paragraph();
            p.IndentationLeft = 8;
            p.Add(UserGroupList(DataKey));
            doc1.Add(p);

            //6目錄檔案存取權限
            p = new Paragraph();
            p.Add(Chunk.NEWLINE);
            p.Add(new Phrase("三、目錄檔案存取權限", new Font(bfChinese, 16)));
            p.Add(Chunk.NEWLINE);
            p.Add(Chunk.NEWLINE);
            doc1.Add(p);
            
            p = new Paragraph();
            p.IndentationLeft = 10f;
            p.Add(new Phrase("※目錄檔案存取權限", new Font(bfChinese, 14)));
            p.Add(Chunk.NEWLINE);
            p.Add(Chunk.NEWLINE);
            doc1.Add(p);

           
            p = new Paragraph();
            p.IndentationLeft = 8;
            p.Add(RootAccess(DataKey));
            doc1.Add(p);
                        
            doc1.Close();

            string pdfName = MACHINENAME + "_SecurityReport" + DateTime.Now.ToString("yyyyMMdd") + ".pdf";
            Response.Clear();

            HttpContext.Current.Response.AddHeader("Content-Disposition", string.Format("attachment;filename={0}", pdfName));
            HttpContext.Current.Response.ContentType = "octet-stream";
            Response.OutputStream.Write(Memory.GetBuffer(), 0, Memory.GetBuffer().Length);
            Response.OutputStream.Flush();
            Response.OutputStream.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected string[] GetHeader(string DataKey)
    {
        string[] Header = new string[10];
        try
        {
            string strSQL = @"SELECT A.PCID,A.PCFULLNAME,
                            A.DESCR,
                            A.SCANDATE,
                            B.ParameterValue,
                            A.PrintDate
                            FROM SecurityScanUList A left join (select ParameterValue  from SystemCodes_Config  where Class = 'FT') B on 1=1
                            WHERE DataKey = @DataKey";
            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {
                    Header[0] = Convert.ToString(dv["PCID"]);
                    Header[1] = Convert.ToString(dv["DESCR"]);
                    Header[2] = Convert.ToString(dv["SCANDATE"]);
                    Header[3] = Convert.ToString(dv["ParameterValue"]);
                    Header[4] = Convert.ToString(dv["PrintDate"]);
                }
            }
        }
        catch (Exception ex)
        {
        }


        return Header;
    }
    protected PdfPTable OS(string DataKey)
    {
        //讀取相關資料
        PdfPTable table = new PdfPTable(new float[] { 60, 80, 80, 80 });
        try
        {
            string strSQL = @"SELECT A.PCID,A.PCFULLNAME,
                            A.DomainName,
                            A.OSNAME,
                            A.OSSP,
                            Convert(varchar(20),A.HOTFIX_LASTDATE,120) HOTFIX_LASTDATE,
                            A.MANUFACTURER,
                            A.MODEL
                            FROM SecurityScanUList A 
                            WHERE DataKey = @DataKey";



            string fontPath = Environment.GetFolderPath(Environment.SpecialFolder.System) + @"\..\Fonts\kaiu.ttf";
            BaseFont bfChinese = BaseFont.CreateFont(
                fontPath,
                BaseFont.IDENTITY_H, //橫式中文
                BaseFont.NOT_EMBEDDED
                );

            Font ChFont = new Font(bfChinese, 12);
            Font ChHead = new Font(bfChinese, 12, Font.BOLD, Color.BLACK);

            table.TotalWidth = 500f;
            table.LockedWidth = true;

            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);

            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {

                    PdfPCell ItemName1 = new PdfPCell(new Phrase("主機名稱：", ChHead));
                    ItemName1.MinimumHeight = 30f;
                    ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                    ItemName1.BackgroundColor = new iTextSharp.text.Color(222, 225, 231);
                    table.AddCell(ItemName1);
                    ItemName1 = new PdfPCell(new Phrase(Convert.ToString(dv["PCID"]), ChFont));
                    ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                    table.AddCell(ItemName1);
                    MACHINENAME = Convert.ToString(dv["PCID"]);


                    ItemName1 = new PdfPCell(new Phrase("作業系統版本：", ChHead));
                    ItemName1.MinimumHeight = 30f;
                    ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                    ItemName1.BackgroundColor = new iTextSharp.text.Color(222, 225, 231);
                    table.AddCell(ItemName1);
                    ItemName1 = new PdfPCell(new Phrase(Convert.ToString(dv["OSNAME"]), ChFont));
                    ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                    OSNAME = Convert.ToString(dv["OSNAME"]);
                    table.AddCell(ItemName1);

                    init(dv["OSNAME"].ToString());    
                }
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        return table;
    }
    protected PdfPTable Disk(string DataKey)
    {
        
        DataRow[] foundRows;
        foundRows = dt_Layout.Select("type = 'Disks'");
        string[] columns, columndes, columndwidth, columnalign=null;
        //讀取相關資料
        PdfPTable table = new PdfPTable(new float[] { 14,15,9,9,11 });
        try
        {
            string strSQL = @"SELECT A.name,A.fstype,A.total,A.free ,A.mountpt
                                   , A.usedpcnt
                            FROM Disks A 
                            WHERE DataKey = @DataKey ";


            string fontPath = Environment.GetFolderPath(Environment.SpecialFolder.System) + @"\..\Fonts\kaiu.ttf";
            BaseFont bfChinese = BaseFont.CreateFont(
                fontPath,
                BaseFont.IDENTITY_H, //橫式中文
                BaseFont.NOT_EMBEDDED
                );

            Font ChFont = new Font(bfChinese, 10);
            Font ChHead = new Font(bfChinese, 12, Font.BOLD, Color.BLACK);

            table.TotalWidth = 500f;
            table.LockedWidth = true;

            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            int i = 0;
            PdfPCell ItemName1;
            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {
                    if (i == 0)
                    {
                        if (foundRows.Length > 0)
                        {
                            columndes = foundRows[0]["columndesc"].ToString().Split(',');
                            columndwidth = foundRows[0]["columndwidth"].ToString().Split(',');
                            columnalign = foundRows[0]["columnalign"].ToString().Split(',');
                            float[] width = new float[columndwidth.Length];
                            int z = 0;
                            foreach (string strwidth in columndwidth)
                            {
                                width[z] = Convert.ToInt32(strwidth.Replace("%", ""));
                                z++;
                            }
                            //table = new PdfPTable(width);

                            z = 0;
                            foreach (string column in columndes)
                            {
                                
                                ItemName1 = new PdfPCell(new Phrase(column, ChHead));
                                ItemName1.MinimumHeight = 20f;
                                ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                                ItemName1.HorizontalAlignment = Element.ALIGN_CENTER;
                                ItemName1.BackgroundColor = new iTextSharp.text.Color(222, 225, 231);
                                table.AddCell(ItemName1);

                                z++;
                            }
                        }                        
                    }

                    columns = foundRows[0]["columnname"].ToString().Split(',');
                    int c = 0;
                    foreach (string column in columns)
                    {                                                
                        ItemName1 = new PdfPCell(new Phrase(Convert.ToString(dv[column]), ChFont));
                        ItemName1.MinimumHeight = 20f;
                        ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                        if (columnalign.Length > 0)
                        {
                            switch (columnalign[c])
                            {
                                case "R":
                                    ItemName1.HorizontalAlignment = Element.ALIGN_RIGHT;
                                    break;
                                case "C":
                                    ItemName1.HorizontalAlignment = Element.ALIGN_CENTER;
                                    break;
                                default:
                                    ItemName1.HorizontalAlignment = Element.ALIGN_LEFT;
                                    break;
                            }
                        }
                        else
                        {
                            ItemName1.HorizontalAlignment = Element.ALIGN_LEFT;
                        }
                        
                        table.AddCell(ItemName1);
                        c++;
                    }
                    
                    i++;
                }
            }


        }
        catch (Exception ex)
        {
            throw ex;
        }
        return table;
    }
    protected PdfPTable ServiceList(string DataKey)
    {
        DataRow[] foundRows;
        foundRows = dt_Layout.Select("type = 'Services'");
        string[] columns, columndes, columndwidth;
        //讀取相關資料
        PdfPTable table = new PdfPTable(new float[] { 20,40,10 });
        try
        {
            string strSQL = @"SELECT A.name,A.runtype
                            , E.OSType OSType,IIF (E.ServicesName is null , 'Yes', 'NO' ) status
                            , case when isnull(B.servicedesc,'') = '' then A.[desc] else B.servicedesc end [Desc]
                           from Services A left join ServiceDesc B on A.DataKey = B.DataKey and A.name = B.servicename
                                left JOIN (SELECT ServicesName,OSType FROM ServiceOptionalU ) E ON (A.name LIKE '%' + E.ServicesName + '%')
                            WHERE A.DataKey = @DataKey 
                             order by A.runtype,A.name";

            string fontPath = Environment.GetFolderPath(Environment.SpecialFolder.System) + @"\..\Fonts\kaiu.ttf";
            BaseFont bfChinese = BaseFont.CreateFont(
                fontPath,
                BaseFont.IDENTITY_H, //橫式中文
                BaseFont.NOT_EMBEDDED
                );

            Font ChFont = new Font(bfChinese, 10);
            Font ChHead = new Font(bfChinese, 12, Font.BOLD, Color.BLACK);

            Font ChREAD = new Font(bfChinese, 10, Font.NORMAL, Color.RED);

            table.TotalWidth = 500f;
            table.LockedWidth = true;

            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            int i = 0;
            PdfPCell ItemName1;
            string[] OSType = null;
            Boolean ISOSType = false;
            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {
                    if (i == 0)
                    {
                        if (foundRows.Length > 0)
                        {
                            columndes = foundRows[0]["columndesc"].ToString().Split(',');
                            columndwidth = foundRows[0]["columndwidth"].ToString().Split(',');
                            float[] width = new float[columndwidth.Length];
                            int z = 0;
                            foreach (string strwidth in columndwidth)
                            {
                                width[z] = Convert.ToInt32(strwidth.Replace("%", ""));
                                z++;
                            }
                            //table = new PdfPTable(width);

                            z = 0;
                            foreach (string column in columndes)
                            {

                                ItemName1 = new PdfPCell(new Phrase(column, ChHead));
                                ItemName1.MinimumHeight = 20f;
                                ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                                ItemName1.HorizontalAlignment = Element.ALIGN_CENTER;
                                ItemName1.BackgroundColor = new iTextSharp.text.Color(222, 225, 231);
                                table.AddCell(ItemName1);

                                z++;
                            }
                        }      



                    }

                    #region 判斷是否合規
                    OSType = dv["OSType"].ToString().ToLower().Split(';');
                    ISOSType = false;
                    if (dv["OSType"].ToString() == "")
                    {
                        ISOSType = true;
                    }
                    else
                    {
                        for (int k = 0; k < OSType.Length; k++)
                        {
                            if (OSNAME.ToLower().Contains(OSType[k]) && OSType[k] != "")
                            {
                                ISOSType = true;
                            }

                        }
                    }

                    #endregion


                    columns = foundRows[0]["columnname"].ToString().Split(',');
                    foreach (string column in columns)
                    {
                        if (column == "name")
                        {
                            string value = (ISOSType && dv["status"].ToString() == "NO" ? "***" : "") + dv[column].ToString();
                            ItemName1 = new PdfPCell(new Phrase(value, ISOSType && dv["status"].ToString() == "NO" ? ChREAD : ChFont));
                        }
                        else
                        {
                            ItemName1 = new PdfPCell(new Phrase(Convert.ToString(dv[column]), ChFont));
                        }

                        
                        ItemName1.MinimumHeight = 20f;
                        ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                        ItemName1.HorizontalAlignment = Element.ALIGN_LEFT;
                        table.AddCell(ItemName1);
                    }

                    i++;
                }
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        return table;
    }
    protected PdfPTable ServicesNecessary(string DataKey)
    {
        DataRow[] foundRows;
        foundRows = dt_Layout.Select("type = 'ServicesNecessary'");
        string[] columns, columndes, columndwidth;
        //讀取相關資料
        PdfPTable table = new PdfPTable(new float[] { 30 });
        try
        {
            string strSQL = @"select A.ServicesName,A.OSType 
                                FROM ServicesNecessaryU A 
                                where not exists(select name from Services E  WHERE DataKey =  @DataKey and E.name like '%' + A.ServicesName + '%')
                              ";

            string fontPath = Environment.GetFolderPath(Environment.SpecialFolder.System) + @"\..\Fonts\kaiu.ttf";
            BaseFont bfChinese = BaseFont.CreateFont(
                fontPath,
                BaseFont.IDENTITY_H, //橫式中文
                BaseFont.NOT_EMBEDDED
                );

            Font ChFont = new Font(bfChinese, 10);
            Font ChHead = new Font(bfChinese, 12, Font.BOLD, Color.BLACK);

            Font ChREAD = new Font(bfChinese, 10, Font.NORMAL, Color.RED);

            table.TotalWidth = 500f;
            table.LockedWidth = true;

            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            int i = 0;
            PdfPCell ItemName1;
            string[] OSType = null;
            Boolean ISOSType = false;
            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {
                    if (i == 0)
                    {
                        if (foundRows.Length > 0)
                        {
                            columndes = foundRows[0]["columndesc"].ToString().Split(',');
                            columndwidth = foundRows[0]["columndwidth"].ToString().Split(',');
                            float[] width = new float[columndwidth.Length];
                            int z = 0;
                            foreach (string strwidth in columndwidth)
                            {
                                width[z] = Convert.ToInt32(strwidth.Replace("%", ""));
                                z++;
                            }
                            //table = new PdfPTable(width);

                            z = 0;
                            foreach (string column in columndes)
                            {

                                ItemName1 = new PdfPCell(new Phrase(column, ChHead));
                                ItemName1.MinimumHeight = 20f;
                                ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                                ItemName1.HorizontalAlignment = Element.ALIGN_CENTER;
                                ItemName1.BackgroundColor = new iTextSharp.text.Color(222, 225, 231);
                                table.AddCell(ItemName1);

                                z++;
                            }
                        }



                    }

                    #region 判斷是否合規
                    OSType = dv["OSType"].ToString().ToLower().Split(';');
                    ISOSType = false;
                    if (dv["OSType"].ToString() == "")
                    {
                        ISOSType = true;
                    }
                    else
                    {
                        for (int k = 0; k < OSType.Length; k++)
                        {
                            if (OSNAME.ToLower().Contains(OSType[k]) && OSType[k] != "")
                            {
                                ISOSType = true;
                            }

                        }
                    }
                    #endregion


                    if (ISOSType)
                    {
                        IS_ServicesNecessary = "Y";
                        columns = foundRows[0]["columnname"].ToString().Split(',');
                        foreach (string column in columns)
                        {
                            ItemName1 = new PdfPCell(new Phrase(Convert.ToString("***" + dv[column]), ChREAD));
                            ItemName1.MinimumHeight = 20f;
                            ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                            ItemName1.HorizontalAlignment = Element.ALIGN_LEFT;
                            table.AddCell(ItemName1);
                        }
                    }
                    i++;
                }
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        return table;
    }
    protected PdfPTable ProcesseList(string DataKey)
    {
        DataRow[] foundRows;
        foundRows = dt_Layout.Select("type = 'Process'");
        string[] columns, columndes, columndwidth;
        //讀取相關資料
        PdfPTable table = new PdfPTable(new float[] { 40,10 });
        try
        {
            string strSQL = @"select distinct ProcessName, A.OSType, IIF (E.DataKey is null , 'NO', 'Yes' ) status
                                from [dbo].[ProcessNecessaryU]  A 
                                left join  (select  DataKey,runcmd from [Processes]  where DataKey=@DataKey ) E on E.runcmd LIKE '%' + a.ProcessName + '%' 
                              order by A.ProcessName
                           ";

            string fontPath = Environment.GetFolderPath(Environment.SpecialFolder.System) + @"\..\Fonts\kaiu.ttf";
            BaseFont bfChinese = BaseFont.CreateFont(
                fontPath,
                BaseFont.IDENTITY_H, //橫式中文
                BaseFont.NOT_EMBEDDED
                );

            Font ChFont = new Font(bfChinese, 10);
            Font ChHead = new Font(bfChinese, 12, Font.BOLD, Color.BLACK);

            Font ChREAD = new Font(bfChinese, 10, Font.NORMAL, Color.RED);

            table.TotalWidth = 500f;
            table.LockedWidth = true;

            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            int i = 0;
            PdfPCell ItemName1;
            string[] OSType = null;
            Boolean ISOSType = false;
            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {
                    if (i == 0)
                    {
                        if (foundRows.Length > 0)
                        {
                            columndes = foundRows[0]["columndesc"].ToString().Split(',');
                            columndwidth = foundRows[0]["columndwidth"].ToString().Split(',');
                            float[] width = new float[columndwidth.Length];
                            int z = 0;
                            foreach (string strwidth in columndwidth)
                            {
                                width[z] = Convert.ToInt32(strwidth.Replace("%", ""));
                                z++;
                            }
                            //table = new PdfPTable(width);

                            z = 0;
                            foreach (string column in columndes)
                            {
                                
                                ItemName1 = new PdfPCell(new Phrase(column, ChHead));
                                ItemName1.MinimumHeight = 20f;
                                ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                                ItemName1.HorizontalAlignment = Element.ALIGN_CENTER;
                                ItemName1.BackgroundColor = new iTextSharp.text.Color(222, 225, 231);
                                table.AddCell(ItemName1);

                                z++;
                            }
                        }

                    }

                    #region 判斷是否合規
                    OSType = dv["OSType"].ToString().ToLower().Split(';');
                    ISOSType = false;
                    if (dv["OSType"].ToString() == "")
                    {
                        ISOSType = true;
                    }
                    else
                    {
                        for (int k = 0; k < OSType.Length; k++)
                        {
                            if (OSNAME.ToLower().Contains(OSType[k]) && OSType[k] != "")
                            {
                                ISOSType = true;
                            }

                        }
                    }

                    #endregion
                    IS_Process = "Y";
                    columns = foundRows[0]["columnname"].ToString().Split(',');
                    foreach (string column in columns)
                    {
                        if (column == "ProcessName" )
                        {
                            string value = (ISOSType && dv["status"].ToString() == "NO" ? "***" : "") + dv[column].ToString();
                            ItemName1 = new PdfPCell(new Phrase(value, ISOSType && dv["status"].ToString() == "NO" ? ChREAD : ChFont));
                        }
                        else
                        {
                            ItemName1 = new PdfPCell(new Phrase(Convert.ToString(dv[column]), ChFont));
                        }
                        ItemName1.MinimumHeight = 20f;
                        ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                        ItemName1.HorizontalAlignment = Element.ALIGN_LEFT;
                        table.AddCell(ItemName1);
                    }

                    i++;
                }
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        return table;
    }
    protected PdfPTable TaskList(string DataKey)
    {
        DataRow[] foundRows;
        foundRows = dt_Layout.Select("type = 'Schedule'");
        string[] columns, columndes, columndwidth;
        //讀取相關資料
        PdfPTable table = new PdfPTable(new float[] { 30 });
        IS_TaskList = "";
        
        try
        {
            string strSQL = @"SELECT A.exectime,A.cmds,A.owner
                                   , case when isnull(B.taskdesc,'') = '' then A.userfor else B.taskdesc end userfor
                            FROM Schedule A left join TaskDesc B on A.DataKey = B.DataKey and A.cmds = B.taskname
                            WHERE A.DataKey = @DataKey 
                            order by A.cmds,A.exectime";

            string fontPath = Environment.GetFolderPath(Environment.SpecialFolder.System) + @"\..\Fonts\kaiu.ttf";
            BaseFont bfChinese = BaseFont.CreateFont(
                fontPath,
                BaseFont.IDENTITY_H, //橫式中文
                BaseFont.NOT_EMBEDDED
                );

            Font ChFont = new Font(bfChinese, 10);
            Font ChHead = new Font(bfChinese, 12, Font.BOLD, Color.BLACK);

            table.TotalWidth = 500f;
            table.LockedWidth = true;

            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            int i = 0;
            PdfPCell ItemName1;
            
            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {
                    IS_TaskList = "Y";
                    if (i == 0)
                    {
                        if (foundRows.Length > 0)
                        {
                            columndes = foundRows[0]["columndesc"].ToString().Split(',');
                            columndwidth = foundRows[0]["columndwidth"].ToString().Split(',');
                            float[] width = new float[columndwidth.Length];
                            int z = 0;
                            foreach (string strwidth in columndwidth)
                            {
                                width[z] = Convert.ToInt32(strwidth.Replace("%", ""));
                                z++;
                            }
                            table = new PdfPTable(width);

                            z = 0;
                            foreach (string column in columndes)
                            {

                                ItemName1 = new PdfPCell(new Phrase(column, ChHead));
                                ItemName1.MinimumHeight = 20f;
                                ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                                ItemName1.HorizontalAlignment = Element.ALIGN_CENTER;
                                ItemName1.BackgroundColor = new iTextSharp.text.Color(222, 225, 231);
                                table.AddCell(ItemName1);

                                z++;
                            }
                        }    

                    }
                    columns = foundRows[0]["columnname"].ToString().Split(',');
                    foreach (string column in columns)
                    {
                        ItemName1 = new PdfPCell(new Phrase(Convert.ToString(dv[column]), ChFont));
                        ItemName1.MinimumHeight = 20f;
                        ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                        ItemName1.HorizontalAlignment = Element.ALIGN_LEFT;
                        table.AddCell(ItemName1);
                    }

                    i++;
                }
            }








        }
        catch (Exception ex)
        {
            throw ex;
        }
        return table;
    }
    protected PdfPTable WebServerInfo(string DataKey)
    {
        string value = string.Empty;
        IS_WebServerInfo = "N";
        DataRow[] foundRows;
        foundRows = dt_Layout.Select("type = 'WebServerInfo'");
        string[] columns, columndes, columndwidth;
        //讀取相關資料
        PdfPTable table = new PdfPTable(new float[] { 20, 20 });
        try
        {
            string strSQL = @"SELECT A.type,A.options,A.value,A.conf,case when A.value = 'N' then N'已關閉目錄瀏覽功能' else N'***未關閉目錄瀏覽功能' end  [desc]
                            FROM WebServerInfo A 
                            WHERE DataKey = @DataKey
                            ";

            string fontPath = Environment.GetFolderPath(Environment.SpecialFolder.System) + @"\..\Fonts\kaiu.ttf";
            BaseFont bfChinese = BaseFont.CreateFont(
                fontPath,
                BaseFont.IDENTITY_H, //橫式中文
                BaseFont.NOT_EMBEDDED
                );

            Font ChFont = new Font(bfChinese, 10);
            Font ChHead = new Font(bfChinese, 12, Font.BOLD, Color.BLACK);

            Font ChREAD = new Font(bfChinese, 10, Font.NORMAL, Color.RED);

            
            

            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            int i = 0;
            PdfPCell ItemName1;
            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {
                    IS_WebServerInfo = "Y";   //有web 服務
                    if (i == 0)
                    {
                        value = dv["value"].ToString().ToUpper();
                        if (value == "Y")
                        {
                            foundRows = dt_Layout.Select("type = 'WebServerInfoN'");
                            table = new PdfPTable(new float[] { 20, 30, 20 });
                            
                        }
                        table.TotalWidth = 500f;
                        table.LockedWidth = true;
                        if (foundRows.Length > 0)
                        {
                            columndes = foundRows[0]["columndesc"].ToString().Split(',');
                            columndwidth = foundRows[0]["columndwidth"].ToString().Split(',');
                            float[] width = new float[columndwidth.Length];
                            int z = 0;
                            foreach (string strwidth in columndwidth)
                            {
                                width[z] = Convert.ToInt32(strwidth.Replace("%", ""));
                                z++;
                            }
                            //table = new PdfPTable(width);

                            z = 0;
                            foreach (string column in columndes)
                            {

                                ItemName1 = new PdfPCell(new Phrase(column, ChHead));
                                ItemName1.MinimumHeight = 20f;
                                ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                                ItemName1.HorizontalAlignment = Element.ALIGN_CENTER;
                                ItemName1.BackgroundColor = new iTextSharp.text.Color(222, 225, 231);
                                table.AddCell(ItemName1);

                                z++;
                            }
                        }



                    }

                    columns = foundRows[0]["columnname"].ToString().Split(',');
                    foreach (string column in columns)
                    {
                        if (column == "desc")
                        {
                            ItemName1 = new PdfPCell(new Phrase(Convert.ToString(dv[column]), value == "Y" ? ChREAD : ChFont));
                        }
                        else
                        {
                            ItemName1 = new PdfPCell(new Phrase(Convert.ToString(dv[column]), ChFont));
                        }
                        ItemName1.MinimumHeight = 20f;
                        ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                        ItemName1.HorizontalAlignment = Element.ALIGN_LEFT;
                        table.AddCell(ItemName1);
                    }

                    i++;
                }
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        return table;
    }
    protected PdfPTable TaskList_New(string DataKey)
    {
        //讀取相關資料
        IS_TaskList = "";
        PdfPTable table = new PdfPTable(new float[] { 60, 60, 250 });
        try
        {
            string strSQL = @"SELECT A.exectime,A.cmds,A.owner
                                   , case when isnull(B.taskdesc,'') = '' then A.userfor else B.taskdesc end userfor
                            FROM Schedule A left join TaskDesc B on A.DataKey = B.DataKey and A.cmds = B.taskname
                            WHERE A.DataKey = @DataKey 
                            order by A.cmds,A.exectime";

            string fontPath = Environment.GetFolderPath(Environment.SpecialFolder.System) + @"\..\Fonts\kaiu.ttf";
            BaseFont bfChinese = BaseFont.CreateFont(
                fontPath,
                BaseFont.IDENTITY_H, //橫式中文
                BaseFont.NOT_EMBEDDED
                );

            Font ChFont = new Font(bfChinese, 10);
            Font ChHead = new Font(bfChinese, 12, Font.BOLD, Color.BLACK);

            table.TotalWidth = 500f;
            table.LockedWidth = true;

            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            int i = 0;
            PdfPCell ItemName1;
            
            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {

                    if (i == 0)
                    {
                        
                        ItemName1 = new PdfPCell(new Phrase("序號", ChHead));
                        ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                        ItemName1.HorizontalAlignment = Element.ALIGN_CENTER;
                        ItemName1.MinimumHeight = 20f;
                        ItemName1.BackgroundColor = new iTextSharp.text.Color(222, 225, 231);
                        table.AddCell(ItemName1);

                        ItemName1 = new PdfPCell(new Phrase("排程設定內容", ChHead));
                        ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                        ItemName1.HorizontalAlignment = Element.ALIGN_CENTER;
                        ItemName1.BackgroundColor = new iTextSharp.text.Color(222, 225, 231);
                        ItemName1.Colspan = 2;
                        table.AddCell(ItemName1);

                    }
                                        
                        
                        string value = (i+1).ToString();
                        ItemName1 = new PdfPCell(new Phrase(value, ChFont));
                        ItemName1.MinimumHeight = 20f;
                        ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                        ItemName1.Rowspan = 4;
                        table.AddCell(ItemName1);
                        //if (i % 2 == 0)
                        //{
                        //    ItemName1.BackgroundColor = new iTextSharp.text.Color(222, 225 ,231);
                        //}

                        ItemName1 = new PdfPCell(new Phrase("啟動時間", ChFont));
                        ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                        ItemName1.HorizontalAlignment = Element.ALIGN_CENTER;
                        ItemName1.MinimumHeight = 20f;
                        table.AddCell(ItemName1);


                        ItemName1 = new PdfPCell(new Phrase(Convert.ToString(dv["exectime"]), ChFont));
                        ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                        table.AddCell(ItemName1);

                        ItemName1 = new PdfPCell(new Phrase("執行程式", ChFont));
                        ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                        ItemName1.HorizontalAlignment = Element.ALIGN_CENTER;
                        ItemName1.MinimumHeight = 20f;
                        table.AddCell(ItemName1);


                        ItemName1 = new PdfPCell(new Phrase(Convert.ToString(dv["cmds"]), ChFont));
                        ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                        table.AddCell(ItemName1);

                        ItemName1 = new PdfPCell(new Phrase("執行帳號", ChFont));
                        ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                        ItemName1.HorizontalAlignment = Element.ALIGN_CENTER;
                        ItemName1.MinimumHeight = 20f;
                        table.AddCell(ItemName1);

                        ItemName1 = new PdfPCell(new Phrase(Convert.ToString(dv["owner"]), ChFont));
                        ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                        table.AddCell(ItemName1);

                        ItemName1 = new PdfPCell(new Phrase("用途", ChFont));
                        ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                        ItemName1.HorizontalAlignment = Element.ALIGN_CENTER;
                        ItemName1.MinimumHeight = 20f;
                        table.AddCell(ItemName1);

                        ItemName1 = new PdfPCell(new Phrase(Convert.ToString(dv["userfor"]), ChFont));
                        ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                        ItemName1.MinimumHeight = 20f;
                        table.AddCell(ItemName1);
                                          
                    
                    i++;
                }
            }








        }
        catch (Exception ex)
        {
            throw ex;
        }
        return table;
    }
    protected PdfPTable SystemConfigs(string DataKey)
    {
        DataRow[] foundRows;
        foundRows = dt_Layout.Select("type = 'SystemConfigs'");
        string[] columns, columndes, columndwidth;
        //讀取相關資料
        PdfPTable table = new PdfPTable(new float[] { 30,20,13});
        IS_TaskList = "";

        try
        {
//            string strSQL = @"SELECT A.path,A.access,A.owner,E.FilePath,E.AccessAuthority,E.OSType
//                                   , case when E.FilePath is null then 'N' when A.access <> E.AccessAuthority then 'Y' else 'N' end errorstatus
//                            FROM SystemConfigs A  left join (select FilePath,AccessAuthority,OStype from [dbo].[SystemConfigsSetU] ) E on A.path = E.FilePath 
//                            WHERE A.DataKey = @DataKey 
//                            order by A.path ";

            string strSQL = @"SELECT A.path,A.access,A.owner,E.FilePath,E.AccessAuthority,E.OSType
                                   , case when E.FilePath is null then 'N' when A.access <> E.AccessAuthority then 'Y' else 'N' end errorstatus
                            FROM SystemConfigs A  left join (select FilePath,AccessAuthority,OStype from [dbo].[SystemConfigsSetU] where (OSType = '' or OSType like @OSNAME) ) E on A.path = E.FilePath 
                            WHERE A.DataKey = @DataKey 
                            order by A.path ";

            string fontPath = Environment.GetFolderPath(Environment.SpecialFolder.System) + @"\..\Fonts\kaiu.ttf";
            BaseFont bfChinese = BaseFont.CreateFont(
                fontPath,
                BaseFont.IDENTITY_H, //橫式中文
                BaseFont.NOT_EMBEDDED
                );

            Font ChFont = new Font(bfChinese, 10);
            Font ChHead = new Font(bfChinese, 12, Font.BOLD, Color.BLACK);
            Font ChREAD = new Font(bfChinese, 10, Font.NORMAL, Color.RED);

            table.TotalWidth = 500f;
            table.LockedWidth = true;

            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            objParams.Add("OSNAME", DbType.String, "%" + OSNAME + "%");
            int i = 0;
            PdfPCell ItemName1;
            string[] OSType = null;
            Boolean ISOSType = false;
            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {

                    if (i == 0)
                    {
                        if (foundRows.Length > 0)
                        {
                            columndes = foundRows[0]["columndesc"].ToString().Split(',');
                            columndwidth = foundRows[0]["columndwidth"].ToString().Split(',');
                            float[] width = new float[columndwidth.Length];
                            int z = 0;
                            foreach (string strwidth in columndwidth)
                            {
                                width[z] = Convert.ToInt32(strwidth.Replace("%", ""));
                                z++;
                            }
                            //table = new PdfPTable(width);

                            z = 0;
                            foreach (string column in columndes)
                            {

                                ItemName1 = new PdfPCell(new Phrase(column, ChHead));
                                ItemName1.MinimumHeight = 20f;
                                ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                                ItemName1.HorizontalAlignment = Element.ALIGN_CENTER;
                                ItemName1.BackgroundColor = new iTextSharp.text.Color(222, 225, 231);
                                table.AddCell(ItemName1);

                                z++;
                            }
                        }

                    }

                    #region 判斷是否合規
                    OSType = dv["OSType"].ToString().ToLower().Split(';');
                    ISOSType = false;
                    if (dv["OSType"].ToString() == "")
                    {
                        ISOSType = true;
                    }
                    else
                    {
                        for (int k = 0; k < OSType.Length; k++)
                        {
                            if (OSNAME.ToLower().Contains(OSType[k]) && OSType[k] != "")
                            {
                                ISOSType = true;
                            }

                        }
                    }
                    #endregion


                    columns = foundRows[0]["columnname"].ToString().Split(',');
                    foreach (string column in columns)
                    {
                        //判斷權限對不對
                        if (column == "access")
                        {
                            string value = (ISOSType && dv["errorstatus"].ToString() == "Y" ? "***" : "") + Convert.ToString(dv[column]);
                            ItemName1 = new PdfPCell(new Phrase(value, ISOSType && dv["errorstatus"].ToString() == "Y" ? ChREAD : ChFont));
                        }
                        else
                        {
                            ItemName1 = new PdfPCell(new Phrase(Convert.ToString(dv[column]), ChFont));
                        }
                        
                        ItemName1.MinimumHeight = 20f;
                        ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                        ItemName1.HorizontalAlignment = Element.ALIGN_LEFT;
                        table.AddCell(ItemName1);
                    }

                    i++;
                }
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        return table;
    }
    protected PdfPTable Package(string DataKey)
    {
        DataRow[] foundRows;
        foundRows = dt_Layout.Select("type = 'Packages'");
        string[] columns, columndes, columndwidth;
        //讀取相關資料
        PdfPTable table = new PdfPTable(new float[] { 40,20,10 });
        IS_TaskList = "";

        try
        {
            string strSQL = @"select A.KitName name,E.ver,A.Version,A.OSType
                            , case when E.ver is null then 'NO'  when  isnull(A.Version,'') = '' or isnull(A.Version,'')  = E.ver then 'Yes'  else 'NO' end status
		                    ,  case when E.ver is null then 'Y' else '' end notexists
		                    ,  case when  isnull(A.Version,'') <> '' and isnull(A.Version,'') <> E.ver then 'Y' else '' end noversion
                            from [dbo].[PackageNecessaryU] A
                             left join(select name,ver from [Packages] where  DataKey = @DataKey ) E on A.KitName = E.name  
                            order by A.kitname
                             ";

            string fontPath = Environment.GetFolderPath(Environment.SpecialFolder.System) + @"\..\Fonts\kaiu.ttf";
            BaseFont bfChinese = BaseFont.CreateFont(
                fontPath,
                BaseFont.IDENTITY_H, //橫式中文
                BaseFont.NOT_EMBEDDED
                );

            Font ChFont = new Font(bfChinese, 10);
            Font ChHead = new Font(bfChinese, 12, Font.BOLD, Color.BLACK);
            Font ChREAD = new Font(bfChinese, 10, Font.NORMAL, Color.RED);

            table.TotalWidth = 500f;
            table.LockedWidth = true;

            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            int i = 0;
            PdfPCell ItemName1;
            string[] OSType = null;
            Boolean ISOSType = false;
            string iserror=string.Empty, isnotexits = string.Empty, isversion = string.Empty;
            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {

                    if (i == 0)
                    {
                        if (foundRows.Length > 0)
                        {
                            columndes = foundRows[0]["columndesc"].ToString().Split(',');
                            columndwidth = foundRows[0]["columndwidth"].ToString().Split(',');
                            float[] width = new float[columndwidth.Length];
                            int z = 0;
                            foreach (string strwidth in columndwidth)
                            {
                                width[z] = Convert.ToInt32(strwidth.Replace("%", ""));
                                z++;
                            }
                            //table = new PdfPTable(width);

                            z = 0;
                            foreach (string column in columndes)
                            {

                                ItemName1 = new PdfPCell(new Phrase(column, ChHead));
                                ItemName1.MinimumHeight = 20f;
                                ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                                ItemName1.HorizontalAlignment = Element.ALIGN_CENTER;
                                ItemName1.BackgroundColor = new iTextSharp.text.Color(222, 225, 231);
                                table.AddCell(ItemName1);

                                z++;
                            }
                        }

                    }

                    #region 判斷是否合規
                    iserror = "";
                    OSType = dv["OSType"].ToString().ToLower().Split(';');
                    ISOSType = false;
                    if (dv["OSType"].ToString() == "")
                    {
                        ISOSType = true;
                    }
                    else
                    {
                        for (int k = 0; k < OSType.Length; k++)
                        {
                            if (OSNAME.ToLower().Contains(OSType[k]) && OSType[k] != "")
                            {
                                ISOSType = true;
                            }

                        }
                    }
                    //判斷必要安裝的Package是否存在
                    if (ISOSType)
                    {
                        if (dv["status"].ToString() == "NO")
                        {
                            //有問題
                            iserror = "Y";
                            
                        }
                    }
                    #endregion

                    if (ISOSType)  //有設定到OS的才顯示 20180917 關鍵字cifs_fs是AIX專用，非AIX主機上，報表能否不顯示
                    {
                        columns = foundRows[0]["columnname"].ToString().Split(',');
                        foreach (string column in columns)
                        {
                            string value = "";
                            if (column == "name")
                            {
                                value = (iserror == "Y" && dv["notexists"].ToString() == "Y" ? "***" : "") + Convert.ToString(dv[column]);
                                ItemName1 = new PdfPCell(new Phrase(value, iserror == "Y" && dv["notexists"].ToString() == "Y" ? ChREAD : ChFont));
                            }
                            else if (column == "ver")
                            {
                                value = (iserror == "Y" && dv["noversion"].ToString() == "Y" ? "***" : "") + Convert.ToString(dv[column]);
                                ItemName1 = new PdfPCell(new Phrase(value, iserror == "Y" && dv["noversion"].ToString() == "Y" ? ChREAD : ChFont));
                            }
                            else
                            {
                                ItemName1 = new PdfPCell(new Phrase(Convert.ToString(dv[column]), ChFont));
                            }

                            ItemName1.MinimumHeight = 20f;
                            ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                            ItemName1.HorizontalAlignment = Element.ALIGN_LEFT;
                            table.AddCell(ItemName1);
                        }
                    }

                    i++;
                }
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        return table;
    }
    protected PdfPTable Policy(string DataKey, string type)
    {
        DataRow[] foundRows;
        foundRows = dt_Layout.Select(string.Format("type = 'Policie_{0}'", type));
        string[] columns, columndes, columndwidth;
        //讀取相關資料
        PdfPTable table = new PdfPTable(new float[] { 50,50 });
        IS_TaskList = "";

        try
        {
            string strSQL = @" select A.name,A.value ,E.Policy,E.OSType,E.SetPoint
                                    , case when isnull(A.value,'') <> E.SetPoint then 'Y' else 'N' end errstatus
                            from Policies A left join  PolicyNecessaryU E on A.name = E.Policy
                            WHERE A.DataKey = @DataKey and A.type = @type";

            string fontPath = Environment.GetFolderPath(Environment.SpecialFolder.System) + @"\..\Fonts\kaiu.ttf";
            BaseFont bfChinese = BaseFont.CreateFont(
                fontPath,
                BaseFont.IDENTITY_H, //橫式中文
                BaseFont.NOT_EMBEDDED
                );

            Font ChFont = new Font(bfChinese, 10);
            Font ChHead = new Font(bfChinese, 12, Font.BOLD, Color.BLACK);
            Font ChREAD = new Font(bfChinese, 10, Font.NORMAL, Color.RED);

            table.TotalWidth = 500f;
            table.LockedWidth = true;

            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            objParams.Add("type", DbType.String, type);
            int i = 0;
            PdfPCell ItemName1;
            string[] OSType = null;
            Boolean ISOSType = false;

            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {
                    IS_TaskList = "Y";
                    if (i == 0)
                    {
                        if (foundRows.Length > 0)
                        {
                            columndes = foundRows[0]["columndesc"].ToString().Split(',');
                            columndwidth = foundRows[0]["columndwidth"].ToString().Split(',');
                            float[] width = new float[columndwidth.Length];
                            int z = 0;
                            foreach (string strwidth in columndwidth)
                            {
                                width[z] = Convert.ToInt32(strwidth.Replace("%", ""));
                                z++;
                            }
                            //table = new PdfPTable(width);
                            
                            z = 0;
                            foreach (string column in columndes)
                            {

                                ItemName1 = new PdfPCell(new Phrase(column, ChHead));
                                ItemName1.MinimumHeight = 20f;
                                ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                                ItemName1.HorizontalAlignment = Element.ALIGN_LEFT;
                                ItemName1.BackgroundColor = new iTextSharp.text.Color(222, 225, 231);
                                table.AddCell(ItemName1);

                                z++;
                            }
                        }

                    }

                    #region 判斷是否合規
                    //OSType = dv["OSType"].ToString().ToLower().Split(';');
                    //ISOSType = false;
                    //if (dv["OSType"].ToString() == "")
                    //{
                    //    ISOSType = true;
                    //}
                    //else
                    //{
                    //    for (int z = 0; z < OSType.Length; z++)
                    //    {
                    //        if (OSNAME.ToLower().Contains(OSType[z]) && OSType[z] != "")
                    //        {
                    //            ISOSType = true;
                    //        }

                    //    }
                    //}
                    ISOSType = true;


                    string strcolumn = "";
                    ResourceManager ReportRex = Resources.ReportRex.ResourceManager;
                    columns = foundRows[0]["columnname"].ToString().Split(',');
                    int k = 0;
                    foreach (string column in columns)
                    {
                        
                        try
                        {
                            if (k == 0)
                            {
                                strcolumn = ReportRex.GetString(Convert.ToString(dv[column]));
                                strcolumn = strcolumn == null ? Convert.ToString(dv[column]) : strcolumn;
                            }
                            else
                            {
                                strcolumn = Convert.ToString(dv[column]);
                            }
                            
                        }
                        catch (Exception ex)
                        {
                            strcolumn = column;
                        }

                        if (column == "value")
                        {
                            /*
                             * 2020.06.10, Jeremy, 因客戶要求臨時調整，未來考慮密碼原則設定大小時再來重構。
                             */
                            EADMCommon EADMCommon = new EADMCommon();
                            bool isAbnormal = CommonInfo.GCB_isAbnormal(dv["value"].ToString(), dv["SetPoint"].ToString(), dv["name"].ToString());

                            string value = (ISOSType && isAbnormal ? "***" : "") + strcolumn;
                            ItemName1 = new PdfPCell(new Phrase(value, ISOSType && isAbnormal ? ChREAD : ChFont));
                        }
                        else
                        {
                            ItemName1 = new PdfPCell(new Phrase(strcolumn, ChFont));
                        }

                        ItemName1.MinimumHeight = 20f;
                        ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                        ItemName1.HorizontalAlignment = Element.ALIGN_LEFT;
                        table.AddCell(ItemName1);
                        k++;
                    }

                    #endregion
                    i++;
                }
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        return table;
    }

    protected string Policy_value(string DataKey, string type)
    {
        //讀取相關資料
        string strValue = "";
        try
        {
            string strSQL = @" select A.name,A.value ,E.Policy,E.OSType,E.SetPoint
                                    , case when isnull(A.value,'') <> E.SetPoint then 'Y' else 'N' end errstatus
                            from Policies A left join  PolicyNecessaryU E on A.name = E.Policy
                            WHERE A.DataKey = @DataKey and A.type = @type";

            
            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            objParams.Add("type", DbType.String, type);
            int i = 0;
            

            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {
                    strValue = dv["value"].ToString();
                    break;
                }
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        return strValue;
    }
    protected PdfPTable UserList(string DataKey)
    {
        DataRow[] foundRows;
        foundRows = dt_Layout.Select("type = 'Users'");
        string[] columns, columndes, columndwidth, columnalign=null;
        //讀取相關資料
        PdfPTable table = new PdfPTable(new float[] { 20,20,30,30 });
        IS_TaskList = "";

        try
        {
            

            string fontPath = Environment.GetFolderPath(Environment.SpecialFolder.System) + @"\..\Fonts\kaiu.ttf";
            BaseFont bfChinese = BaseFont.CreateFont(
                fontPath,
                BaseFont.IDENTITY_H, //橫式中文
                BaseFont.NOT_EMBEDDED
                );

            Font ChFont = new Font(bfChinese, 10);
            Font ChREAD = new Font(bfChinese, 10, Font.NORMAL, Color.RED);
            Font ChHead = new Font(bfChinese, 12, Font.BOLD, Color.BLACK);
            

            table.TotalWidth = 500f;
            table.LockedWidth = true;

            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            
            int i = 0;
            PdfPCell ItemName1;
            string strSQL = @"select S.OSNAME,A.name,A.sh,A.grps,A.id
                          from SecurityScanUList S inner join [Users] A on A.DataKey = S.DataKey
                          where S.DataKey = @DataKey 
                            order by Convert(bigint,isnull(A.ID,9999)) ";
            objParams.Clear();
            objParams.Add("DataKey", DbType.String, DataKey);
            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {

                    if (i == 0)
                    {
                        if (foundRows.Length > 0)
                        {
                            columndes = foundRows[0]["columndesc"].ToString().Split(',');
                            columndwidth = foundRows[0]["columndwidth"].ToString().Split(',');
                            columnalign = foundRows[0]["columnalign"].ToString().Split(',');
                            float[] width = new float[columndwidth.Length];
                            int z = 0;
                            foreach (string strwidth in columndwidth)
                            {
                                width[z] = Convert.ToInt32(strwidth.Replace("%", ""));
                                z++;
                            }
                            //table = new PdfPTable(width);

                            z = 0;
                            foreach (string column in columndes)
                            {

                                ItemName1 = new PdfPCell(new Phrase(column, ChHead));
                                ItemName1.MinimumHeight = 20f;
                                ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                                ItemName1.HorizontalAlignment = Element.ALIGN_CENTER;
                                ItemName1.BackgroundColor = new iTextSharp.text.Color(222, 225, 231);
                                table.AddCell(ItemName1);

                                z++;
                            }
                        }

                    }
                    #region 判斷是否合規
                    strSQL = @"select * from RootDefautU a where @OSNAME LIKE '%' + a.OSType + '%'  order by AccountId";
                    objParams.Clear();
                    objParams.Add("OSNAME", DbType.String, OSNAME);
                    DataTable dt = da.ExecuteDataTable(strSQL, objParams);
                    string Filter="",AccountId="";
                    string[] OSType = null;
                    Boolean ISOSType = false, iderrorstatus = false, nameerrorstatus = false;
                    foreach (DataRow dr in dt.Rows)
                    {
                        OSType = dr["OSType"].ToString().ToLower().Split(';');
                        Filter = dr["Filter"].ToString();
                        AccountId = dr["AccountId"].ToString();

                        ISOSType = false;
                        if (dr["OSType"].ToString() == "")
                        {
                            ISOSType = true;
                        }
                        else
                        {
                            for (int k = 0; k < OSType.Length; k++)
                            {
                                if (OSNAME.ToLower().Contains(OSType[k]) && OSType[k] != "")
                                {
                                    ISOSType = true;
                                }

                            }
                        }
                        if (ISOSType)
                        {                            
                            Int64 n;
                            if (Int64.TryParse(AccountId, out n))  //數字格式
                            {
                                //數字
                                switch (Filter.ToUpper())
	                            {
                                    case "L":
                                        if (Convert.ToInt64(dv["id"]) >= Convert.ToInt64(AccountId))
                                        {
                                            iderrorstatus = true;
                                        }
                                        break;
                                    case "LE":
                                        if (Convert.ToInt64(dv["id"]) > Convert.ToInt64(AccountId))
                                        {
                                            iderrorstatus = true;
                                        }
                                        break;
                                    case "E":
                                        if (Convert.ToInt64(dv["id"]) != Convert.ToInt64(AccountId))
                                        {
                                            iderrorstatus = true;
                                        }
                                        break;
                                    case "G":
                                        if (Convert.ToInt64(dv["id"]) <= Convert.ToInt64(AccountId))
                                        {
                                            iderrorstatus = true;
                                        }
                                        break;
                                    case "GE":
                                        if (Convert.ToInt64(dv["id"]) < Convert.ToInt64(AccountId))
                                        {
                                            iderrorstatus = true;
                                        }
                                        break;
		                            default:
                                        break;
	                            }
                            }
                            else
                            {
                                if (iderrorstatus)
                                {
                                    //文字
                                    switch (Filter.ToUpper())
                                    {
                                       
                                        case "E":
                                            if (dv["name"].ToString() == AccountId)
                                            {
                                                iderrorstatus = false;
                                            }
                                            break;
                                        
                                        default:
                                            break;
                                    }
                                }
                            }
                                                       
                        }
                    }
                    

                    #endregion

                    columns = foundRows[0]["columnname"].ToString().Split(',');
                    int col = 0;
                    foreach (string column in columns)
                    {
                        if (column.ToUpper() == "ID" )
                        {

                            string value = (iderrorstatus ? "***" : "") + Convert.ToString(dv[column]);
                            ItemName1 = new PdfPCell(new Phrase(value, iderrorstatus ? ChREAD : ChFont));
                        }
                        else
                        {
                            ItemName1 = new PdfPCell(new Phrase(Convert.ToString(dv[column]), ChFont));
                        }
                        
                        ItemName1.MinimumHeight = 20f;
                        ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                        if (columnalign.Length > 0)
                        {
                            switch (columnalign[col])
                            {
                                case "R":
                                    ItemName1.HorizontalAlignment = Element.ALIGN_RIGHT;
                                    break;
                                case "C":
                                    ItemName1.HorizontalAlignment = Element.ALIGN_CENTER;
                                    break;
                                default:
                                    ItemName1.HorizontalAlignment = Element.ALIGN_LEFT;
                                    break;
                            }
                        }
                        else
                        {
                            ItemName1.HorizontalAlignment = Element.ALIGN_LEFT;
                        }
                        table.AddCell(ItemName1);

                        col++;
                    }

                    i++;
                }
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        return table;
    }
    protected PdfPTable UserGroupList(string DataKey)
    {
        DataRow[] foundRows;
        foundRows = dt_Layout.Select("type = 'Groups'");
        string[] columns, columndes, columndwidth, columnalign = null; 
        string columnsplit="";
        //讀取相關資料
        PdfPTable table = new PdfPTable(new float[] { 20,10,30 });
        IS_TaskList = "";

        try
        {
            string strSQL = @"SELECT A.name,A.id, REPLACE(A.users,',',char(13)+char(10)) users
                            FROM Groups A 
                            WHERE DataKey = @DataKey 
                            order by Convert(bigint,isnull(A.ID,9999))  ";

            string fontPath = Environment.GetFolderPath(Environment.SpecialFolder.System) + @"\..\Fonts\kaiu.ttf";
            BaseFont bfChinese = BaseFont.CreateFont(
                fontPath,
                BaseFont.IDENTITY_H, //橫式中文
                BaseFont.NOT_EMBEDDED
                );

            Font ChFont = new Font(bfChinese, 10);
            Font ChHead = new Font(bfChinese, 12, Font.BOLD, Color.BLACK);

            table.TotalWidth = 500f;
            table.LockedWidth = true;

            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            int i = 0;
            PdfPCell ItemName1;

            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {

                    if (i == 0)
                    {
                        if (foundRows.Length > 0)
                        {
                            columndes = foundRows[0]["columndesc"].ToString().Split(',');
                            columndwidth = foundRows[0]["columndwidth"].ToString().Split(',');
                            columnalign = foundRows[0]["columnalign"].ToString().Split(',');
                            columnsplit = foundRows[0]["columnsplit"].ToString();
                            float[] width = new float[columndwidth.Length];
                            int z = 0;
                            foreach (string strwidth in columndwidth)
                            {
                                width[z] = Convert.ToInt32(strwidth.Replace("%", ""));
                                z++;
                            }
                            //table = new PdfPTable(width);

                            z = 0;
                            foreach (string column in columndes)
                            {

                                ItemName1 = new PdfPCell(new Phrase(column, ChHead));
                                ItemName1.MinimumHeight = 20f;
                                ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                                ItemName1.HorizontalAlignment = Element.ALIGN_CENTER;
                                ItemName1.BackgroundColor = new iTextSharp.text.Color(222, 225, 231);
                                table.AddCell(ItemName1);

                                z++;
                            }
                        }

                    }
                    columns = foundRows[0]["columnname"].ToString().Split(',');
                    int col = 0;
                    foreach (string column in columns)
                    {
                        
                        ItemName1 = new PdfPCell(new Phrase(Convert.ToString(dv[column]), ChFont));
                        ItemName1.MinimumHeight = 20f;
                        ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                        if (columnalign.Length > 0)
                        {
                            switch (columnalign[col])
                            {
                                case "R":
                                    ItemName1.HorizontalAlignment = Element.ALIGN_RIGHT;
                                    break;
                                case "C":
                                    ItemName1.HorizontalAlignment = Element.ALIGN_CENTER;
                                    break;
                                default:
                                    ItemName1.HorizontalAlignment = Element.ALIGN_LEFT;
                                    break;
                            }
                        }
                        else
                        {
                            ItemName1.HorizontalAlignment = Element.ALIGN_LEFT;
                        }
                        table.AddCell(ItemName1);
                        col++;
                    }

                    i++;
                }
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        return table;
    }
    protected PdfPTable RootAccess(string DataKey)
    {
        DataRow[] foundRows;
        foundRows = dt_Layout.Select("type = 'RootAccess'");
        string[] columns, columndes, columndwidth;
        //讀取相關資料
        PdfPTable table = new PdfPTable(new float[] { 30,15,20,20,20 });
        IS_TaskList = "";

        try
        {
            string strSQL = @"SELECT A.name,A.type,A.access,A.owner,E.catalogName,E.OSType
                                    , case when E.catalogName is null then 'Y' else 'N' end errstatus
                                    --, case when E.catalogName is null then '' else N'系統預設' end userfor
                                    , case when B.RootDesc is null then  case when E.catalogName is null then '' else N'系統預設' end else B.RootDesc end userfor

                            FROM RootAccess A  left join RootDesc B on A.DataKey = B.DataKey and A.name = B.RootName
                                               left join RootAccessNecessaryU E on A.name = E.catalogName
                            WHERE A.DataKey = @DataKey 
                            order by A.type,A.name ";

            string fontPath = Environment.GetFolderPath(Environment.SpecialFolder.System) + @"\..\Fonts\kaiu.ttf";
            BaseFont bfChinese = BaseFont.CreateFont(
                fontPath,
                BaseFont.IDENTITY_H, //橫式中文
                BaseFont.NOT_EMBEDDED
                );

            Font ChFont = new Font(bfChinese, 10);
            Font ChHead = new Font(bfChinese, 12, Font.BOLD, Color.BLACK);
            Font ChREAD = new Font(bfChinese, 10, Font.NORMAL, Color.RED);

            table.TotalWidth = 500f;
            table.LockedWidth = true;

            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            int i = 0;
            PdfPCell ItemName1;
            string[] OSType = null;
            Boolean ISOSType = false;
            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {

                    if (i == 0)
                    {
                        if (foundRows.Length > 0)
                        {
                            columndes = foundRows[0]["columndesc"].ToString().Split(',');
                            columndwidth = foundRows[0]["columndwidth"].ToString().Split(',');
                            float[] width = new float[columndwidth.Length];
                            int z = 0;
                            foreach (string strwidth in columndwidth)
                            {
                                width[z] = Convert.ToInt32(strwidth.Replace("%", ""));
                                z++;
                            }
                            //table = new PdfPTable(width);

                            z = 0;
                            foreach (string column in columndes)
                            {

                                ItemName1 = new PdfPCell(new Phrase(column, ChHead));
                                ItemName1.MinimumHeight = 20f;
                                ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                                ItemName1.HorizontalAlignment = Element.ALIGN_CENTER;
                                ItemName1.BackgroundColor = new iTextSharp.text.Color(222, 225, 231);
                                table.AddCell(ItemName1);

                                z++;
                            }
                        }

                    }

                    #region 判斷是否合規
                    OSType = dv["OSType"].ToString().ToLower().Split(';');
                    ISOSType = false;
                    if (dv["OSType"].ToString() == "")
                    {
                        ISOSType = true;
                    }
                    else
                    {
                        for (int k = 0; k < OSType.Length; k++)
                        {
                            if (OSNAME.ToLower().Contains(OSType[k]) && OSType[k] != "")
                            {
                                ISOSType = true;
                            }

                        }
                    }
                    
                    #endregion

                    columns = foundRows[0]["columnname"].ToString().Split(',');
                    foreach (string column in columns)
                    {
                        ItemName1 = new PdfPCell(new Phrase(Convert.ToString(dv[column]), ChFont));


                        if (column == "name")
                        {
                            string value = (ISOSType && dv["errstatus"].ToString() == "Y" ? "***":"") + Convert.ToString(dv[column]);
                            ItemName1 = new PdfPCell(new Phrase(value, ISOSType && dv["errstatus"].ToString() == "Y" ? ChREAD : ChFont));
                        }
                        else
                        {
                            ItemName1 = new PdfPCell(new Phrase(Convert.ToString(dv[column]), ChFont));
                        }

                        ItemName1.MinimumHeight = 20f;
                        ItemName1.VerticalAlignment = Element.ALIGN_MIDDLE;
                        ItemName1.HorizontalAlignment = Element.ALIGN_LEFT;
                        table.AddCell(ItemName1);
                    }

                    i++;
                }
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        return table;
    }
    public DataTable dt_Layout;
    public string MACHINENAME;
    public void init(string ostype)
    {
        EADMCommon EADMCommon = new EADMCommon();
        dt_Layout = EADMCommon.init_layout(ostype);

    }
}