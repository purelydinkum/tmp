﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;
using System.Data;
using SelectPdf;
using System.Resources;


public partial class Comm_PrintHtml_Unix : BasePage
{
    public string IS_Process = "", IS_ServicesNecessary = "", IS_TaskList = "", IS_WebServerInfo = "";
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["DataKey"] == null)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Comm_OutputExcel", "alert('查詢資料不存在！');window.close()", true);
            return;
        }


        string Datakey = Session["DataKey"].ToString();
        try
        {
            #region 建立HTML Table
            TableRow row = new TableRow();
            TableCell cell = new TableCell();
            //-------------------------------------------------------------------------------------
            
            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "<b>一 基本安全設定原則</b>";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            row = new TableRow();
            cell = new TableCell();
            cell.Style.Add("width", "20");
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            row.Cells.Add(cell);

            //-------------------------------------------------------------------------------------
            HtmlTable tb_OS = OS(Datakey);
            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "<b>(一) 作業系統資訊</b>";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            row = new TableRow();
            cell = new TableCell();
            cell.Style.Add("width", "20");
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            row.Cells.Add(cell);

            cell = new TableCell();
            cell.Style.Add("width", "80");
            cell.Controls.Add(tb_OS);
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);
            //-------------------------------------------------------------------------------------
            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);
            ////-------------------------------------------------------------------------------------

            HtmlTable tb_Disk = Disk(DataKey);
            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "<b>(二) 磁碟分割資訊</b>";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            row = new TableRow();
            cell = new TableCell();
            cell.Style.Add("width", "20");
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            row.Cells.Add(cell);

            cell = new TableCell();
            cell.Style.Add("width", "80");
            cell.Controls.Add(tb_Disk);
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);
            //-------------------------------------------------------------------------------------
            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);
            ////-------------------------------------------------------------------------------------

            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "<b>(二) 主機服務及排程工作資訊</b>";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "<b>※服務清單</b>";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            row = new TableRow();
            cell = new TableCell();
            cell.Style.Add("width", "20");
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            row.Cells.Add(cell);
            HtmlTable tb_ServiceList = ServiceList(DataKey);
            cell = new TableCell();
            cell.Style.Add("width", "80");
            cell.Controls.Add(tb_ServiceList);
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            //-------------------------------------------------------------------------------------
            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);
            //-------------------------------------------------------------------------------------
            HtmlTable tb_ServicesNecessary = ServicesNecessary(DataKey);
            if (IS_ServicesNecessary == "Y")
            {
                row = new TableRow();
                cell = new TableCell();
                cell.ColumnSpan = 2;
                cell.Text = "<b>※未安裝服務清單</b>";
                cell.Font.Size = 20;
                row.Cells.Add(cell);
                tbHtml.Rows.Add(row);

                row = new TableRow();
                cell = new TableCell();
                cell.Style.Add("width", "20");
                cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                row.Cells.Add(cell);
                
                cell = new TableCell();
                cell.Style.Add("width", "80");
                cell.Controls.Add(tb_ServicesNecessary);
                row.Cells.Add(cell);
                tbHtml.Rows.Add(row);

            }

            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);
            //-------------------------------------------------------------------------------------    
            HtmlTable tb_ProcessList = ProcesseList(DataKey);

            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "<b>※正在執行Process清單</b>";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            row = new TableRow();
            cell = new TableCell();
            cell.Style.Add("width", "20");
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            row.Cells.Add(cell);

            cell = new TableCell();
            cell.Style.Add("width", "80");
            cell.Controls.Add(tb_ProcessList);
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);
            //-------------------------------------------------------------------------------------
            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);
            //-------------------------------------------------------------------------------------

            HtmlTable tb_TaskList = TaskList(DataKey);

            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "<b>※排程清單</b>";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            row = new TableRow();
            cell = new TableCell();
            cell.Style.Add("width", "20");
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            row.Cells.Add(cell);

            cell = new TableCell();
            cell.Style.Add("width", "80");
            cell.Controls.Add(tb_TaskList);
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            //-------------------------------------------------------------------------------------
            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);
            //-------------------------------------------------------------------------------------

            HtmlTable tb_WebServerInfo = WebServerInfo(DataKey);

            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "<b>※網站服務</b>";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            row = new TableRow();
            cell = new TableCell();
            cell.Style.Add("width", "20");
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            row.Cells.Add(cell);

            if(IS_WebServerInfo == "Y")
            {
                cell = new TableCell();
                cell.Style.Add("width", "80");
                cell.Controls.Add(tb_WebServerInfo);
                row.Cells.Add(cell);
                tbHtml.Rows.Add(row);
            }
            else
            {
                cell = new TableCell();
                cell.Style.Add("width", "80");
                cell.Style.Add("font-size", "16pt");
                cell.Style.Add("color", "red");
                cell.Text = "***<b>無WebSphere或Apache服務</b>";

                row.Cells.Add(cell);
                tbHtml.Rows.Add(row);
            }
            //-------------------------------------------------------------------------------------
            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);
            //-------------------------------------------------------------------------------------
            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);
            //-------------------------------------------------------------------------------------        
            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "<b>(三) 系統檔案存取權限管理</b>";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);


            row = new TableRow();
            cell = new TableCell();
            cell.Style.Add("width", "20");
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            row.Cells.Add(cell);
            HtmlTable SystemConfigs_p = SystemConfigs(DataKey);
            cell = new TableCell();
            cell.Style.Add("width", "80");
            cell.Controls.Add(SystemConfigs_p);
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);
            //-------------------------------------------------------------------------------------        
            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "<b>(四) 已安裝套件資訊</b>";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "<b>※已安裝套件</b>";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);


            row = new TableRow();
            cell = new TableCell();
            cell.Style.Add("width", "20");
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            row.Cells.Add(cell);
            HtmlTable PackageT = Package(DataKey);
            cell = new TableCell();
            cell.Style.Add("width", "80");
            cell.Controls.Add(PackageT);
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            //-------------------------------------------------------------------------------------        
            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "<b>(五) 作業系統安全性設定</b>";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "<b>※重要系統參數檢查項目</b>";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);


            row = new TableRow();
            cell = new TableCell();
            cell.Style.Add("width", "20");
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            row.Cells.Add(cell);
            HtmlTable Policy_p = Policy(DataKey, "important");
            cell = new TableCell();
            cell.Style.Add("width", "80");
            cell.Controls.Add(Policy_p);
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "<b>※ROOT 管控原則</b>";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);


            row = new TableRow();
            cell = new TableCell();
            cell.Style.Add("width", "20");
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            row.Cells.Add(cell);
            Policy_p = Policy(DataKey, "root");
            cell = new TableCell();
            cell.Style.Add("width", "80");
            cell.Controls.Add(Policy_p);
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            Policy_p = Policy(DataKey, "guest");
            if (Policy_p.Rows.Count != 0)
            {
                row = new TableRow();
                cell = new TableCell();
                cell.ColumnSpan = 2;
                cell.Text = "<b>※Guest帳戶狀態</b>";
                cell.Font.Size = 20;
                row.Cells.Add(cell);
                tbHtml.Rows.Add(row);

                row = new TableRow();
                cell = new TableCell();
                cell.Style.Add("width", "20");
                cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                row.Cells.Add(cell);
                cell = new TableCell();
                cell.Style.Add("width", "80");
                cell.Controls.Add(Policy_p);
                row.Cells.Add(cell);
                tbHtml.Rows.Add(row);

                row = new TableRow();
                cell = new TableCell();
                cell.ColumnSpan = 2;
                cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                cell.Font.Size = 20;
                row.Cells.Add(cell);
                tbHtml.Rows.Add(row);
            }

            //-------------------------------------------------------------------------------------        
            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "<b>二、本機使用者及群組清單</b>";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            row = new TableRow();
            cell = new TableCell();
            cell.Style.Add("width", "20");
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "<b>※使用者清單</b>";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            row = new TableRow();
            cell = new TableCell();
            cell.Style.Add("width", "20");
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            row.Cells.Add(cell);
            HtmlTable tb_UserList = UserList(DataKey);
            cell = new TableCell();
            cell.Style.Add("width", "80");
            cell.Controls.Add(tb_UserList);
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            row = new TableRow();
            cell = new TableCell();
            cell.Style.Add("width", "20");
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "<b>※使用者群組</b>";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            row = new TableRow();
            cell = new TableCell();
            cell.Style.Add("width", "20");
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            row.Cells.Add(cell);
            HtmlTable tb_UserGroupList = UserGroupList(DataKey);
            cell = new TableCell();
            cell.Style.Add("width", "80");
            cell.Controls.Add(tb_UserGroupList);
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            //-------------------------------------------------------------------------------------
            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);
            //-------------------------------------------------------------------------------------   
            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "<b>三、目錄檔案存取權限</b>";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            row = new TableRow();
            cell = new TableCell();
            cell.Style.Add("width", "20");
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            row = new TableRow();
            cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "<b>※目錄檔案存取權限</b>";
            cell.Font.Size = 20;
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            row = new TableRow();
            cell = new TableCell();
            cell.Style.Add("width", "20");
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            row.Cells.Add(cell);
            HtmlTable RootAccess_p = RootAccess(DataKey);
            cell = new TableCell();
            cell.Style.Add("width", "80");
            cell.Controls.Add(RootAccess_p);
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);

            row = new TableRow();
            cell = new TableCell();
            cell.Style.Add("width", "20");
            cell.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            row.Cells.Add(cell);
            tbHtml.Rows.Add(row);
                       

            #endregion
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
            Response.Flush();
            Response.End();
        }
    }
    public string OSNAME = "";

    protected HtmlTable OS(string DataKey)
    {
        //讀取相關資料

        HtmlTable tb_OS = new HtmlTable();
        HtmlTableRow row = new HtmlTableRow();
        HtmlTableCell cell = new HtmlTableCell();
        try
        {

            string strSQL = @"SELECT A.PCID,A.PCFULLNAME,
                            A.DomainName,
                            A.OSNAME,
                            A.OSSP,
                            Convert(varchar(20),A.HOTFIX_LASTDATE,120) HOTFIX_LASTDATE,
                            A.MANUFACTURER,
                            A.MODEL
                            FROM SecurityScanUList A 
                            WHERE DataKey = @DataKey";


            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            //tb_OS.Border = 1;
            tb_OS.Style.Add("width", "100%");
            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {
                    row = new HtmlTableRow();
                    cell = new HtmlTableCell();
                    cell.BgColor = "DEE1E7";
                    cell.Style.Add("font-size", "16pt");
                    cell.Style.Add("width", "10%");
                    cell.Style.Add("font-weight", "bold");
                    cell.InnerText = "主機名稱：";
                    row.Cells.Add(cell);
                    cell = new HtmlTableCell();
                    cell.BgColor = "F6F6F6";
                    cell.Style.Add("font-size", "16pt");
                    cell.Style.Add("width", "20%");
                    cell.InnerText = dv["PCID"].ToString();
                    row.Cells.Add(cell);

                    cell = new HtmlTableCell();
                    cell.BgColor = "DEE1E7";
                    cell.Style.Add("font-size", "16pt");
                    cell.Style.Add("width", "10%");
                    cell.Style.Add("font-weight", "bold");
                    cell.InnerText = "作業系統版本：";
                    row.Cells.Add(cell);
                    cell = new HtmlTableCell();
                    cell.BgColor = "F6F6F6";
                    cell.Style.Add("font-size", "16pt");
                    cell.Style.Add("width", "20%");
                    cell.InnerText = dv["OSNAME"].ToString();
                    OSNAME = dv["OSNAME"].ToString();
                    row.Cells.Add(cell);
                    tb_OS.Rows.Add(row);

                    init(dv["OSNAME"].ToString());
                }
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        return tb_OS;
    }        
    protected HtmlTable Disk(string DataKey)
    {
        DataRow[] foundRows;
        foundRows = dt_Layout.Select("type = 'Disks'");
        string[] columns, columndes, columndwidth;

        HtmlTable tb = new HtmlTable();
        HtmlTableRow row = new HtmlTableRow();
        HtmlTableCell cell = new HtmlTableCell();
        //讀取相關資料
        try
        {
            string strSQL = @"SELECT A.name,A.fstype,A.total,A.free ,A.mountpt
                                   , A.usedpcnt
                            FROM Disks A 
                            WHERE DataKey = @DataKey ";

            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            //style="border:3px #FFAC55 solid;padding:5px;" 

            tb.Attributes.CssStyle["empty-cells"] = "show";
            //tb.Border = 1;
            tb.Style.Add("width", "100%");
            int i = 0;
            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {
                    if (i == 0)
                    {
                        row = new HtmlTableRow();                       

                        if (foundRows.Length > 0)
                        {
                            columndes = foundRows[0]["columndesc"].ToString().Split(',');
                            columndwidth = foundRows[0]["columndwidth"].ToString().Split(',');
                            int z = 0;
                            foreach (string column in columndes)
                            {
                                cell = new HtmlTableCell();
                                cell.BgColor = "DEE1E7";
                                cell.Style.Add("font-size", "16pt");
                                cell.Style.Add("width", columndwidth[z]);
                                cell.Style.Add("font-weight", "bold");
                                cell.InnerText = column;
                                row.Cells.Add(cell);
                                z++;
                            }
                        }

                        tb.Rows.Add(row);
                    }
                    row = new HtmlTableRow();

                    columns = foundRows[0]["columnname"].ToString().Split(',');
                    foreach (string column in columns)
                    {

                        cell = new HtmlTableCell();
                        cell.BgColor = "F6F6F6";
                        cell.Style.Add("font-size", "16pt");
                        cell.InnerText = Convert.ToString(dv[column]);
                        row.Cells.Add(cell);
                        
                    }

                    tb.Rows.Add(row);

                    i++;
                }
            }


        }
        catch (Exception ex)
        {
            throw ex;
        }
        return tb;
    }
    protected HtmlTable ServiceList(string DataKey)
    {
        DataRow[] foundRows;
        foundRows = dt_Layout.Select("type = 'Services'");
        string[] columns, columndes, columndwidth;

        HtmlTable tb = new HtmlTable();
        HtmlTableRow row = new HtmlTableRow();
        HtmlTableCell cell = new HtmlTableCell();
        //讀取相關資料
        try
        {
            string strSQL = @"SELECT A.name,A.runtype
                            , E.OSType OSType,IIF (E.ServicesName is null , 'Yes', 'NO' ) status
                            , case when isnull(B.servicedesc,'') = '' then A.[desc] else B.servicedesc end [Desc]
                           from Services A left join ServiceDesc B on A.DataKey = B.DataKey and A.name = B.servicename
                                left JOIN (SELECT ServicesName,OSType FROM ServiceOptionalU ) E ON (A.name LIKE '%' + E.ServicesName + '%')
                            WHERE A.DataKey = @DataKey 
                             order by A.runtype,A.name";

            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            //style="border:3px #FFAC55 solid;padding:5px;" 
            string[] OSType = null;
            Boolean ISOSType = false;
            tb.Attributes.CssStyle["empty-cells"] = "show";
            //tb.Border = 1;
            tb.Style.Add("width", "100%");
            int i = 0;
            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {
                    if (i == 0)
                    {
                        row = new HtmlTableRow();

                        if (foundRows.Length > 0)
                        {
                            columndes = foundRows[0]["columndesc"].ToString().Split(',');
                            columndwidth = foundRows[0]["columndwidth"].ToString().Split(',');
                            int z = 0;
                            foreach (string column in columndes)
                            {
                                cell = new HtmlTableCell();
                                cell.BgColor = "DEE1E7";
                                cell.Style.Add("font-size", "16pt");
                                cell.Style.Add("width", columndwidth[z]);
                                cell.Style.Add("font-weight", "bold");
                                cell.InnerText = column;
                                row.Cells.Add(cell);
                                z++;
                            }
                        }

                        tb.Rows.Add(row);
                    }


                    #region 判斷是否合規
                    OSType = dv["OSType"].ToString().ToLower().Split(';');
                    ISOSType = false;
                    if (dv["OSType"].ToString() == "")
                    {
                        ISOSType = true;
                    }
                    else
                    {
                        for (int k = 0; k < OSType.Length; k++)
                        {
                            if (OSNAME.ToLower().Contains(OSType[k]) && OSType[k] != "")
                            {
                                ISOSType = true;
                            }

                        }
                    }

                    #endregion
                    row = new HtmlTableRow();

                    columns = foundRows[0]["columnname"].ToString().Split(',');
                    foreach (string column in columns)
                    {

                        cell = new HtmlTableCell();
                        cell.BgColor = "F6F6F6";
                        cell.Style.Add("font-size", "16pt");

                        if (column == "name")
                        {
                            cell.Style.Add("color", ISOSType && dv["status"].ToString() == "NO" ? "red" : "black");
                            cell.InnerText = (ISOSType && dv["status"].ToString() == "NO" ? "***" : "") + Convert.ToString(dv[column]);
                        }
                        else
                        {
                            cell.InnerText = Convert.ToString(dv[column]);
                        }

                        
                        row.Cells.Add(cell);

                    }

                    tb.Rows.Add(row);

                    i++;
                }
            }


        }
        catch (Exception ex)
        {
            
            throw ex;
        }
        return tb;
    }

    protected HtmlTable ServicesNecessary(string DataKey)
    {
        DataRow[] foundRows;
        foundRows = dt_Layout.Select("type = 'ServicesNecessary'");
        string[] columns, columndes, columndwidth;

        HtmlTable tb = new HtmlTable();
        HtmlTableRow row = new HtmlTableRow();
        HtmlTableCell cell = new HtmlTableCell();
        //讀取相關資料
        try
        {
            string strSQL = @"select A.ServicesName,A.OSType 
                                FROM ServicesNecessaryU A 
                                where not exists(select name from Services E  WHERE DataKey =  @DataKey and E.name like '%' + A.ServicesName + '%')
                              ";


            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            //style="border:3px #FFAC55 solid;padding:5px;" 

            tb.Attributes.CssStyle["empty-cells"] = "show";
            //tb.Border = 1;
            tb.Style.Add("width", "100%");
            int i = 0;
            string[] OSType = null;
            Boolean ISOSType = false;
            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {
                    if (i == 0)
                    {
                        row = new HtmlTableRow();

                        if (foundRows.Length > 0)
                        {
                            columndes = foundRows[0]["columndesc"].ToString().Split(',');
                            columndwidth = foundRows[0]["columndwidth"].ToString().Split(',');
                            int z = 0;
                            foreach (string column in columndes)
                            {
                                cell = new HtmlTableCell();
                                cell.BgColor = "DEE1E7";
                                cell.Style.Add("font-size", "16pt");
                                cell.Style.Add("width", columndwidth[z]);
                                cell.Style.Add("font-weight", "bold");
                                cell.InnerText = column;
                                row.Cells.Add(cell);
                                z++;
                            }
                        }

                        tb.Rows.Add(row);
                    }


                    #region 合檢查
                    OSType = dv["OSType"].ToString().ToLower().Split(';');
                    ISOSType = false;
                    if (dv["OSType"].ToString() == "")
                    {
                        ISOSType = true;
                    }
                    else
                    {
                        for (int k = 0; k < OSType.Length; k++)
                        {
                            if (OSNAME.ToLower().Contains(OSType[k]) && OSType[k] != "")
                            {
                                ISOSType = true;
                            }

                        }
                    }
                    #endregion
                    if (ISOSType)
                    {
                        IS_ServicesNecessary = "Y";
                        row = new HtmlTableRow();

                        columns = foundRows[0]["columnname"].ToString().Split(',');
                        foreach (string column in columns)
                        {

                            cell = new HtmlTableCell();
                            cell.BgColor = "F6F6F6";
                            cell.Style.Add("font-size", "16pt");
                            cell.Style.Add("color", "red");
                            cell.InnerText = "***" + Convert.ToString(dv[column]);
                            row.Cells.Add(cell);

                        }

                        tb.Rows.Add(row);
                    }
                    i++;
                }
            }


        }
        catch (Exception ex)
        {

            throw ex;
        }
        return tb;
    }
    protected HtmlTable ProcesseList(string DataKey)
    {
        DataRow[] foundRows;
        foundRows = dt_Layout.Select("type = 'Process'");
        string[] columns, columndes, columndwidth;

        HtmlTable tb = new HtmlTable();
        HtmlTableRow row = new HtmlTableRow();
        HtmlTableCell cell = new HtmlTableCell();
        //讀取相關資料
        try
        {
            string strSQL = @"select distinct ProcessName, A.OSType, IIF (E.DataKey is null , 'NO', 'Yes' ) status
                                from [dbo].[ProcessNecessaryU]  A 
                                left join  (select  DataKey,runcmd from [Processes]  where DataKey=@DataKey ) E on E.runcmd LIKE '%' + a.ProcessName + '%' 
                              order by A.ProcessName
                           ";

            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            //style="border:3px #FFAC55 solid;padding:5px;" 

            tb.Attributes.CssStyle["empty-cells"] = "show";
            //tb.Border = 1;
            tb.Style.Add("width", "100%");
            int i = 0;
            string[] OSType = null;
            Boolean ISOSType = false;
            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {
                    if (i == 0)
                    {
                        row = new HtmlTableRow();

                        if (foundRows.Length > 0)
                        {
                            columndes = foundRows[0]["columndesc"].ToString().Split(',');
                            columndwidth = foundRows[0]["columndwidth"].ToString().Split(',');
                            int z = 0;
                            foreach (string column in columndes)
                            {
                                cell = new HtmlTableCell();
                                cell.BgColor = "DEE1E7";
                                cell.Style.Add("font-size", "16pt");
                                cell.Style.Add("width", columndwidth[z]);
                                cell.Style.Add("font-weight", "bold");
                                cell.InnerText = column;
                                row.Cells.Add(cell);
                                z++;
                            }
                        }

                        tb.Rows.Add(row);
                    }


                    #region 合檢查
                    OSType = dv["OSType"].ToString().ToLower().Split(';');
                    ISOSType = false;
                    if (dv["OSType"].ToString() == "")
                    {
                        ISOSType = true;
                    }
                    else
                    {
                        for (int k = 0; k < OSType.Length; k++)
                        {
                            if (OSNAME.ToLower().Contains(OSType[k]) && OSType[k] != "")
                            {
                                ISOSType = true;
                            }

                        }
                    }
                    #endregion
                    IS_Process = "Y";
                    row = new HtmlTableRow();

                    columns = foundRows[0]["columnname"].ToString().Split(',');
                    foreach (string column in columns)
                    {

                        cell = new HtmlTableCell();
                        cell.BgColor = "F6F6F6";
                        cell.Style.Add("font-size", "16pt");

                        if (column == "ProcessName")
                        {
                            cell.Style.Add("color", ISOSType && dv["status"].ToString() == "NO" ? "red" : "black");
                            cell.InnerText = (ISOSType && dv["status"].ToString() == "NO" ? "***" : "" )+ Convert.ToString(dv[column]);
                        }
                        else
                        {

                            cell.InnerText = Convert.ToString(dv[column]);
                        }
                        row.Cells.Add(cell);

                    }

                    tb.Rows.Add(row);
                    i++;
                }
            }


        }
        catch (Exception ex)
        {

            throw ex;
        }
        return tb;
    }
    protected HtmlTable TaskList(string DataKey)
    {
        DataRow[] foundRows;
        foundRows = dt_Layout.Select("type = 'Schedule'");
        string[] columns, columndes, columndwidth;

        HtmlTable tb = new HtmlTable();
        HtmlTableRow row = new HtmlTableRow();
        HtmlTableCell cell = new HtmlTableCell();
        //讀取相關資料
        try
        {
            string strSQL = @"SELECT A.exectime,A.cmds,A.owner
                                   , case when isnull(B.taskdesc,'') = '' then A.userfor else B.taskdesc end userfor
                            FROM Schedule A left join TaskDesc B on A.DataKey = B.DataKey and A.cmds = B.taskname
                            WHERE A.DataKey = @DataKey 
                            order by A.cmds,A.exectime";

            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            //style="border:3px #FFAC55 solid;padding:5px;" 

            tb.Attributes.CssStyle["empty-cells"] = "show";
            //tb.Border = 1;
            tb.Style.Add("width", "100%");
            int i = 0;
            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {
                    if (i == 0)
                    {
                        row = new HtmlTableRow();

                        if (foundRows.Length > 0)
                        {
                            columndes = foundRows[0]["columndesc"].ToString().Split(',');
                            columndwidth = foundRows[0]["columndwidth"].ToString().Split(',');
                            int z = 0;
                            foreach (string column in columndes)
                            {
                                cell = new HtmlTableCell();
                                cell.BgColor = "DEE1E7";
                                cell.Style.Add("font-size", "16pt");
                                cell.Style.Add("width", columndwidth[z]);
                                cell.Style.Add("font-weight", "bold");
                                cell.InnerText = column;
                                row.Cells.Add(cell);
                                z++;
                            }
                        }

                        tb.Rows.Add(row);
                    }

                    row = new HtmlTableRow();
                    columns = foundRows[0]["columnname"].ToString().Split(',');
                    foreach (string column in columns)
                    {

                        cell = new HtmlTableCell();
                        cell.BgColor = "F6F6F6";
                        cell.Style.Add("font-size", "16pt");
                        cell.InnerText = Convert.ToString(dv[column]);
                        row.Cells.Add(cell);

                    }

                    tb.Rows.Add(row);

                    i++;
                }
            }


        }
        catch (Exception ex)
        {
            throw ex;
        }
        return tb;
    }
    protected HtmlTable WebServerInfo(string DataKey)
    {
        string value=string.Empty;
        IS_WebServerInfo = "N";
        DataRow[] foundRows;
        foundRows = dt_Layout.Select("type = 'WebServerInfo'");
        string[] columns, columndes, columndwidth;

        HtmlTable tb = new HtmlTable();
        HtmlTableRow row = new HtmlTableRow();
        HtmlTableCell cell = new HtmlTableCell();
        //讀取相關資料
        try
        {
            string strSQL = @"SELECT A.type,A.options,A.value,A.conf,case when A.value = 'N' then N'已關閉目錄瀏覽功能' else N'***未關閉目錄瀏覽功能' end  [desc]
                            FROM WebServerInfo A 
                            WHERE DataKey = @DataKey
                            ";
            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            //style="border:3px #FFAC55 solid;padding:5px;" 

            tb.Attributes.CssStyle["empty-cells"] = "show";
            //tb.Border = 1;
            tb.Style.Add("width", "100%");
            int i = 0;
            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {
                    IS_WebServerInfo = "Y";
                    if (i == 0)
                    {
                        row = new HtmlTableRow();
                        value = dv["value"].ToString().ToUpper();
                        if (value == "Y")
                        {
                            foundRows = dt_Layout.Select("type = 'WebServerInfoN'");
                        }
                        if (foundRows.Length > 0)
                        {
                            columndes = foundRows[0]["columndesc"].ToString().Split(',');
                            columndwidth = foundRows[0]["columndwidth"].ToString().Split(',');
                            int z = 0;
                            foreach (string column in columndes)
                            {
                                cell = new HtmlTableCell();
                                cell.BgColor = "DEE1E7";
                                cell.Style.Add("font-size", "16pt");
                                cell.Style.Add("width", columndwidth[z]);
                                cell.Style.Add("font-weight", "bold");
                                cell.InnerText = column;
                                row.Cells.Add(cell);
                                z++;
                            }
                        }

                        tb.Rows.Add(row);
                    }

                    row = new HtmlTableRow();
                    
                    columns = foundRows[0]["columnname"].ToString().Split(',');
                    foreach (string column in columns)
                    {

                        cell = new HtmlTableCell();
                        cell.BgColor = "F6F6F6";
                        cell.Style.Add("font-size", "16pt");
                        if (column == "desc")
                        {
                            cell.Style.Add("color", value =="Y" ? "red" : "black");
                            
                        }
                        cell.InnerText = Convert.ToString(dv[column]);
                        row.Cells.Add(cell);

                    }

                    tb.Rows.Add(row);

                    i++;
                }
            }


        }
        catch (Exception ex)
        {

            throw ex;
        }
        return tb;
    }

    protected HtmlTable UserList(string DataKey)
    {
        DataRow[] foundRows;
        foundRows = dt_Layout.Select("type = 'Users'");
        string[] columns, columndes, columndwidth;

        HtmlTable tb = new HtmlTable();
        HtmlTableRow row = new HtmlTableRow();
        HtmlTableCell cell = new HtmlTableCell();
        //讀取相關資料
        try
        {
            
            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            
            tb.Attributes.CssStyle["empty-cells"] = "show";
            //tb.Border = 1;
            tb.Style.Add("width", "100%");
            int i = 0;

            string strSQL = @"select S.OSNAME,A.name,A.sh,A.grps,A.id
                          from SecurityScanUList S inner join [Users] A on A.DataKey = S.DataKey
                          where S.DataKey = @DataKey 
                            order by Convert(bigint,isnull(A.ID,9999)) ";
            objParams.Clear();
            objParams.Add("DataKey", DbType.String, DataKey);
            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {
                    if (i == 0)
                    {
                        row = new HtmlTableRow();

                        if (foundRows.Length > 0)
                        {
                            columndes = foundRows[0]["columndesc"].ToString().Split(',');
                            columndwidth = foundRows[0]["columndwidth"].ToString().Split(',');
                            int z = 0;
                            foreach (string column in columndes)
                            {
                                cell = new HtmlTableCell();
                                cell.BgColor = "DEE1E7";
                                cell.Style.Add("font-size", "16pt");
                                cell.Style.Add("width", columndwidth[z]);
                                cell.Style.Add("font-weight", "bold");
                                cell.InnerText = column;
                                row.Cells.Add(cell);
                                z++;
                            }
                        }

                        tb.Rows.Add(row);
                    }


                    #region 判斷是否合規
                    strSQL = @"select * from RootDefautU a where @OSNAME LIKE '%' + a.OSType + '%'  order by AccountId";
                    objParams.Clear();
                    objParams.Add("OSNAME", DbType.String, OSNAME);
                    DataTable ddt = da.ExecuteDataTable(strSQL, objParams);
                    string Filter = "", AccountId = "";
                    string[] OSType = null;
                    Boolean ISOSType = false, iderrorstatus = false;
                    foreach (DataRow dr in ddt.Rows)
                    {
                        OSType = dr["OSType"].ToString().ToLower().Split(';');
                        Filter = dr["Filter"].ToString();
                        AccountId = dr["AccountId"].ToString();

                        ISOSType = false;
                        if (dr["OSType"].ToString() == "")
                        {
                            ISOSType = true;
                        }
                        else
                        {
                            for (int k = 0; k < OSType.Length; k++)
                            {
                                if (OSNAME.ToLower().Contains(OSType[k]) && OSType[k] != "")
                                {
                                    ISOSType = true;
                                }

                            }
                        }
                        if (ISOSType)
                        {

                            Int64 n;
                            if (Int64.TryParse(AccountId, out n))  //數字格式
                            {
                                //數字
                                switch (Filter.ToUpper())
                                {
                                    case "L":
                                        if (Convert.ToInt64(dv["id"]) >= Convert.ToInt64(AccountId))
                                        {
                                            iderrorstatus = true;
                                        }
                                        break;
                                    case "LE":
                                        if (Convert.ToInt64(dv["id"]) > Convert.ToInt64(AccountId))
                                        {
                                            iderrorstatus = true;
                                        }
                                        break;
                                    case "E":
                                        if (Convert.ToInt64(dv["id"]) != Convert.ToInt64(AccountId))
                                        {
                                            iderrorstatus = true;
                                        }
                                        break;
                                    case "G":
                                        if (Convert.ToInt64(dv["id"]) <= Convert.ToInt64(AccountId))
                                        {
                                            iderrorstatus = true;
                                        }
                                        break;
                                    case "GE":
                                        if (Convert.ToInt64(dv["id"]) < Convert.ToInt64(AccountId))
                                        {
                                            iderrorstatus = true;
                                        }
                                        break;
                                    default:
                                        break;
                                }
                            }
                            else
                            {

                                if (iderrorstatus)
                                {
                                    //文字
                                    switch (Filter.ToUpper())
                                    {
                                        
                                        case "E":
                                            if (dv["name"].ToString() == AccountId)
                                            {
                                                iderrorstatus = false;
                                            }
                                            break;
                                        
                                        default:
                                            break;
                                    }
                                }
                            }

                        }
                    }


                    #endregion

                    row = new HtmlTableRow();
                    columns = foundRows[0]["columnname"].ToString().Split(',');
                    foreach (string column in columns)
                    {

                        cell = new HtmlTableCell();
                        cell.BgColor = "F6F6F6";
                        cell.Style.Add("font-size", "16pt");
                        if (column.ToUpper() == "ID")
                        {
                            cell.Style.Add("color", iderrorstatus ? "red" : "black");
                            cell.InnerText = (iderrorstatus ? "***" : "") + Convert.ToString(dv[column]);
                        }
                        else
                        {
                            cell.InnerText = Convert.ToString(dv[column]);
                        }
                        row.Cells.Add(cell);

                    }

                    tb.Rows.Add(row);

                    i++;
                }
            }


        }
        catch (Exception ex)
        {
            throw ex;
        }
        return tb;
    }
    protected HtmlTable UserGroupList(string DataKey)
    {
        DataRow[] foundRows;
        foundRows = dt_Layout.Select("type = 'Groups'");
        string[] columns, columndes, columndwidth;

        HtmlTable tb = new HtmlTable();
        HtmlTableRow row = new HtmlTableRow();
        HtmlTableCell cell = new HtmlTableCell();
        //讀取相關資料
        try
        {
            string strSQL = @"SELECT A.name,A.id,A.users
                            FROM Groups A 
                            WHERE DataKey = @DataKey 
                            order by Convert(bigint,isnull(A.ID,9999))  ";

            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            //style="border:3px #FFAC55 solid;padding:5px;" 

            tb.Attributes.CssStyle["empty-cells"] = "show";
            //tb.Border = 1;
            tb.Style.Add("width", "100%");
            int i = 0;
            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {
                    if (i == 0)
                    {
                        row = new HtmlTableRow();

                        if (foundRows.Length > 0)
                        {
                            columndes = foundRows[0]["columndesc"].ToString().Split(',');
                            columndwidth = foundRows[0]["columndwidth"].ToString().Split(',');
                            int z = 0;
                            foreach (string column in columndes)
                            {
                                cell = new HtmlTableCell();
                                cell.BgColor = "DEE1E7";
                                cell.Style.Add("font-size", "16pt");
                                cell.Style.Add("width", columndwidth[z]);
                                cell.Style.Add("font-weight", "bold");
                                
                                cell.InnerText = column;
                                row.Cells.Add(cell);
                                z++;
                            }
                        }

                        tb.Rows.Add(row);
                    }

                    row = new HtmlTableRow();
                    columns = foundRows[0]["columnname"].ToString().Split(',');
                    foreach (string column in columns)
                    {

                        cell = new HtmlTableCell();
                        cell.BgColor = "F6F6F6";
                        cell.Style.Add("font-size", "16pt");
                        cell.Style.Add("word-break", "break-all");
                        cell.InnerText = Convert.ToString(dv[column]);
                        row.Cells.Add(cell);

                    }

                    tb.Rows.Add(row);

                    i++;
                }
            }


        }
        catch (Exception ex)
        {
            throw ex;
        }
        return tb;
    }
    protected HtmlTable SystemConfigs(string DataKey)
    {
        DataRow[] foundRows;
        foundRows = dt_Layout.Select("type = 'SystemConfigs'");
        string[] columns, columndes, columndwidth;

        HtmlTable tb = new HtmlTable();
        HtmlTableRow row = new HtmlTableRow();
        HtmlTableCell cell = new HtmlTableCell();
        //讀取相關資料
        try
        {
//            string strSQL = @"SELECT A.path,A.access,A.owner,E.FilePath,E.AccessAuthority,E.OSType
//                                   , case when E.FilePath is null then 'N' when A.access <> E.AccessAuthority then 'Y' else 'N' end errorstatus
//                            FROM SystemConfigs A  left join (select FilePath,AccessAuthority,OStype from [dbo].[SystemConfigsSetU] ) E on A.path = E.FilePath 
//                            WHERE A.DataKey = @DataKey 
//                            order by A.path ";
            string strSQL = @"SELECT A.path,A.access,A.owner,E.FilePath,E.AccessAuthority,E.OSType
                                   , case when E.FilePath is null then 'N' when A.access <> E.AccessAuthority then 'Y' else 'N' end errorstatus
                            FROM SystemConfigs A  left join (select FilePath,AccessAuthority,OStype from [dbo].[SystemConfigsSetU] where (OSType = '' or OSType like @OSNAME) ) E on A.path = E.FilePath 
                            WHERE A.DataKey = @DataKey 
                            order by A.path ";

            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            objParams.Add("OSNAME", DbType.String, "%" + OSNAME + "%");
            //style="border:3px #FFAC55 solid;padding:5px;" 

            tb.Attributes.CssStyle["empty-cells"] = "show";
            //tb.Border = 1;
            tb.Style.Add("width", "100%");
            int i = 0;
            string[] OSType = null;
            Boolean ISOSType = false;
            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {
                    if (i == 0)
                    {
                        row = new HtmlTableRow();

                        if (foundRows.Length > 0)
                        {
                            columndes = foundRows[0]["columndesc"].ToString().Split(',');
                            columndwidth = foundRows[0]["columndwidth"].ToString().Split(',');
                            int z = 0;
                            foreach (string column in columndes)
                            {
                                cell = new HtmlTableCell();
                                cell.BgColor = "DEE1E7";
                                cell.Style.Add("font-size", "16pt");
                                cell.Style.Add("width", columndwidth[z]);
                                cell.Style.Add("font-weight", "bold");
                                cell.InnerText = column;
                                row.Cells.Add(cell);
                                z++;
                            }
                        }

                        tb.Rows.Add(row);
                    }

                    row = new HtmlTableRow();

                    #region 判斷是否合規
                    OSType = dv["OSType"].ToString().ToLower().Split(';');
                    ISOSType = false;
                    if (dv["OSType"].ToString() == "")
                    {
                        ISOSType = true;
                    }
                    else
                    {
                        for (int k = 0; k < OSType.Length; k++)
                        {
                            if (OSNAME.ToLower().Contains(OSType[k]) && OSType[k] != "")
                            {
                                ISOSType = true;
                            }

                        }
                    }
                    #endregion
                    columns = foundRows[0]["columnname"].ToString().Split(',');
                    foreach (string column in columns)
                    {

                        cell = new HtmlTableCell();
                        cell.BgColor = "F6F6F6";
                        cell.Style.Add("font-size", "16pt");
                        if (column == "access")
                        {
                            cell.Style.Add("color", ISOSType && dv["errorstatus"].ToString() == "Y" ? "red" : "black");
                            cell.InnerText = (ISOSType && dv["errorstatus"].ToString() == "Y" ? "***" : "") + Convert.ToString(dv[column]);
                        }
                        else
                        {
                            cell.InnerText = Convert.ToString(dv[column]);
                        }
                        row.Cells.Add(cell);

                    }

                    tb.Rows.Add(row);

                    i++;
                }
            }


        }
        catch (Exception ex)
        {
            throw ex;
        }
        return tb;
    }
    protected HtmlTable RootAccess(string DataKey)
    {
        DataRow[] foundRows;
        foundRows = dt_Layout.Select("type = 'RootAccess'");
        string[] columns, columndes, columndwidth;

        HtmlTable tb = new HtmlTable();
        HtmlTableRow row = new HtmlTableRow();
        HtmlTableCell cell = new HtmlTableCell();
        //讀取相關資料
        try
        {
            string strSQL = @"SELECT A.name,A.type,A.access,A.owner,E.catalogName,E.OSType
                                    , case when E.catalogName is null then 'Y' else 'N' end errstatus
                                    --, case when E.catalogName is null then '' else N'系統預設' end userfor
                                    , case when B.RootDesc is null then  case when E.catalogName is null then '' else N'系統預設' end else B.RootDesc end userfor

                            FROM RootAccess A  left join RootDesc B on A.DataKey = B.DataKey and A.name = B.RootName
                                               left join RootAccessNecessaryU E on A.name = E.catalogName
                            WHERE A.DataKey = @DataKey 
                            order by A.type,A.name ";


            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            //style="border:3px #FFAC55 solid;padding:5px;" 

            tb.Attributes.CssStyle["empty-cells"] = "show";
            //tb.Border = 1;
            tb.Style.Add("width", "100%");
            int i = 0;
            string[] OSType = null;
            Boolean ISOSType = false;
            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {
                    if (i == 0)
                    {
                        row = new HtmlTableRow();

                        if (foundRows.Length > 0)
                        {
                            columndes = foundRows[0]["columndesc"].ToString().Split(',');
                            columndwidth = foundRows[0]["columndwidth"].ToString().Split(',');
                            int z = 0;
                            foreach (string column in columndes)
                            {
                                cell = new HtmlTableCell();
                                cell.BgColor = "DEE1E7";
                                cell.Style.Add("font-size", "16pt");
                                cell.Style.Add("width", columndwidth[z]);
                                cell.Style.Add("font-weight", "bold");
                                cell.InnerText = column;
                                row.Cells.Add(cell);
                                z++;
                            }
                        }

                        tb.Rows.Add(row);
                    }
                    

                    #region 判斷是否合規
                    OSType = dv["OSType"].ToString().ToLower().Split(';');
                    ISOSType = false;
                    if (dv["OSType"].ToString() == "")
                    {
                        ISOSType = true;
                    }
                    else
                    {
                        for (int k = 0; k < OSType.Length; k++)
                        {
                            if (OSNAME.ToLower().Contains(OSType[k]) && OSType[k] != "")
                            {
                                ISOSType = true;
                            }

                        }
                    }

                    #endregion
                    row = new HtmlTableRow();
                    columns = foundRows[0]["columnname"].ToString().Split(',');
                    foreach (string column in columns)
                    {

                        cell = new HtmlTableCell();
                        cell.BgColor = "F6F6F6";
                        cell.Style.Add("font-size", "16pt");
                        if (column == "name")
                        {
                            cell.Style.Add("color", ISOSType && dv["errstatus"].ToString() == "Y" ? "red" : "black");
                            cell.InnerText = (ISOSType && dv["errstatus"].ToString() == "Y" ? "***" : "") + Convert.ToString(dv[column]);
                        }
                        else
                        {
                            cell.InnerText = Convert.ToString(dv[column]);
                        }
                        row.Cells.Add(cell);

                    }

                    tb.Rows.Add(row);

                    i++;
                }
            }


        }
        catch (Exception ex)
        {
            throw ex;
        }
        return tb;
    }
    protected HtmlTable Policy(string DataKey,string type)
    {
        DataRow[] foundRows;
        foundRows = dt_Layout.Select(string.Format("type = 'Policie_{0}'", type));
        string[] columns, columndes, columndwidth;

        HtmlTable tb = new HtmlTable();
        HtmlTableRow row = new HtmlTableRow();
        HtmlTableCell cell = new HtmlTableCell();
        //讀取相關資料
        try
        {
            string strSQL = @" select A.name,A.value ,E.Policy,E.OSType,E.SetPoint
                                    , case when  isnull(A.value,'') <> E.SetPoint then 'Y' else 'N' end errstatus
                            from Policies A left join  PolicyNecessaryU E on A.name = E.Policy
                            WHERE A.DataKey = @DataKey and A.type = @type";

            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            objParams.Add("type", DbType.String, type);
            //style="border:3px #FFAC55 solid;padding:5px;" 

            tb.Attributes.CssStyle["empty-cells"] = "show";
            //tb.Border = 1;
            tb.Style.Add("width", "100%");
            int i = 0;
            string[] OSType = null;
            Boolean ISOSType = false;
            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {
                    if (i == 0)
                    {
                        row = new HtmlTableRow();

                        if (foundRows.Length > 0)
                        {
                            columndes = foundRows[0]["columndesc"].ToString().Split(',');
                            columndwidth = foundRows[0]["columndwidth"].ToString().Split(',');
                            int z = 0;
                            foreach (string column in columndes)
                            {
                                cell = new HtmlTableCell();
                                cell.BgColor = "DEE1E7";
                                cell.Style.Add("font-size", "16pt");
                                cell.Style.Add("width", columndwidth[z]);
                                cell.Style.Add("font-weight", "bold");
                                cell.InnerText = column;
                                row.Cells.Add(cell);
                                z++;
                            }
                        }

                        tb.Rows.Add(row);
                    }

                    #region 判斷是否合規
                    //OSType = dv["OSType"].ToString().ToLower().Split(';');
                    //ISOSType = false;
                    //if (dv["OSType"].ToString() == "")
                    //{
                    //    ISOSType = true;
                    //}
                    //else
                    //{
                    //    for (int z = 0; z < OSType.Length; z++)
                    //    {
                    //        if (OSNAME.ToLower().Contains(OSType[z]) && OSType[z] != "")
                    //        {
                    //            ISOSType = true;
                    //        }

                    //    }
                    //}
                    ISOSType = true;


                    string strcolumn = "";
                    ResourceManager ReportRex = Resources.ReportRex.ResourceManager;
                    row = new HtmlTableRow();
                    columns = foundRows[0]["columnname"].ToString().Split(',');
                    int k = 0;
                    foreach (string column in columns)
                    {
                        try
                        {
                            if (k == 0)
                            {
                                strcolumn = ReportRex.GetString(Convert.ToString(dv[column]));
                                strcolumn = strcolumn == null ? Convert.ToString(dv[column]) : strcolumn;
                            }
                            else
                            {
                                strcolumn = Convert.ToString(dv[column]);
                            }

                        }
                        catch (Exception ex)
                        {
                            strcolumn = column;
                        }
                        cell = new HtmlTableCell();
                        cell.BgColor = "F6F6F6";
                        cell.Style.Add("font-size", "16pt");
                        if (column == "value")
                        {
                            //cell.Style.Add("color", ISOSType && dv["errstatus"].ToString() == "Y" ? "red" : "black");
                            //cell.InnerText = (ISOSType && dv["errstatus"].ToString() == "Y" ? "***" : "") +  strcolumn;

                            string std_val = dv["SetPoint"].ToString(), val = dv["value"].ToString();

                            EADMCommon EADMCommon = new EADMCommon();
                            bool isAbnormal = CommonInfo.GCB_isAbnormal(dv["value"].ToString(), dv["SetPoint"].ToString(), dv["name"].ToString());
                            
                            cell.Style.Add("color", ISOSType && isAbnormal ? "red" : "black");
                            cell.InnerText = (ISOSType && isAbnormal ? "***" : "") +  strcolumn;
                            //除錯用，可看盤點值和比較值
                            //cell.InnerText = (ISOSType && isAbnormal ? "***" : "") +  strcolumn + ";" + std_val;
                        }
                        else
                        {
                            cell.InnerText = strcolumn;
                        }
                        row.Cells.Add(cell);
                        k++;
                    }

                    #endregion
                    tb.Rows.Add(row);

                    i++;
                }
            }


        }
        catch (Exception ex)
        {
            throw ex;
        }
        return tb;
    }

    protected string Policy_value(string DataKey, string type)
    {
        string strValue = "";
        //讀取相關資料
        try
        {
            string strSQL = @" select A.name,A.value ,E.Policy,E.OSType,E.SetPoint
                                    , case when isnull(A.value,'') <> E.SetPoint then 'Y' else 'N' end errstatus
                            from Policies A left join  PolicyNecessaryU E on A.name = E.Policy
                            WHERE A.DataKey = @DataKey and A.type = @type";

            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            objParams.Add("type", DbType.String, type);
            
            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {
                    strValue = dv["value"].ToString();
                    break;
                }
            }


        }
        catch (Exception ex)
        {
            throw ex;
        }
        return strValue;
    }

    protected HtmlTable Package(string DataKey)
    {
        DataRow[] foundRows;
        foundRows = dt_Layout.Select("type = 'Packages'");
        string[] columns, columndes, columndwidth;

        HtmlTable tb = new HtmlTable();
        HtmlTableRow row = new HtmlTableRow();
        HtmlTableCell cell = new HtmlTableCell();
        //讀取相關資料
        try
        {
            string strSQL = @"select A.KitName name,E.ver,A.Version,A.OSType
                            , case when E.ver is null then 'NO'  when  isnull(A.Version,'') = '' or isnull(A.Version,'')  = E.ver then 'Yes'  else 'NO' end status
		                    ,  case when E.ver is null then 'Y' else '' end notexists
		                    ,  case when  isnull(A.Version,'') <> '' and isnull(A.Version,'') <> E.ver then 'Y' else '' end noversion
                            from [dbo].[PackageNecessaryU] A
                             left join(select name,ver from [Packages] where  DataKey = @DataKey ) E on A.KitName = E.name  
                            order by A.kitname
                             ";

            DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
            ParameterCollection objParams = new ParameterCollection();
            objParams.Add("DataKey", DbType.String, DataKey);
            //style="border:3px #FFAC55 solid;padding:5px;" 

            tb.Attributes.CssStyle["empty-cells"] = "show";
            //tb.Border = 1;
            tb.Style.Add("width", "100%");
            int i = 0;
            string[] OSType = null;
            Boolean ISOSType = false;
            string iserror;
            using (IDataReader dv = da.ExecuteReader(strSQL, objParams))
            {
                while (dv.Read())
                {
                    if (i == 0)
                    {
                        row = new HtmlTableRow();

                        if (foundRows.Length > 0)
                        {
                            columndes = foundRows[0]["columndesc"].ToString().Split(',');
                            columndwidth = foundRows[0]["columndwidth"].ToString().Split(',');
                            int z = 0;
                            foreach (string column in columndes)
                            {
                                cell = new HtmlTableCell();
                                cell.BgColor = "DEE1E7";
                                cell.Style.Add("font-size", "16pt");
                                cell.Style.Add("width", columndwidth[z]);
                                cell.Style.Add("font-weight", "bold");
                                cell.InnerText = column;
                                row.Cells.Add(cell);
                                z++;
                            }
                        }

                        tb.Rows.Add(row);
                    }
                    #region 判斷是否合規
                    iserror = "";
                    OSType = dv["OSType"].ToString().ToLower().Split(';');
                    ISOSType = false;
                    if (dv["OSType"].ToString() == "")
                    {
                        ISOSType = true;
                    }
                    else
                    {
                        for (int k = 0; k < OSType.Length; k++)
                        {
                            if (OSNAME.ToLower().Contains(OSType[k]) && OSType[k] != "")
                            {
                                ISOSType = true;
                            }

                        }
                    }
                    //判斷必要安裝的Package是否存在
                    if (ISOSType)
                    {
                        if (dv["status"].ToString() == "NO")
                        {
                            //有問題
                            iserror = "Y";

                        }
                    }
                    #endregion

                    if (ISOSType)  //有設定到OS的才顯示 20180917 關鍵字cifs_fs是AIX專用，非AIX主機上，報表能否不顯示
                    {
                        row = new HtmlTableRow();
                        columns = foundRows[0]["columnname"].ToString().Split(',');
                        foreach (string column in columns)
                        {

                            cell = new HtmlTableCell();
                            cell.BgColor = "F6F6F6";
                            cell.Style.Add("font-size", "16pt");
                            if (column == "name")
                            {
                                cell.Style.Add("color", iserror == "Y" && dv["notexists"].ToString() == "Y" ? "red" : "black");
                                cell.InnerText = (iserror == "Y" && dv["notexists"].ToString() == "Y" ? "***" : "") + Convert.ToString(dv[column]);
                            }
                            else if (column == "ver")
                            {
                                cell.Style.Add("color", iserror == "Y" && dv["noversion"].ToString() == "Y" ? "red" : "black");
                                cell.InnerText = (iserror == "Y" && dv["noversion"].ToString() == "Y" ? "***" : "") + Convert.ToString(dv[column]);
                            }
                            else
                            {
                                cell.InnerText = Convert.ToString(dv[column]);
                            }
                            row.Cells.Add(cell);

                        }

                        tb.Rows.Add(row);
                    }
                    i++;
                }
            }


        }
        catch (Exception ex)
        {
            throw ex;
        }
        return tb;
    }
    public DataTable dt_Layout;
    public void init(string ostype)
    {
        EADMCommon EADMCommon = new EADMCommon();
        dt_Layout = EADMCommon.init_layout(ostype);        

    }
    
}
