﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Web;

public partial class ServerListU : CallbackPage
{
    private TempatePage_Query _master;
    /// <summary>
    ///  初始化動作
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        Event_Register();

        if (!IsPostBack)
        {
            Control_Data_Binding();
        }
        else if (HttpUtility.HtmlEncode(Request.Form["hdfRefresh"]) == "Y")
        {
            GridBind();
        }
    }

    /// <summary>
    /// 非同步回呼事件
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_CallBack(object sender, CallbackEventArgs e)
    {
        string strResult = base.GetCallBackMethod(this, e.Argument);
        e.Result = strResult;
    }

    /// <summary>
    /// 初始設定
    /// </summary>
    private void Event_Register()
    {
        base.CallBack += new CallBackEventHandler(Page_CallBack);
        _master = this.Master as TempatePage_Query;

        _master.ToolSave.Visible = false;
        //預設未查詢前(筆數為0)部份按鈕為灰色
        if (IsPostBack == false)
        {
            //_master.ToolEdit.Disabled = true;
            _master.ToolDel.Disabled = true;
            _master.ToolPreview.Disabled = true;
            _master.ToolExcel.Disabled = true;
            _master.ToolOutputCsv.Disabled = true;
            _master.ToolOutputHtml.Disabled = true;
        }

        //檢查是否有選取資料
        base.MustKeyIn2(HiddenField1.ClientID, Resources.Language.MSG0040);
        //_master.ToolEdit.Attributes["onclick"] = base.GetValidationScript();
        _master.ToolDel.Attributes["onclick"] = base.GetValidationScript();
        _master.ToolPreview.Attributes["onclick"] = base.GetValidationScript();
    }

    private void Control_Data_Binding()
    {
        _pnlGrid.Style["Display"] = "none";


        if (base.FirstLoad())
        {
            //base.RestoreCondition();
            GridBind();
        }
    }

    #region Button Event

    /// <summary>
    /// 查詢資料
    /// </summary>
    protected override void OnSearch_Click(object sender, EventArgs e)
    {
        GridView1.PageIndex = 0;
        GridBind();
    }



    protected override void OnImportClick(object sender, EventArgs e)
    {
        ClientScript.RegisterStartupScript(GetType(), "", "showWindow('','ServerListUImport.aspx','900','200');", true);
    }

    #endregion

    #region Grid Event

    /// <summary>
    /// Grid1來源
    /// </summary>
    public void GridBind()
    {
        #region 查詢條件&回上一頁必要

        //Dictionary<string, string> Params = new Dictionary<string, string>();
        //Params.Add(txtPolicy.ID, HttpUtility.HtmlEncode(txtPolicy.Text));
        //Params.Add(txtSetPoint.ID, HttpUtility.HtmlEncode(txtSetPoint.Text));
        //Params.Add(txtOSType.ID, HttpUtility.HtmlEncode(txtOSType.Text));
        //Params.Add(txtRemark.ID, HttpUtility.HtmlEncode(txtRemark.Text));
        //Params.Add("GridView1.PageIndex", GridView1.PageIndex.ToString());
        //Params.Add("GridDataPage1.SortExpression", GridDataPage1.SortExpression);
        //Params.Add("GridDataPage1.SortDirection", GridDataPage1.SortDirection);
        //base.KeepCondition(Params);

        #endregion

        _pnlGrid.Style["Display"] = "";

        string strSQL = @"SELECT  [DataKey]
                          ,[ServerNum]
                          ,[ServerName] as PCName
                          ,[ServerType]
                          ,[effect]
                          ,[SysNum]
                          ,[SysName]
                          ,[PublicIP] as IPAddress
                          ,[PrivateIP]
                          ,[ExternalIP]
                          ,[Stages]
                          ,[Location]
                          ,[Company]
                          ,[Cabinet]
                          ,[OSName]
                          ,[isVM]
                          ,[BuyDepartment]
                          ,[TransferDate]
                          ,[Department] as UseDepartment
                          ,[SysType]
                          ,[SysGroup]
                          ,[description]
                          ,[UpdUser]
                          ,[UpdDateTime] as UpdateDate
                            FROM ServerListU
                            where 1=1 ";

        DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
        ParameterCollection parameters = new ParameterCollection();
        
        if (!string.IsNullOrEmpty(txtPCName.Text))
        {
            strSQL += " AND ServerName like @PCName ";
            parameters.Add("PCName", DbType.String, "%" + txtPCName.Text + "%");
        }

        if (!string.IsNullOrEmpty(txtIPAddress.Text))
        {
            strSQL += " AND PublicIP like @IPAddress ";
            parameters.Add("IPAddress", DbType.String, "%" + txtIPAddress.Text + "%");
        }

        if (!string.IsNullOrEmpty(txtUseDepartment.Text))
        {
            strSQL += " AND Department like @Department ";
            parameters.Add("Department", DbType.String, "%" + txtUseDepartment.Text + "%");
        }
        DataTable dtb = da.ExecuteDataTable(strSQL, parameters);

        //匯出用資訊
        this.OutputExcelSql = strSQL + " order by " + GridDataPage1.SortExpression;
        this.OutputExcelParameter = parameters;

        int[] cellsWidth = new int[] { 150, 600, 100, 200 };
        GridDataPage1.SetDataSource(dtb, cellsWidth);

        if (dtb.Rows.Count > 0)
        {
            _master.ToolEdit.Disabled = false;
            _master.ToolDel.Disabled = false;
            _master.ToolPreview.Disabled = false;
            _master.ToolExcel.Disabled = false;
            _master.ToolOutputCsv.Disabled = false;
            _master.ToolOutputHtml.Disabled = false;
        }
        else
        {
            //_master.ToolEdit.Disabled = true;
            _master.ToolDel.Disabled = true;
            _master.ToolPreview.Disabled = true;
            _master.ToolExcel.Disabled = true;
            _master.ToolOutputCsv.Disabled = true;
            _master.ToolOutputHtml.Disabled = true;
        }
    }

    #endregion
}