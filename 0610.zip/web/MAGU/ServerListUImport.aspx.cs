﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web;
using System.IO;
using System.Collections;
using System.Web.Script.Serialization;

public partial class ServerListUImport : CallbackPage
{
    #region Page Event

    TempatePage_Query _master;
    /// <summary>
    /// 初始化動作
    /// </summary>
    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        Event_Register();
        //txtManualPath.Text = "";
        if (!IsPostBack)
        {
        }
    }
    /// <summary>
    /// 非同步回呼事件
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_CallBack(object sender, CallbackEventArgs e)
    {
        string strResult = base.GetCallBackMethod(this, e.Argument);
        e.Result = strResult;
    }
    /// <summary>
    /// 初始設定
    /// </summary>
    private void Event_Register()
    {
        base.CallBack += new CallBackEventHandler(Page_CallBack);
        _master = this.Master as TempatePage_Query;

        //預設未查詢前(筆數為0)部份按鈕為灰色
        if (IsPostBack == false)
        {
            _master.ToolOutputHtml.Disabled = true;
            _master.ToolMaintan.Disabled = true;
        }
        _master.ToolMaintan.Attributes["onclick"] = base.GetValidationScript();
    }

    #endregion

    protected void FileUpload1_Unload(object sender, EventArgs e)
    {
        string strMessage = "", jsScript = "";
        try
        {
            if (FileUpload1.HasFile == false)  // FU1.FileName 只有 "檔案名稱.附檔名"，並沒有 Client 端的完整理路徑    
                return;

            string filename = FileUpload1.FileName;
            string extension = Path.GetExtension(filename).ToLowerInvariant();
            // 判斷是否為允許上傳的檔案附檔名             
            List<string> allowedExtextsion = new List<string> { ".xls", ".xlsx" };
            if (allowedExtextsion.IndexOf(extension) == -1)
            {
                strMessage = "上傳檔案需為Excel File";
                jsScript = @"<script>$(document).ready(function () {alert('" + strMessage + "');})</script>";
                ClientScript.RegisterClientScriptBlock(GetType(), "", jsScript);
                return;
            }
        }
        catch (Exception ex)
        {
            //Utility.Write(ex);
            //Response.Write("<Script language='JavaScript'>alert('檔案上傳失敗!!');</Script>");
            strMessage = "檔案上傳失敗!!";
            jsScript = @"<script>$(document).ready(function () {alert('" + strMessage + "');})</script>";
            ClientScript.RegisterClientScriptBlock(GetType(), "", jsScript);
            return;
        }
    }

    protected void btn_ApplySend_Click(object sender, EventArgs e)
    {

        if (FileUpload1.HasFile == true)
        {
            try
            {
                string strMessage = "", jsScript = "";
                string ServerFilename = "";
                List<string> ClientFilename = new List<string> { FileUpload1.FileName };
                string extension = Path.GetExtension(ClientFilename[0]).ToLowerInvariant();

                if (FileUpload1.FileName.IndexOf(".xls") == -1 && FileUpload1.FileName.IndexOf(".xlsx") == -1)
                {
                    strMessage = "上傳檔案需為Excel File";
                    jsScript = @"<script>$(document).ready(function () {alert('" + strMessage + "');})</script>";
                    ClientScript.RegisterClientScriptBlock(GetType(), "", jsScript);
                    return;
                }

                // 檢查 Server 上該資料夾是否存在，不存在就自動建立             
                //string serverDir = @"D:\FileUploadDemo";
                string serverDir = Server.MapPath("~") + @"\UPLOAD\" + DateTime.Now.ToString("yyyyMMdd");
                if (Directory.Exists(serverDir) == false)
                    Directory.CreateDirectory(serverDir);

                string serverFilePath = Path.Combine(serverDir, ClientFilename[0]);
                string fileNameOnly = Path.GetFileNameWithoutExtension(ClientFilename[0]);
                int fileCount = 1;
                while (File.Exists(serverFilePath))
                {
                    // 重覆檔案的命名規則為 檔名_1、檔名_2 以此類推                 
                    ServerFilename = string.Concat(fileNameOnly, "_", fileCount, extension);
                    serverFilePath = Path.Combine(serverDir, ServerFilename);
                    fileCount++;
                }
                // 把檔案傳入指定的 Server 內路徑             
                try
                {
                    FileUpload1.SaveAs(serverFilePath);
                }
                catch (Exception ex)
                {
                    strMessage = "上傳Excel資料失敗";
                    jsScript = @"<script>$(document).ready(function () {alert('" + ex.Message + "');})</script>";
                    ClientScript.RegisterClientScriptBlock(GetType(), "", jsScript);
                }


                string FILENAME = serverFilePath;
                FileUtil FileUtil = new FileUtil();
                DataTable dtExcel = FileUtil.ReadExcelAsTableNPOI(FILENAME);

                if (dtExcel.Rows.Count > 0)
                {

                    #region 檢查EXCEL內容

                    if(!dtExcel.Columns.Contains("實體IP") || !dtExcel.Columns.Contains("業務主辦科"))
                    {
                        strMessage = "Excel資料格式不正確，需要有欄位:[伺服主機名稱]、[實體IP]、[業務主辦科]";
                        jsScript = @"<script>$(document).ready(function () {alert('" + strMessage + "');})</script>";
                        ClientScript.RegisterClientScriptBlock(GetType(), "", jsScript);
                        return;
                    }

                    string errmsg = "";
                    for (int i = 0; i < dtExcel.Rows.Count; i++)
                    {
                        if (string.IsNullOrEmpty(dtExcel.Rows[i]["業務主辦科"].ToString().Trim()))
                        {
                            errmsg += "第" + (i + 2) + @"行，[業務主辦科]不可為空白!\n";
                        }

                        //if (string.IsNullOrEmpty(dtExcel.Rows[i]["實體IP"].ToString().Trim()))
                        //{
                        //    errmsg += "第" + (i + 2) + @"行，[實體IP]不可為空白!\n";
                        //}

                        //if (string.IsNullOrEmpty(dtExcel.Rows[i]["伺服主機名稱"].ToString().Trim()))
                        //{
                        //    errmsg += "第" + (i + 2) + @"行，[伺服主機名稱]不可為空白!\n";
                        //}

                    }

                    if (!string.IsNullOrEmpty(errmsg))
                    {
                        jsScript = "<script>$(document).ready(function () {alert('" + errmsg + "');})</script>";
                        ClientScript.RegisterClientScriptBlock(GetType(), "", jsScript);
                        return;
                    }

                    //var duplicates = dtExcel.AsEnumerable().GroupBy(r => r["伺服主機名稱"]).Where(gr => gr.Count() > 1);
                    //if (duplicates.Any())
                    //{
                    //    string dept = String.Join(", ", duplicates.Select(dupl => dupl.Key));
                    //    jsScript = "<script>$(document).ready(function () {alert('[伺服主機名稱]:"+ dept + "重複!');})</script>";
                    //    ClientScript.RegisterClientScriptBlock(GetType(), "", jsScript);
                    //    return;
                    //}

                    #endregion

                    DataAccess da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
                    ParameterCollection Params = new ParameterCollection();
                    string sql = "";
                    sql = @"delete from ServerListU";
                    da.AddSql(sql, Params);

                    for (int i = 0; i < dtExcel.Rows.Count; i++)
                    {
                        string stage = dtExcel.Columns.Contains("環境") ? dtExcel.Rows[i]["環境"].ToString().Trim() : null;
                        if (stage != "正式")
                        {
                            break;
                        }
                        sql = @"INSERT INTO [dbo].[ServerListU]
                           ([DataKey]
                           ,[ServerNum]
                           ,[ServerName]
                           ,[ServerType]
                           ,[ServerModel]
                           ,[effect]
                           ,[SysNum]
                           ,[SysName]
                           ,[PublicIP]
                           ,[PrivateIP]
                           ,[ExternalIP]
                           ,[Stages]
                           ,[Location]
                           ,[Company]
                           ,[Cabinet]
                           ,[OSName]
                           ,[isVM]
                           ,[BuyDepartment]
                           ,[TransferDate]
                           ,[Department]
                           ,[SysType]
                           ,[SysGroup]
                           ,[description]
                           ,[UpdUser]
                           ,[UpdDateTime])
                     VALUES
                           (newID()
                           ,@ServerNum
                           ,@ServerName
                           ,@ServerType
                           ,@ServerModel
                           ,@effect
                           ,@SysNum
                           ,@SysName
                           ,@PublicIP
                           ,@PrivateIP
                           ,@ExternalIP
                           ,@Stages
                           ,@Location
                           ,@Company
                           ,@Cabinet
                           ,@OSName
                           ,@isVM
                           ,@BuyDepartment
                           ,@TransferDate
                           ,@Department
                           ,@SysType
                           ,@SysGroup
                           ,@description
                           ,@UpdUser
                           ,getdate())";
                        Params.Clear();
                        Params.Add("ServerNum", DbType.String, dtExcel.Columns.Contains("伺服主機編號") ? dtExcel.Rows[i]["伺服主機編號"].ToString().Trim() : null );
                        Params.Add("ServerName", DbType.String, dtExcel.Columns.Contains("伺服主機名稱") ? dtExcel.Rows[i]["伺服主機名稱"].ToString().Trim() : null);
                        Params.Add("ServerType", DbType.String, dtExcel.Columns.Contains("類別") ? dtExcel.Rows[i]["類別"].ToString().Trim() : null);
                        Params.Add("ServerModel", DbType.String, dtExcel.Columns.Contains("機型") ? dtExcel.Rows[i]["機型"].ToString().Trim() : null);
                        Params.Add("effect", DbType.String, dtExcel.Columns.Contains("用途") ? dtExcel.Rows[i]["用途"].ToString().Trim() : null);
                        Params.Add("SysNum", DbType.String, dtExcel.Columns.Contains("系統代號") ? dtExcel.Rows[i]["系統代號"].ToString().Trim() : null);
                        Params.Add("SysName", DbType.String, dtExcel.Columns.Contains("系統名稱") ? dtExcel.Rows[i]["系統名稱"].ToString().Trim() : null);
                        Params.Add("PublicIP", DbType.String, dtExcel.Columns.Contains("實體IP") ? dtExcel.Rows[i]["實體IP"].ToString().Trim() : null);
                        Params.Add("PrivateIP", DbType.String, dtExcel.Columns.Contains("虛擬IP") ? dtExcel.Rows[i]["虛擬IP"].ToString().Trim() : null);
                        Params.Add("ExternalIP", DbType.String, dtExcel.Columns.Contains("外部IP") ? dtExcel.Rows[i]["外部IP"].ToString().Trim() : null);
                        Params.Add("Stages", DbType.String, dtExcel.Columns.Contains("環境") ? dtExcel.Rows[i]["環境"].ToString().Trim() : null);
                        Params.Add("Location", DbType.String, dtExcel.Columns.Contains("位置") ? dtExcel.Rows[i]["位置"].ToString().Trim() : null);
                        Params.Add("Company", DbType.String, dtExcel.Columns.Contains("維護廠商") ? dtExcel.Rows[i]["維護廠商"].ToString().Trim() : null);
                        Params.Add("Cabinet", DbType.String, dtExcel.Columns.Contains("機櫃") ? dtExcel.Rows[i]["機櫃"].ToString().Trim() : null);
                        Params.Add("OSName", DbType.String, dtExcel.Columns.Contains("作業系統") ? dtExcel.Rows[i]["作業系統"].ToString().Trim() : null);
                        Params.Add("isVM", DbType.String, dtExcel.Columns.Contains("實體機器") ? dtExcel.Rows[i]["實體機器"].ToString().Trim() : null);
                        Params.Add("BuyDepartment", DbType.String, dtExcel.Columns.Contains("採購主辦科") ? dtExcel.Rows[i]["採購主辦科"].ToString().Trim() : null);
                        Params.Add("TransferDate", DbType.String, dtExcel.Columns.Contains("收到系統移交日期(收到送審)") ? dtExcel.Rows[i]["收到系統移交日期(收到送審)"].ToString().Trim() : null);
                        Params.Add("Department", DbType.String, dtExcel.Columns.Contains("業務主辦科") ? dtExcel.Rows[i]["業務主辦科"].ToString().Trim() : null);
                        Params.Add("SysType", DbType.String, dtExcel.Columns.Contains("伺服主機角色") ? dtExcel.Rows[i]["伺服主機角色"].ToString().Trim() : null);
                        Params.Add("SysGroup", DbType.String, dtExcel.Columns.Contains("維護群組") ? dtExcel.Rows[i]["維護群組"].ToString().Trim() : null);
                        Params.Add("description", DbType.String, dtExcel.Columns.Contains("備註") ? dtExcel.Rows[i]["備註"].ToString().Trim() : null);

                        Params.Add("UpdUser", DbType.String, GUserInfo.UserId);

                        da.AddSql(sql, Params);


                    }
                    try
                    {
                        da.ExecuteNonQueryTrans();
                        strMessage = "匯入Excel資料成功";
                        base.CloseModalDialog(strMessage);
                    }
                    catch (Exception ex)
                    {
                        Utility.Write(System.Diagnostics.TraceEventType.Error, ex.ToString());
                        var message = new JavaScriptSerializer().Serialize(ex.Message.ToString());
                        jsScript = @"<script>$(document).ready(function () {alert('匯入Excel資料失敗!:" + message + "');})</script>";
                        ClientScript.RegisterClientScriptBlock(GetType(), "", jsScript);
                    }

                }
                else
                {
                    strMessage = "無資料可匯入";
                    jsScript = @"<script>$(document).ready(function () {alert('" + strMessage + "');})</script>";
                    ClientScript.RegisterClientScriptBlock(GetType(), "", jsScript);
                }
            }
            catch (SystemException ex)
            {
                Utility.Write(System.Diagnostics.TraceEventType.Error, ex.ToString());
                var message = new JavaScriptSerializer().Serialize(ex.Message.ToString());
                string jsScript = @"<script>$(document).ready(function () {alert('解析發生錯誤!:" + message + "');})</script>";
                ClientScript.RegisterClientScriptBlock(GetType(), "", jsScript);

            }

        }
        else
        {
            //Response.Write("<Script language='JavaScript'>alert('請選擇上傳檔案!');</Script>");
            string strMessage = "請選擇上傳檔案!";
            string jsScript = @"<script>$(document).ready(function () {alert('" + strMessage + "');})</script>";
            ClientScript.RegisterClientScriptBlock(GetType(), "", jsScript);
        }
    }
}