USE [SecurityScan]
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'4daf2129-5947-47d3-a05e-b8fc9fc569f1', N'AIX_ip_forward', N'0', N'AIX', N'關閉「IP轉送」')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'f60349fe-6f44-4353-ad35-6c51e5d123c5', N'AIX_send_redirects', N'0', N'AIX', N'關閉「預設網路介面傳送ICMP重新導向封包」')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'2c633a42-39c4-4646-9a9d-e0905bd9446d', N'Linux_delay', N'10', N'Linux', N'失敗登入額外增加延遲')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'190f2d94-5c5a-44a7-a99d-e4b26557fef4', N'Linux_deny', N'10', N'Linux', N'嘗試登入失敗之後停用登入')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'3c861af6-561d-4cd5-92f8-361e44f5b7f9', N'Linux_dictpath', N'empty', N'Linux', N'避免常用密碼字典設定')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'c89bc233-245d-4424-8c49-30669c4cf2e8', N'Linux_difok', N'1', N'Linux', N'與前一代密碼至少字元不同數')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'6293eaf1-c217-480f-9327-f8e9b10b852e', N'Linux_fail_interval', N'60', N'Linux', N'失敗登入之間的間隔')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'9f2de8ff-4e54-4094-9b89-2db50ae88792', N'Linux_ignorerhosts', N'yes', N'Linux', N'取消信任主機驗證')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'9bf7b26b-a1a5-4d5d-b2bf-21f1ca4ac2be', N'Linux_pwd_algo_info', N'SHA256;SHA512', N'Linux', N'密碼加密儲存演算法')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'f45d7724-ef28-4e4f-91cc-63e257842fe0', N'Linux_ServerAliveInterval', N'30', N'Linux', N'登入逾時')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'566fc2dd-f4cd-4fff-9876-2d3c16b03aa8', N'Linux_tmout', N'540', N'Linux', N'自動登出時間')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'efb8cbd4-650b-4c18-977b-be54066a1448', N'Linux_unlock_time', N'360', N'Linux', N'鎖定帳號之後重新啟用')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'054bed74-2d0d-47cf-a018-0b3f169ea4a7', N'Solaris_clientaliveinterval', N'540', N'Solaris', N'自動登出時間')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'1a3f8714-522b-40e1-b5de-e2c978496e02', N'Solaris_dictionlist', N'/usr/share/lib/dict/words', N'Solaris', N'避免常用密碼字典設定')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'0ab06b1f-c910-4014-b124-e45cd984c644', N'Solaris_disabletime', N'360', N'Solaris', N'鎖定帳號之後重新啟用')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'38c4c66b-2507-4001-b94b-3f0ac98396f1', N'Solaris_forward_src_routed', N'0', N'Solaris', N'關閉「IP轉送」')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'a77a5d59-ab4e-452c-b266-bc00bbe602f3', N'Solaris_ignorerhosts', N'yes', N'Solaris', N'取消信任主機驗證')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'0859a925-6270-4ab4-acec-37024f4e0b62', N'Solaris_logingracetime', N'30', N'Solaris', N'登入逾時')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'47df04ab-d405-4ce1-a27c-f6084f423f20', N'Solaris_min_nonalpha', N'2', N'Solaris', N'密碼至少應包含非英文字母字元數')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'808f7e27-1ffb-4023-b507-65bead4e26a1', N'Solaris_pwd_algo_info', N'5', N'Solaris', N'密碼加密儲存演算法')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'0759a332-9281-411d-b231-bebffba7c270', N'Solaris_send_redirects', N'1,off', N'Solaris', N'關閉「預設網路介面傳送ICMP&amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;#160;重新導向封包」')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'b72f4e7e-4628-496e-af4d-a5129515d25d', N'Solaris_sleeptime', N'10', N'Solaris', N'失敗登入額外增加延遲')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'9f29ee41-8f9c-402e-b7e3-9374f43d120e', N'SUSE_dcredit', N'-1', N'SUSE', N'密碼至少應包含數字字元數')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'b9a72ac0-5dbc-4b40-9fe3-b5e5cee1f310', N'SUSE_delay', N'10', N'SUSE', N'失敗登入額外增加延遲')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'0eda9e98-55ce-424e-9a90-4701f9c5f016', N'SUSE_deny', N'10', N'SUSE', N'嘗試登入失敗之後停用登入')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'9d3f9bc6-1af0-474c-8e2f-efc1f8bb2328', N'SUSE_dictpath', N'/etc/security/pwquality.conf', N'SUSE', N'避免常用密碼字典設定')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'87f2b0e3-c9bd-48bd-8d89-3789cc2eb682', N'SUSE_difok', N'1', N'SUSE', N'與前一代密碼至少字元不同數')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'27e4b300-3779-422b-b2c7-d246e9e64146', N'SUSE_fail_interval', N'60', N'SUSE', N'失敗登入之間的間隔')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'f0080b17-6642-49ab-a9d6-ead14a8ecc6d', N'SUSE_ignorerhosts', N'yes', N'SUSE', N'取消信任主機驗證')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'40ac7898-fec5-4cb2-9f33-f738fae97175', N'SUSE_ip_forward', N'0', N'SUSE', N'關閉「IP轉送」')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'02e99c70-eae0-4cc5-9e7b-0f9d2372da51', N'SUSE_lcredit', N'-1', N'SUSE', N'密碼至少應包含小寫字母字元數')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'd8ea0cf2-128c-49fb-a949-4ca8dd44e2fa', N'SUSE_LOGIN_TIMEOUT', N'30', N'SUSE', N'登入逾時')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'fb384f84-53d5-45aa-9c89-fbc66b154300', N'SUSE_martians', N'1', N'SUSE', N'啟用「記錄可疑封包」')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'c05bca34-090a-4473-a6ad-cd39a5dc5f65', N'SUSE_pwd_algo_info', N'SHA256;SHA512', N'SUSE', N'密碼加密儲存演算法')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'e682d7c1-3406-487e-a267-32808fe04a23', N'SUSE_send_redirects', N'0', N'SUSE', N'關閉「預設網路介面傳送ICMP&amp;amp;#160;重新導向封包」')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'f3c0e2c1-ec36-4ba8-bf39-054cfb6b549c', N'SUSE_tmout', N'540', N'SUSE', N'自動登出時間')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'25fb8c60-c509-487d-9386-714e569b49dd', N'SUSE_ucredit', N'-1', N'SUSE', N'密碼至少應包含大寫字母字元數')
GO
INSERT [dbo].[PolicyNecessaryU] ([MainId], [Policy], [SetPoint], [OSType], [Remark]) VALUES (N'd4e0a05a-a99a-4f63-adde-9c161f642181', N'SUSE_unlock_time', N'360', N'SUSE', N'鎖定帳號之後重新啟用')
GO
UPDATE [dbo].[PolicyNecessaryU] SET [Remark]='限制密碼變更不可與前幾次相同之期間(週)' WHERE [Policy]='AIX_histexpire';
UPDATE [dbo].[PolicyNecessaryU] SET [Remark]='失敗登入額外增加延遲' WHERE [Policy]='AIX_logindelay';
UPDATE [dbo].[PolicyNecessaryU] SET [Remark]='嘗試登入失敗之後停用登入' WHERE [Policy]='AIX_logindisable';
UPDATE [dbo].[PolicyNecessaryU] SET [Remark]='密碼至少應包含英文字母字元數' WHERE [Policy]='AIX_minalpha';
UPDATE [dbo].[PolicyNecessaryU] SET [Remark]='與前一代密碼至少字元不同數' WHERE [Policy]='AIX_mindiff';
UPDATE [dbo].[PolicyNecessaryU] SET [Remark]='密碼至少應包含非英文字母字元數' WHERE [Policy]='AIX_minother';
UPDATE [dbo].[PolicyNecessaryU] SET [Remark]='自動登出時間' WHERE [Policy]='AIX_tmout';
UPDATE [dbo].[PolicyNecessaryU] SET [Remark]='密碼至少應包含英文字母字元數' WHERE [Policy]='Solaris_min_alpha';
UPDATE [dbo].[PolicyNecessaryU] SET [Remark]='與前一代密碼至少字元不同數' WHERE [Policy]='Solaris_min_diff';
UPDATE [dbo].[PolicyNecessaryU] SET [Remark]='密碼至少應包含數字字元數' WHERE [Policy]='Solaris_min_digit';
UPDATE [dbo].[PolicyNecessaryU] SET [Remark]='密碼至少應包含小寫字母字元數' WHERE [Policy]='Solaris_min_lower';
UPDATE [dbo].[PolicyNecessaryU] SET [Remark]='密碼至少應包含大寫字母字元數' WHERE [Policy]='Solaris_min_upper';