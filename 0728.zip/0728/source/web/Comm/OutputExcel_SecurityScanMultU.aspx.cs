﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using System.Configuration;
using System.Data;
using System.IO;
using System.Resources;
using ICSharpCode.SharpZipLib.Zip;
using NPOI.SS.UserModel;
using NPOI.HSSF.UserModel;
using NPOI.XSSF.UserModel;


public partial class OutputExcel_SecurityScanMultU : CallbackPage
{
    ResourceManager ReportRex = Resources.ReportRex.ResourceManager;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["SearchResult"] == null)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Comm_OutputExcel_ConfigChangeU", "alert('無資料列可供匯出！');window.close()", true);
            return;
        }

        try
        {
            string pdfName = "ConfigSecurityReport" + DateTime.Now.ToString("yyyyMMdd") + ".zip";
            Response.Clear();

            HttpContext.Current.Response.AddHeader("Content-Disposition", string.Format("attachment;filename={0}", pdfName));
            HttpContext.Current.Response.ContentType = "application/zip";

            DataTable Policy = GetPolicySetPoint();

            using (var zipStream = new ZipOutputStream(Response.OutputStream))
            {
                string Filename = "ConfigSecurityReport_{0}.xlsx";
                foreach (OsType item in (OsType[])Enum.GetValues(typeof(OsType)))
                {
                    byte[] fileBytes = CreateXlsx(item, Policy).ToArray();
                    ZipEntry fileEntry = new ZipEntry(string.Format(Filename, item))
                    {
                        Size = fileBytes.Length
                    };

                    zipStream.PutNextEntry(fileEntry);
                    zipStream.Write(fileBytes, 0, fileBytes.Length);
                }

                zipStream.Flush();
                zipStream.Close();
            }

        }
        catch (Exception ex)
        {
            Utility.Write(System.Diagnostics.TraceEventType.Information, ex.ToString());
            Response.Write(ex.ToString());
            Response.Flush();
            Response.End();
        }
    }

    XSSFWorkbook wb;
    protected MemoryStream CreateXlsx(OsType osType, DataTable Policy)
    {
        try
        {
            wb = new XSSFWorkbook();
            ISheet ws = wb.CreateSheet("Policy");
            //ws.DefaultColumnWidth = (int)((150 + 0.72) * 256);

            #region Cellstyle
            IFont fontTitle = wb.CreateFont();
            //fontTitle.Boldweight = (short)FontBoldWeight.Bold;
            fontTitle.FontHeightInPoints = 16;

            ICellStyle styleHEAD = wb.CreateCellStyle();
            styleHEAD.Alignment = HorizontalAlignment.Center;
            styleHEAD.VerticalAlignment = VerticalAlignment.Center;
            styleHEAD.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
            styleHEAD.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            styleHEAD.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
            styleHEAD.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
            styleHEAD.SetFont(fontTitle);

            ICellStyle styleHEAD2 = wb.CreateCellStyle();
            styleHEAD2.Alignment = HorizontalAlignment.Center;
            styleHEAD2.VerticalAlignment = VerticalAlignment.Center;
            styleHEAD2.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
            styleHEAD2.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            styleHEAD2.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
            styleHEAD2.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;

            ICellStyle styleHEAD3 = wb.CreateCellStyle();
            styleHEAD3.Alignment = HorizontalAlignment.Center;
            styleHEAD3.VerticalAlignment = VerticalAlignment.Center;
            styleHEAD3.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
            styleHEAD3.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            styleHEAD3.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
            styleHEAD3.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;

            ICellStyle styleHEAD4 = wb.CreateCellStyle();
            styleHEAD4.Alignment = HorizontalAlignment.Center;
            styleHEAD4.VerticalAlignment = VerticalAlignment.Center;
            styleHEAD4.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
            styleHEAD4.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            styleHEAD4.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
            styleHEAD4.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;

            ICellStyle styleContent = wb.CreateCellStyle();
            styleContent.Alignment = HorizontalAlignment.Center;
            styleContent.VerticalAlignment = VerticalAlignment.Center;
            styleContent.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
            styleContent.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            styleContent.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
            styleContent.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
            styleContent.WrapText = true;

            IFont fontError = wb.CreateFont();
            fontError.Color = NPOI.HSSF.Util.HSSFColor.Red.Index;

            ICellStyle styleContentError = wb.CreateCellStyle();
            styleContentError.Alignment = HorizontalAlignment.Center;
            styleContentError.VerticalAlignment = VerticalAlignment.Center;
            styleContentError.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
            styleContentError.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            styleContentError.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
            styleContentError.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
            styleContentError.WrapText = true;
            styleContentError.SetFont(fontError);

            ICellStyle styleEmpty = wb.CreateCellStyle();
            styleEmpty.Alignment = HorizontalAlignment.Left;
            styleEmpty.VerticalAlignment = VerticalAlignment.Center;
            #endregion

            DataTable data_source = Session["SearchResult"] as DataTable;
            string check_date2 = Session["CheckDateTimeString2"].ToString();
            string check_date3 = Session["CheckDateTimeString3"].ToString();
            string check_date;
            if (!string.IsNullOrEmpty(check_date3))
            {
                check_date = check_date3;
            }
            else
            {
                check_date = check_date2;
            }
            string Dept = Session["SearchDept"] != null ? Session["SearchDept"].ToString() : "";

            // 共用文字

            DateTime Dresult;
            DateTime.TryParseExact(
                 check_date,
                 "yyyy/MM/dd HH:mm",
                 System.Globalization.CultureInfo.InvariantCulture,
                 System.Globalization.DateTimeStyles.AssumeUniversal,
                 out Dresult);
            int Year = Dresult.Year - 1911;
            string title = string.Format("{0}年度非Windows主機重要系統安全參數設定檢核表", Year);
            string dept = string.Format("業務主辦科 : {0}", Dept);
            string level = "機密等級: 敏感";
            string date = string.Format("盤點日期:{0}", check_date);
            string tip = "註:與合規值相符以-顯示";
            string Sign1 = "副科長:";
            string Sign2 = "科長:";
            string Sign3 = "歸檔人員:";
            //
            if (osType == OsType.AIX)
            {
                printTitle(ws, 35, title, dept, level, date);

                #region AIX
                DataRow[] AIXResult = data_source.Select("UnixOSName like '%AIX%' and UnixServerStatus Like '%成功%'");
                List<Policy_Item> AIX_Police = new List<Policy_Item>();
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_MaxHistories", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_MaxHistories") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_MaxWeeks", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_MaxWeeks") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_MinWeeks", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_MinWeeks") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_MinLength", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_MinLength") });
                //AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_warn_time", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_warn_time") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_retries", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_retries") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_histexpire", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_histexpire") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_minother", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_minother") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_minalpha", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_minalpha") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_mindigit", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_mindigit") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_minupperalpha", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_minupperalpha") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_minloweralpha", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_minloweralpha") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_mindiff", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_mindiff") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_dictionlist", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_dictionlist") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_pwd_algo_info", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_pwd_algo_info") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_umask", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_umask") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_logininterval", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_logininterval") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_logindisable", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_logindisable") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_loginreenable", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_loginreenable") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_logintimeout", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_logintimeout") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_logindelay", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_logindelay") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_tmout", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_tmout") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_auditstart", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_auditstart") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_auditshutdown", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_auditshutdown") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_ignorerhosts", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_ignorerhosts") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_binmode", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_binmode") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_ip_forward", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_ip_forward") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_send_redirects", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_send_redirects") });
                //AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_guest", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_guest") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_superuser", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_superuser") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_NonAuditSuperuser", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_NonAuditSuperuser") });

                int EndRowNum = CreateTable(ws, AIXResult, AIX_Police);

                #endregion

                // 產生結尾
                EndRowNum++;
                IRow ICell_tip = ws.CreateRow(EndRowNum);
                CreateCell(ICell_tip, 0, getCellStyle(CellStyle.Empty), tip);
                EndRowNum++;
                IRow ICell_Sign = ws.CreateRow(EndRowNum);
                CreateCell(ICell_Sign, 16, getCellStyle(CellStyle.Empty), Sign1);
                CreateCell(ICell_Sign, 19, getCellStyle(CellStyle.Empty), Sign2);
                CreateCell(ICell_Sign, 22, getCellStyle(CellStyle.Empty), Sign3);
            }

            if (osType == OsType.SUSE)
            {
                printTitle(ws, 29, title, dept, level, date);

                #region SUSE
                DataRow[] SUSEResult = data_source.Select("UnixOSName like '%SUSE%' and UnixServerStatus Like '%成功%'");
                List<Policy_Item> SUSE_Police = new List<Policy_Item>();
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_MaxHistories", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_MaxHistories") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_MaxDays", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_MaxDays") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_MinDays", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_MinDays") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_MinLength", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_MinLength") });
                //SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_warn_time", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_warn_time") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_retries", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_retries") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_dcredit", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_dcredit") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_ucredit", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_ucredit") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_lcredit", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_lcredit") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_difok", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_difok") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_dictpath", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_dictpath") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_pwd_algo_info", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_pwd_algo_info") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_umask", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_umask") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_fail_interval", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_fail_interval") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_deny", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_deny") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_unlock_time", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_unlock_time") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_LOGIN_TIMEOUT", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_LOGIN_TIMEOUT") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_delay", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_delay") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_tmout", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_tmout") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_ignorerhosts", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_ignorerhosts") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_martians", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_martians") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_ip_forward", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_ip_forward") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_send_redirects", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_send_redirects") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_superuser", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_superuser") });

                int EndRowNum = CreateTable(ws, SUSEResult, SUSE_Police);
                #endregion

                // 產生結尾
                EndRowNum++;
                IRow ICell_tip = ws.CreateRow(EndRowNum);
                CreateCell(ICell_tip, 0, getCellStyle(CellStyle.Empty), tip);
                EndRowNum++;
                IRow ICell_Sign = ws.CreateRow(EndRowNum);
                CreateCell(ICell_Sign, 16, getCellStyle(CellStyle.Empty), Sign1);
                CreateCell(ICell_Sign, 19, getCellStyle(CellStyle.Empty), Sign2);
                CreateCell(ICell_Sign, 22, getCellStyle(CellStyle.Empty), Sign3);
            }

            if (osType == OsType.Solaris)
            {
                printTitle(ws, 27, title, dept, level, date);

                #region Solaris
                DataRow[] SolarisResult = data_source.Select("UnixOSName like '%Solaris%' and UnixServerStatus Like '%成功%'");
                List<Policy_Item> Solaris_Police = new List<Policy_Item>();
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_MaxHistories", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_MaxHistories") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_MaxWeeks", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_MaxWeeks") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_MinWeeks", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_MinWeeks") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_MinLength", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_MinLength") });
                //Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_warn_time", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_warn_time") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_retries", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_retries") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_min_nonalpha", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_min_nonalpha") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_min_alpha", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_min_alpha") });
                //Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_min_digit", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_min_digit") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_min_upper", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_min_upper") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_min_lower", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_min_lower") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_min_diff", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_min_diff") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_dictionlist", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_dictionlist") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_pwd_algo_info", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_pwd_algo_info") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_umask", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_umask") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_disabletime", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_disabletime") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_logingracetime", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_logingracetime") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_sleeptime", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_sleeptime") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_clientaliveinterval", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_clientaliveinterval") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_ignorerhosts", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_ignorerhosts") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_forward_src_routed", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_forward_src_routed") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_send_redirects", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_send_redirects") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_superuser", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_superuser") });

                int EndRowNum = CreateTable(ws, SolarisResult, Solaris_Police);
                #endregion

                // 產生結尾
                EndRowNum++;
                IRow ICell_tip = ws.CreateRow(EndRowNum);
                CreateCell(ICell_tip, 0, getCellStyle(CellStyle.Empty), tip);
                EndRowNum++;
                IRow ICell_Sign = ws.CreateRow(EndRowNum);
                CreateCell(ICell_Sign, 16, getCellStyle(CellStyle.Empty), Sign1);
                CreateCell(ICell_Sign, 19, getCellStyle(CellStyle.Empty), Sign2);
                CreateCell(ICell_Sign, 22, getCellStyle(CellStyle.Empty), Sign3);
            }

            if (osType == OsType.Linux)
            {
                printTitle(ws, 29, title, dept, level, date);

                #region Linux
                DataRow[] LinuxResult = data_source.Select(" UnixOSName Not Like '%AIX%' and UnixOSName Not Like '%SUSE%' and  UnixOSName Not Like '%Solaris%' and UnixServerStatus Like '%成功%'");
                List<Policy_Item> Linux_Police = new List<Policy_Item>();
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_MaxHistories", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_MaxHistories") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_MaxDays", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_MaxDays") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_MinDays", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_MinDays") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_MinLength", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_MinLength") });
                //Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_warn_time", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_warn_time") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_retries", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_retries") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_dcredit", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_dcredit") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_ucredit", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_ucredit") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_lcredit", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_lcredit") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_difok", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_difok") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_dictpath", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_dictpath") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_pwd_algo_info", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_pwd_algo_info") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_umask", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_umask") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_fail_interval", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_fail_interval") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_deny", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_deny") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_unlock_time", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_unlock_time") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_ServerAliveInterval", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_ServerAliveInterval") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_delay", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_delay") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_tmout", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_tmout") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_ignorerhosts", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_ignorerhosts") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_martians", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_martians") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_ip_forward", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_ip_forward") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_send_redirects", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_send_redirects") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_superuser", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_superuser") });

                int EndRowNum = CreateTable(ws, LinuxResult, Linux_Police);

                #endregion

                // 產生結尾
                EndRowNum++;
                IRow ICell_tip = ws.CreateRow(EndRowNum);
                CreateCell(ICell_tip, 0, getCellStyle(CellStyle.Empty), tip);
                EndRowNum++;
                IRow ICell_Sign = ws.CreateRow(EndRowNum);
                CreateCell(ICell_Sign, 16, getCellStyle(CellStyle.Empty), Sign1);
                CreateCell(ICell_Sign, 19, getCellStyle(CellStyle.Empty), Sign2);
                CreateCell(ICell_Sign, 22, getCellStyle(CellStyle.Empty), Sign3);
            }

            
            

            //Npoi此版本寫到memoryStream有問題，使用此解法，詳見https://stackoverflow.com/questions/22931582/memorystream-seems-be-closed-after-npoi-workbook-write/55379161#55379161
            NpoiMemoryStream ms = new NpoiMemoryStream();
            ms.AllowClose = false;
            wb.Write(ms);
            ms.Flush();
            ms.Seek(0, SeekOrigin.Begin);
            ms.AllowClose = true;

            return ms;


        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private class Policy_Item
    {
        public string Policy_Name { get; set; }

        public string Policy_Value { get; set; }
    }
    private void printTitle(ISheet ws, int totalCount,string title,string dept, string level, string date)
    {
        ws.SetColumnWidth(0, (int)((30 + 0.72) * 256));
        for (int i = 1; i < totalCount; i++)
        {
            ws.SetColumnWidth(i, (int)((15 + 0.72) * 256));
        }
        // 產生開頭
        IRow IRow_HEAD = ws.CreateRow(0);
        ws.AddMergedRegion(new NPOI.SS.Util.CellRangeAddress(0, 0, 0, totalCount -1));
        for (int i = 0; i < totalCount; i++)
        {
            ICell cell = IRow_HEAD.CreateCell(i);
            cell.CellStyle = getCellStyle(CellStyle.HEAD1);
        }
        ICell ICell_HEAD = IRow_HEAD.CreateCell(0);
        ICell_HEAD.SetCellValue(title);
        ICell_HEAD.CellStyle = getCellStyle(CellStyle.HEAD1);

        IRow IRow_HEAD2 = ws.CreateRow(1);
        ws.AddMergedRegion(new NPOI.SS.Util.CellRangeAddress(1, 1, 1, totalCount -3));
        ws.AddMergedRegion(new NPOI.SS.Util.CellRangeAddress(1, 1, totalCount -2, totalCount -1));
        for (int i = 0; i < totalCount; i++)
        {
            ICell cell = IRow_HEAD2.CreateCell(i);
            cell.CellStyle = getCellStyle(CellStyle.HEAD2);
        }
        ICell ICell_HEAD2_1 = IRow_HEAD2.CreateCell(0);
        ICell_HEAD2_1.SetCellValue(dept);
        ICell_HEAD2_1.CellStyle = getCellStyle(CellStyle.HEAD2);
        ICell ICell_HEAD2_2 = IRow_HEAD2.CreateCell(1);
        ICell_HEAD2_2.SetCellValue(level);
        ICell_HEAD2_2.CellStyle = getCellStyle(CellStyle.HEAD3);
        ICell ICell_HEAD2_3 = IRow_HEAD2.CreateCell(totalCount -2);
        ICell_HEAD2_3.SetCellValue(date);
        ICell_HEAD2_3.CellStyle = getCellStyle(CellStyle.HEAD4);
    }
    public ICellStyle getCellStyle(CellStyle cell)
    {
        switch (cell)
        {
            case CellStyle.HEAD1:
                return wb.GetCellStyleAt(1);
            case CellStyle.HEAD2:
                return wb.GetCellStyleAt(2);
            case CellStyle.HEAD3:
                return wb.GetCellStyleAt(3);
            case CellStyle.HEAD4:
                return wb.GetCellStyleAt(4);
            case CellStyle.Content:
                return wb.GetCellStyleAt(5);
            case CellStyle.ContentError:
                return wb.GetCellStyleAt(6);
            case CellStyle.Empty:
                return wb.GetCellStyleAt(7);
            default:
                return null;
        }
    }
    public enum CellStyle
    {
        HEAD1,
        HEAD2,
        HEAD3,
        HEAD4,
        Content,
        ContentError,
        Empty
    }
    public enum OsType
    {
        AIX,
        Linux,
        SUSE,
        Solaris
    }
    public DataTable dt_Layout;

    private enum CellType { Header, Body, Empty }

    private void CreateCell(IRow row,int CellNum,ICellStyle cellStyle, string CellValue)
    {
        ICell cell= row.CreateCell(CellNum);
        cell.SetCellValue(CellValue);
        cell.CellStyle = cellStyle;
    }
    private int CreateTable(ISheet ws, DataRow[] SearchResult, List<Policy_Item> policy_Items)
    {

        int j;
        try
        {
            // 產生Head
            IRow IRow_HEAD = ws.CreateRow(2);
            CreateCell(IRow_HEAD, 0, getCellStyle(CellStyle.Content), "主機名稱");
            CreateCell(IRow_HEAD, 1, getCellStyle(CellStyle.Content), "主機IP");
            CreateCell(IRow_HEAD, 2, getCellStyle(CellStyle.Content), "系統版本");
            int i = 3;
            foreach (var policy_Item in policy_Items)
            {
                CreateCell(IRow_HEAD, i, getCellStyle(CellStyle.Content), ReportRex.GetString(policy_Item.Policy_Name));
                i++;
            }
            CreateCell(IRow_HEAD, i , getCellStyle(CellStyle.Content), "不符合之說明 / 異動案號");
            CreateCell(IRow_HEAD, i + 1, getCellStyle(CellStyle.Content), "檢視人員");
            CreateCell(IRow_HEAD, i + 2, getCellStyle(CellStyle.Content), "覆核人員");

            // 產生合規值
            IRow IRow_Role = ws.CreateRow(3);
            CreateCell(IRow_Role, 0, getCellStyle(CellStyle.Content), "合規值");
            ws.AddMergedRegion(new NPOI.SS.Util.CellRangeAddress(3, 3, 0, 2));
            for (int IRow_i = 0; IRow_i < 3; IRow_i++)
            {
                ICell cell = IRow_Role.CreateCell(IRow_i);
                cell.CellStyle = getCellStyle(CellStyle.Content);
            }
            ICell IRow_Role_HEAD = IRow_Role.CreateCell(0);
            IRow_Role_HEAD.SetCellValue("合規值");
            IRow_Role_HEAD.CellStyle = getCellStyle(CellStyle.Content);

            i = 3;
            foreach (var policy_Item in policy_Items)
            {
                CreateCell(IRow_Role, i, getCellStyle(CellStyle.Content), policy_Item.Policy_Value);
                i++;
            }
            CreateCell(IRow_Role, i , getCellStyle(CellStyle.Content), "");
            CreateCell(IRow_Role, i + 1, getCellStyle(CellStyle.Content), "");
            CreateCell(IRow_Role, i + 2, getCellStyle(CellStyle.Content), "");

            // 產生 Body
            //因需要排序，需先判斷有問題數量再加入CELL

            List<List<object>> Result = new List<List<object>>();
            foreach (DataRow row in SearchResult)
            {
                string Data = Convert.ToString(row["UnixData"]);
                string[] DataS = Data.Split('\n');
                //Utility.Write(System.Diagnostics.TraceEventType.Information, Data); 看資料log
                List<Result> R = new List<Result>();
                i = 0;
                foreach (var policy_Item in policy_Items)
                {
                    R.Add(new Result() { Policy = policy_Item.Policy_Name
                        , Value = DataS.Length > i ? DataS[i] : "DataError"
                        , std_Value = policy_Item.Policy_Value });
                    i++;
                }

                Result.Add(CreateData(R, Convert.ToString(row["ServerIP"]), Convert.ToString(row["UnixHostName"]), Convert.ToString(row["UnixOSName"])));
            }

            j = printData(ws, Result, SearchResult.Count());

        }
        catch (Exception ex)
        {
            throw ex;
        }
        return j;
    }

    private List<object> CreateData(List<Result> R,string ServerIP,string UnixHostName, string UnixOSName)
    {
        List<object> RowResult = new List<object>();
        string abnormal_options = "";
        int abnormal_count = 0;
        RowResult.Add(new Result() { Value = UnixHostName });
        RowResult.Add(new Result() { Value = ServerIP });
        RowResult.Add(new Result() { Value = UnixOSName });
        foreach (var item in R)
        {
            bool isAbnormal = CommonInfo.GCB_isAbnormal(item.Value, item.std_Value, item.Policy);
            if (isAbnormal)
            {
                abnormal_count++;
                abnormal_options += ReportRex.GetString(item.Policy) + "\n";
            }
            RowResult.Add(new Result() { Value = isAbnormal ? "***" + item.Value : "-", isAbnormal = isAbnormal });
        }
        RowResult.Add(abnormal_count);
        return RowResult;
    }
    private int printData(ISheet ws, List<List<object>> Result,int totalCount)
    {
        Result.Sort((x, y) => { return -((int)x.Last()).CompareTo((int)y.Last()); });

        //從第4行開始為資料
        int j = 4;
        foreach (List<object> item in Result)
        {
            IRow IRow_Data = ws.CreateRow(j);
            //-1 為不符數量
            int i;
            for (i = 0; i < item.Count - 1; i++)
            {
                Result result = (Result)item[i];
                if (result.isAbnormal == true)
                {
                    CreateCell(IRow_Data, i, getCellStyle(CellStyle.ContentError), result.Value);
                }
                else
                {
                    CreateCell(IRow_Data, i, getCellStyle(CellStyle.Content), result.Value);
                }

            }
            //為後面3個欄位
            CreateCell(IRow_Data, i, getCellStyle(CellStyle.Content), "");
            CreateCell(IRow_Data, i + 1, getCellStyle(CellStyle.Content), "");
            CreateCell(IRow_Data, i + 2, getCellStyle(CellStyle.Content), "");
            j++;
        }

        IRow IRow_total = ws.CreateRow(j);
        CreateCell(IRow_total, 0, getCellStyle(CellStyle.Empty), string.Format("總台數:{0}", totalCount));

        return j;
    }

    private string GetPolicySetPoint(string PolicyName)
    {
        var retval = "";
        var da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
        ParameterCollection objParams = new ParameterCollection();

        string strQuery = "SELECT SetPoint FROM PolicyNecessaryU WHERE Policy = @Policy";
        objParams.Add("Policy", DbType.String, PolicyName);

        var dt = da.ExecuteDataTable(strQuery, objParams);

        if (dt.Rows.Count > 0)
            retval = Convert.ToString(dt.Rows[0]["SetPoint"]);

        return retval;
    }
    private DataTable GetPolicySetPoint()
    {
        var da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
        ParameterCollection objParams = new ParameterCollection();

        string strQuery = "SELECT * FROM PolicyNecessaryU ";

        var dt = da.ExecuteDataTable(strQuery, objParams);

        return dt;
    }
    private string DtGetPolicySetPoint(DataTable dt, string Policy)
    {
        return dt.AsEnumerable().Where(x => x.Field<string>("Policy") == Policy).Select(x => x.Field<string>("SetPoint")).FirstOrDefault();
    }
    private class Result
    {
        public string Policy { get; set; }
        public string Value { get; set; }
        public string std_Value { get; set; }
        public bool isAbnormal { get; set; }
    }

    public class NpoiMemoryStream : MemoryStream
    {
        public NpoiMemoryStream()
        {
            // We always want to close streams by default to
            // force the developer to make the conscious decision
            // to disable it.  Then, they're more apt to remember
            // to re-enable it.  The last thing you want is to
            // enable memory leaks by default.  ;-)
            AllowClose = true;
        }

        public bool AllowClose { get; set; }

        public override void Close()
        {
            if (AllowClose)
                base.Close();
        }
    }
}