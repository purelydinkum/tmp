﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Web.UI.WebControls;
using System.Configuration;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Linq;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using Renci.SshNet;
using Renci.SshNet.Common;

public partial class SecurityScanMultFilterU : CallbackPage
{
    TempatePage_Query _master;
    string _ssh_pw;

    protected void Page_Load(object sender, EventArgs e)
    {
        Event_Register();
        if (!IsPostBack)
        {
            Control_Data_Binding();
            var dt = Get_GridView1_DataSource();
            dt.Rows.Add(new object[] { "", "", "" });
            GridView1.PageSize = 500;
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
    }

    protected void Page_Init(object sender, EventArgs e)
    {
        GridView2.RowCreated += GridView2_RowCreated;
    }

    protected void Page_CallBack(object sender, CallbackEventArgs e)
    {
        string strResult = base.GetCallBackMethod(this, e.Argument);
        e.Result = strResult;
    }

    private void Event_Register()
    {
        base.CallBack += new CallBackEventHandler(Page_CallBack);
        _master = this.Master as TempatePage_Query;

        _master.ToolSearch.Visible = true;
        _master.ToolOutputPdf.Visible = true;
        _master.ToolExcel.Visible = true;
        base.ClearValidationScript();

        var toolExcel = Master.FindControl("toolExcel") as HtmlButton;
        toolExcel.ServerClick += toolExcel_ServerClick;
        //excel 改到後端跑
        _master.ToolSearch.Attributes["onclick"] = base.GetValidationScript() + "if (sendSearch() == false) { return false; } else { var j=1; }";
        _master.ToolExcel.Attributes["onclick"] = "";
        //_master.ToolExcel.Attributes["onclick"] = "if (checkDataExisted()) { window.open('../Comm/OutputExcel_SecurityScanMultU.aspx?Year="+ txtDate.Text +"'); } return false;";
        //_master.ToolOutputPdf.Attributes["onclick"] = "if (checkDataExisted()) { window.open('../Comm/PrintPdf_SecurityScanMultU.aspx?Year="+ txtDate.Text + "'); } return false;";
    }

    private void Control_Data_Binding()
    {
        _pnlGrid.Style["Display"] = "none";
        const string sql = @"SELECT distinct Department 
	                            FROM ServerListU order by Department";
        var da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
        var dtb = da.ExecuteDataTable(sql);

        base.MappingListControl(dtb, ddlDept, false);
        if (base.FirstLoad())
        {
            //var dt = Get_GridView1_DataSource();
            //dt.Rows.Add(new object[] { "", "", "" });
            //GridView1.PageSize = 500;
            //GridView1.DataSource = dt;
            //GridView1.DataBind();
        }
    }

    public void GridBind()
    {
        var data_source_2 = Get_GridView2_DataSource();
        GridView2.DataSource = data_source_2;
        GridView2.DataBind();

        int[] cellsWidth = new int[] { 10, 10, 15, 10 };
        GridDataPage1.SetDataSource(data_source_2, cellsWidth);
    }

    private void GridView2_RowCreated(object sender, GridViewRowEventArgs e)
    {
        
    }

    protected override void OnSearch_Click(object sender, EventArgs e)
    {
        var query_task_list = new List<Task>();

        _pnlGrid.Style["Display"] = "";

        GridView1.DataSource = Get_GridView1_DataSource();
        GridView1.DataBind();

        if (GridView1.Rows.Count < 1) JsAlert("無可查詢之機器資訊");
        
        GridView2.PageIndex = 0;

        var data_source_2 = Get_GridView2_DataSource();
        data_source_2.Clear();

        DataTable DeptList = getDeptIPList();

        for (int idx = 0; idx < GridView1.Rows.Count; ++idx)
        {
            TextBox txtServerIP = GridView1.Rows[idx].FindControl("txtServerIP") as TextBox;
            TextBox txtName = GridView1.Rows[idx].FindControl("txtName") as TextBox;
            TextBox txtToken = GridView1.Rows[idx].FindControl("txtToken") as TextBox;

            if (string.IsNullOrEmpty(txtServerIP.Text)) break;

            foreach (DataRow item in DeptList.Rows)
            {
                if (IPMatch(txtServerIP.Text, item[0].ToString()))
                {
                    query_task_list.Add(Task.Factory.StartNew(
                () => GridView_AddConfig(data_source_2, txtServerIP.Text.Trim(), txtName.Text.Trim(), txtToken.Text.Trim())));
                    break;
                }
            }
        }
        Task.WaitAll(query_task_list.ToArray());
        GridView2.DataSource = data_source_2;
        GridView2.DataBind();
        Session["SearchDept"] = ddlDept.SelectedValue;
        Session["SearchResult"] = data_source_2;
        Session["CheckDateTimeString"] = DateTime.Now.ToString();
        Session["CheckDateTimeString2"] = DateTime.Now.ToString("yyyy/MM/dd HH:mm");

        int[] cellsWidth = new int[] { 10, 10, 10,10, 15, 15};
        GridDataPage1.SetDataSource(data_source_2, cellsWidth);
    }

    void toolExcel_ServerClick(object sender, EventArgs e)
    {
        this.OnExcel_Click(sender, e);
    }
    protected override void OnPdf_Click(object sender, EventArgs e)
    {
        var R = Check();
        if (!R.Item1)
        {
            ClientScript.RegisterStartupScript(this.GetType(), "SecurityScanMultFilterU_OnPdf_Click_Check", string.Format("alert('{0}');", R.Item2), true);
            return;
        }

        Session["CheckDateTimeString3"] = R.Item2;
        ScriptManager.RegisterStartupScript(Page, GetType(), "OnPrintPdfClickSecurityScanMultU", "<script>if (checkDataExisted()) { window.open('../Comm/PrintPdf_SecurityScanMultU.aspx'); }</script>", false);
    }
    protected override void OnExcel_Click(object sender, EventArgs e)
    {
        var R = Check();
        if (!R.Item1)
        {
            ClientScript.RegisterStartupScript(this.GetType(), "SecurityScanMultFilterU_OnPdf_Click_Check", string.Format("alert('{0}');", R.Item2), true);
            return;
        }

        Session["CheckDateTimeString3"] = R.Item2;
        ScriptManager.RegisterStartupScript(Page, GetType(), "OnPrintExcelClickSecurityScanMultU", "<script>if (checkDataExisted()) { window.open('../Comm/OutputExcel_SecurityScanMultU.aspx'); }</script>", false);
    }
    private Tuple<bool, string> Check()
    {
        if (string.IsNullOrEmpty(txtDate.Text.Trim()))
        {
            return new Tuple<bool, string>(true, "");
        }
        DateTime result;
        if (!DateTime.TryParseExact(
             txtDate.Text.Trim(),
             "yyyy/MM/dd HH:mm",
             System.Globalization.CultureInfo.InvariantCulture,
             System.Globalization.DateTimeStyles.None,
             out result))
        {
            return new Tuple<bool, string>(false, "日期不符格式! 為:yyyy/MM/dd HH:mm");
        };
        return new Tuple<bool, string>(true, result.ToString("yyyy/MM/dd HH:mm"));
    }
    private DataTable getDeptIPList()
    {
        var da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
        ParameterCollection objParams = new ParameterCollection();

        string strQuery = "SELECT distinct PublicIP FROM ServerListU where PublicIP is not null and PublicIP <> '' and Department = @Department ";
        objParams.Add("Department", DbType.String, ddlDept.SelectedValue);

        DataTable dt = da.ExecuteDataTable(strQuery, objParams);

        return dt;
    }

    private DataTable Get_GridView1_DataSource()
    {
        DataTable retval = new DataTable();
        retval.Columns.Add("ServerIP");
        retval.Columns.Add("Name");
        retval.Columns.Add("Token");

        for (int i = 0; i < GridView1.Rows.Count; i++)
        {
            TextBox txtServerIP = GridView1.Rows[i].FindControl("txtServerIP") as TextBox;
            TextBox txtName = GridView1.Rows[i].FindControl("txtName") as TextBox;
            TextBox txtToken = GridView1.Rows[i].FindControl("txtToken") as TextBox;

            retval.Rows.Add(new object[] { txtServerIP.Text, txtName.Text, txtToken.Text });
        }

        return retval;
    }

    private Boolean IPMatch(string IP , string FilterIP)
    {
        foreach (var item in FilterIP.Split(';'))
        {
            if(item == IP)
            {
                return true;
            }
        }
        return false;
    }
    private DataTable Get_GridView2_DataSource()
    {
        DataTable retval = new DataTable();
        retval.Columns.Add("DataKey");
        retval.Columns.Add("ServerIP");
        retval.Columns.Add("UnixServerStatus");
        retval.Columns.Add("UnixHostName");
        retval.Columns.Add("UName");
        retval.Columns.Add("UnixOSName");
        retval.Columns.Add("UnixData");

        for (int idx = 0; idx < GridView2.Rows.Count; ++idx)
        {
            Label lblServerIP = GridView2.Rows[idx].FindControl("lblServerIP") as Label;
            Label lblUnixServerStatus = GridView2.Rows[idx].FindControl("lblUnixServerStatus") as Label;
            Label lblUnixHostName = GridView2.Rows[idx].FindControl("lblUnixHostName") as Label;
            Label lblUName = GridView2.Rows[idx].FindControl("lblUName") as Label;
            Label lblUnixOSName = GridView2.Rows[idx].FindControl("lblUnixOSName") as Label;

            HiddenField hidData = GridView2.Rows[idx].FindControl("hidData") as HiddenField;

            retval.Rows.Add(
                new object[] {
                    idx + 1,
                    lblServerIP.Text,
                    lblUnixServerStatus.Text,
                    lblUnixHostName.Text,
                    lblUName.Text,
                    lblUnixOSName.Text,
                    hidData
                });
        }

        return retval;
    }

    protected void btn_AddNewStep_Click(object sender, EventArgs e)
    {
        var dt = Get_GridView1_DataSource();
        dt.Rows.Add(new object[] { "", "", "" });
        GridView1.DataSource = dt;
        GridView1.DataBind();
    }

    protected void btn_Import_Click(object sender, EventArgs e)
    {
        using (StreamReader reader = new StreamReader(fuImport.PostedFile.InputStream))
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("ServerIP");
            dt.Columns.Add("Name");
            dt.Columns.Add("Token");
            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                TextBox txtServerIP = GridView1.Rows[i].FindControl("txtServerIP") as TextBox;
                TextBox txtName = GridView1.Rows[i].FindControl("txtName") as TextBox;
                TextBox txtToken = GridView1.Rows[i].FindControl("txtToken") as TextBox;

                if (!(string.IsNullOrEmpty(txtServerIP.Text.Trim()) &&
                    string.IsNullOrEmpty(txtName.Text.Trim()) &&
                    string.IsNullOrEmpty(txtToken.Text.Trim())))
                {
                    dt.Rows.Add(new object[] { txtServerIP.Text.Trim(), txtName.Text.Trim(), txtToken.Text.Trim() });
                }
            }
            while (!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                var values = line.Split(new char[] { ',' }, 3);
                dt.Rows.Add(values);
            }
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        ClientScript.RegisterStartupScript(this.GetType(), "匯入作業", "alert('匯入成功!');", true);

        //if (fuImport.HasFile)
        //{
        //    //設定讀取的權限(FileAccess.Read)
        //    FileStream fs = new FileStream(fuImport.PostedFile.FileName, FileMode.Open, FileAccess.Read);
        //    using (StreamReader reader = new StreamReader(fs))
        //    {
        //        DataTable dt = new DataTable();
        //        dt.Columns.Add("ServerIP");
        //        dt.Columns.Add("Name");
        //        dt.Columns.Add("Token");
        //        for (int i = 0; i < GridView1.Rows.Count; i++)
        //        {
        //            TextBox txtServerIP = GridView1.Rows[i].FindControl("txtServerIP") as TextBox;
        //            TextBox txtName = GridView1.Rows[i].FindControl("txtName") as TextBox;
        //            TextBox txtToken = GridView1.Rows[i].FindControl("txtToken") as TextBox;

        //            if (!(string.IsNullOrEmpty(txtServerIP.Text.Trim()) &&
        //                string.IsNullOrEmpty(txtName.Text.Trim()) &&
        //                string.IsNullOrEmpty(txtToken.Text.Trim())))
        //            {
        //                dt.Rows.Add(new object[] { txtServerIP.Text, txtName.Text, txtToken.Text });
        //            }
        //        }

        //        while (reader.Peek()!=-1)
        //        {
        //            var line = reader.ReadLine();
        //            var values = line.Split(',');
        //            dt.Rows.Add(values);
        //        }
        //        GridView1.DataSource = dt;
        //        GridView1.DataBind();

        //    }
        //    ClientScript.RegisterStartupScript(this.GetType(), "匯入作業", "alert('匯入成功!');", true);
        //}
    }

    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e) { }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        switch (e.CommandName)
        {
            case "D":

                var dt = Get_GridView1_DataSource();
                if (dt.Rows.Count > 1)
                    dt.Rows.RemoveAt(Convert.ToInt32(e.CommandArgument));
                GridView1.DataSource = dt;
                GridView1.DataBind();
                break;
        }
    }

    private void SendFileToRemote(SftpClient Client, string LocalFilePath, string RemoteFilePath)
    {
        using (var file_stream = File.OpenRead(LocalFilePath))
        {
            Client.UploadFile(file_stream, RemoteFilePath);
            Client.ChangePermissions(RemoteFilePath, 700); //修改檔案權限僅owner可讀取/修改/執行。
        }
    }

    private HostInfo GetConfigData(SshClient Client, string RemoteScriptPath)
    {
        if (!Client.IsConnected)
            throw new Exception(string.Format("無法連線至遠端主機: {0}",Client.ConnectionInfo.Host));

        List<string> arglist = Client.RunCommand(RemoteScriptPath).Result.Split('\n').ToList();
        string HostName = arglist[0];
        string UName = arglist[1];
        string OSName = arglist[2];
        arglist.RemoveRange(0, 3);
        return new HostInfo()
        {
            HostName = HostName,
            UName = UName,
            OSName = OSName,
            Data = string.Join("\n", arglist),
            Status = string.Format(Resources.Language.Success, string.Empty)
        };

    }

    private HostInfo GetConfigFromRemote(string Ip, string UserName, string Password)
    {
        const string get_shell = "get-config-V2.sh";
        const string get_shell_detail = "get-config-detail.sh";
        HostInfo retval = new HostInfo();
        if (string.IsNullOrEmpty(UserName) || string.IsNullOrEmpty(Password))
        {
            retval.Status = string.Format(Resources.Language.Fail, string.Empty);
        }
        else
        {
            try
            {
                string local_shell = string.Format(@"C:\SecurityScan\Tools\{0}", get_shell);
                string target_shell = string.Format(@"/tmp/{0}", get_shell);
                _ssh_pw = Password;
                PasswordAuthenticationMethod pauth = new PasswordAuthenticationMethod(UserName, _ssh_pw); // 使用 password 驗證。
                KeyboardInteractiveAuthenticationMethod kAuth = new KeyboardInteractiveAuthenticationMethod(UserName); // 使用 keyboard-interactive 驗證。
                kAuth.AuthenticationPrompt += new EventHandler<AuthenticationPromptEventArgs>(HandleKeyEvent);
                ConnectionInfo conInfo = new ConnectionInfo(Ip, 22, UserName, pauth, kAuth);

                try
                {
                    using (SftpClient client = new SftpClient(conInfo))
                    {
                        client.Connect();
                        SendFileToRemote(client, local_shell, target_shell);
                    }
                }
                catch
                {
                    using (ScpClient client = new ScpClient(conInfo))
                    {
                        client.Connect();
                        using (Stream localFile = File.OpenRead(local_shell))
                        {
                            client.Upload(localFile, target_shell);
                        }
                    }
                }

                using (SshClient client = new SshClient(conInfo))
                {
                    client.Connect();
                    retval = GetConfigData(client, target_shell);
                }

                using (SshClient client = new SshClient(conInfo))
                {
                    client.Connect();
                    if (!client.IsConnected)
                        throw new Exception(string.Format("刪除Shell:無法連線至遠端主機: {0}", client.ConnectionInfo.Host));

                    var Result = client.RunCommand(string.Format("rm {0}", target_shell));
                    if (Result.ExitStatus != 0)
                    {
                        throw new Exception(string.Format("刪除Shell:刪除失敗!: {0}", client.ConnectionInfo.Host));
                    }
                }
            }
            catch(Exception e)
            {
                retval.Status = e.Message;
                return retval;
                //retval.Status = string.Format(Resources.Language.Fail, string.Empty);
            }

            if (cb_CreateDetail.Checked)
            {
                try
                {
                    string local_shell = string.Format(@"C:\SecurityScan\Tools\{0}", get_shell_detail);
                    string target_shell = string.Format(@"/tmp/{0}", get_shell_detail);
                    _ssh_pw = Password;
                    PasswordAuthenticationMethod pauth = new PasswordAuthenticationMethod(UserName, _ssh_pw); // 使用 password 驗證。
                    KeyboardInteractiveAuthenticationMethod kAuth = new KeyboardInteractiveAuthenticationMethod(UserName); // 使用 keyboard-interactive 驗證。
                    kAuth.AuthenticationPrompt += new EventHandler<AuthenticationPromptEventArgs>(HandleKeyEvent);
                    ConnectionInfo conInfo = new ConnectionInfo(Ip, 22, UserName, pauth, kAuth);

                    try
                    {
                        using (SftpClient client = new SftpClient(conInfo))
                        {
                            client.Connect();
                            SendFileToRemote(client, local_shell, target_shell);
                        }
                    }
                    catch
                    {
                        using (ScpClient client = new ScpClient(conInfo))
                        {
                            client.Connect();
                            using (Stream localFile = File.OpenRead(local_shell))
                            {
                                client.Upload(localFile, target_shell);
                            }
                        }
                    }

                    using (SshClient client = new SshClient(conInfo))
                    {
                        client.Connect();
                        if (!client.IsConnected)
                            throw new Exception(string.Format("無法連線至遠端主機: {0}", client.ConnectionInfo.Host));

                        List<string> arglist = client.RunCommand(target_shell).Result.Split('\n').ToList();
                    }

                    //先不刪除目標機器script，因detail比較會遇到問題，可進機器除錯。
                    //using (SshClient client = new SshClient(conInfo))
                    //{
                    //    client.Connect();
                    //    if (!client.IsConnected)
                    //        throw new Exception(string.Format("刪除Shell:無法連線至遠端主機: {0}", client.ConnectionInfo.Host));

                    //    var Result = client.RunCommand(string.Format("rm {0}", target_shell));
                    //    if (Result.ExitStatus != 0)
                    //    {
                    //        throw new Exception(string.Format("刪除Shell:刪除失敗!: {0}", client.ConnectionInfo.Host));
                    //    }
                    //}
                }
                catch (Exception e)
                {
                    retval.Status += "，Detail失敗:"+ e.Message;
                }
            }
            
        }
        return retval;
    }

    private void GridView_AddConfig(DataTable Source, string Ip, string UserName, string Password)
    {
        HostInfo info = GetConfigFromRemote(Ip, UserName, Password);

        Source.Rows.Add(
            new object[] {
                    Source.Rows.Count + 1,
                    Ip,
                    info.Status,
                    info.HostName,
                    info.UName,
                    info.OSName,
                    info.Data
            }
        );
    }

    private class HostInfo
    {
        public HostInfo() { }

        public string HostName { get; set; }

        public string UName { get; set; }

        public string OSName { get; set; }

        public string Status { get; set; }

        public string Data { get; set; }

    }

    private void HandleKeyEvent(object sender, AuthenticationPromptEventArgs e)
    {
        foreach (AuthenticationPrompt prompt in e.Prompts)
        {
            if (prompt.Request.IndexOf("Password:", StringComparison.InvariantCultureIgnoreCase) != -1 ||
                prompt.Request.IndexOf("密碼:", StringComparison.InvariantCultureIgnoreCase) != -1)
            {
                prompt.Response = this._ssh_pw;
            }
        }
    }

}