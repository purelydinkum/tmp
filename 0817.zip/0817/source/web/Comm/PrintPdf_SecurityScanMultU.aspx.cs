﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using System.Configuration;
using System.Data;
using System.IO;
using System.Resources;
using ICSharpCode.SharpZipLib.Zip;

public partial class Comm_PrintPdf_SecurityScanMultU : CallbackPage
{
    ResourceManager ReportRex = Resources.ReportRex.ResourceManager;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["SearchResult"] == null)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Comm_PrintPdf_ConfigChangeU", "alert('無資料列可供匯出！');window.close()", true);
            return;
        }
        
        try
        {
            string pdfName = "ConfigSecurityReport" + DateTime.Now.ToString("yyyyMMdd") + ".zip";
            Response.Clear();

            HttpContext.Current.Response.AddHeader("Content-Disposition", string.Format("attachment;filename={0}", pdfName));
            HttpContext.Current.Response.ContentType = "application/zip";

            DataTable Policy = GetPolicySetPoint();

            using (var zipStream = new ZipOutputStream(Response.OutputStream))
            {
                string Filename = "ConfigSecurityReport_{0}.pdf";
                foreach (OsType item in (OsType[])Enum.GetValues(typeof(OsType)))
                {
                    byte[] fileBytes = CreatePDF(item, Policy).GetBuffer();
                    ZipEntry fileEntry = new ZipEntry(string.Format(Filename, item))
                    {
                        Size = fileBytes.Length
                    };

                    zipStream.PutNextEntry(fileEntry);
                    zipStream.Write(fileBytes, 0, fileBytes.Length);
                }

                zipStream.Flush();
                zipStream.Close();
            }

        }
        catch (Exception ex)
        {
            Utility.Write(System.Diagnostics.TraceEventType.Information, ex.ToString());
            Response.Write(ex.ToString());
            Response.Flush();
            Response.End();
        }
    }

    protected MemoryStream CreatePDF(OsType osType, DataTable Policy)
    {
        try
        {
            string[] Header = new string[10];

            Document doc1 = new Document(PageSize.A4.Rotate(), 5, 5, 25, 35);

            MemoryStream Memory = new MemoryStream();
            PdfWriter writer = PdfWriter.GetInstance(doc1, Memory);

            //加頁碼
            TwoColumnHeaderFooter PageEventHandler = new TwoColumnHeaderFooter();
            writer.PageEvent = PageEventHandler;
            // Define the page header
            PageEventHandler.Title = Title;

            PageEventHandler.FooterText = "";

            doc1.Open();
            
            DataTable data_source = Session["SearchResult"] as DataTable;
            string check_date2 = Session["CheckDateTimeString2"].ToString();
            string check_date3 = Session["CheckDateTimeString3"].ToString();
            string check_date;
            if (!string.IsNullOrEmpty(check_date3))
            {
                check_date = check_date3;
            }
            else
            {
                check_date = check_date2;
            }
            string Dept = Session["SearchDept"] != null ? Session["SearchDept"].ToString() : "";
            
            // 產生開頭
            PdfPTable retval_HEAD = null;
            retval_HEAD = new PdfPTable(new float[] { 200, 600, 200 });
            retval_HEAD.TotalWidth = 802f;
            retval_HEAD.LockedWidth = true;

            DateTime Dresult;
            DateTime.TryParseExact(
                 check_date,
                 "yyyy/MM/dd HH:mm",
                 System.Globalization.CultureInfo.InvariantCulture,
                 System.Globalization.DateTimeStyles.AssumeUniversal,
                 out Dresult);
            int Year = Dresult.Year - 1911;
            var cell_1 = CreateCell(CellType.Body, string.Format("{0}年度非Windows主機重要系統安全參數設定檢核表", Year), size: 20);
            cell_1.Colspan = 3;
            cell_1.PaddingBottom = 5f;
            retval_HEAD.AddCell(cell_1);
            var cell_2 = CreateCell(CellType.Body, string.Format("業務主辦科 : {0}", Dept));
            cell_2.HorizontalAlignment = Element.ALIGN_LEFT;
            cell_2.BorderWidthRight = 0;
            retval_HEAD.AddCell(cell_2);
            var cell_3 = CreateCell(CellType.Body, "機密等級: 敏感");
            cell_3.BorderWidthLeft = 0;
            cell_3.BorderWidthRight = 0;
            retval_HEAD.AddCell(cell_3);
            var cell_4 = CreateCell(CellType.Body, string.Format("盤點日期:{0}", check_date));
            cell_4.BorderWidthLeft = 0;
            cell_4.HorizontalAlignment = Element.ALIGN_RIGHT;
            retval_HEAD.AddCell(cell_4);

            Paragraph p = new Paragraph();
            p.IndentationLeft = 5f;
            p.Alignment = Element.ALIGN_LEFT;
            p.Add(retval_HEAD);
            doc1.Add(p);
            //

            if (osType == OsType.AIX)
            {
                #region AIX
                DataRow[] AIXResult = data_source.Select("UnixOSName like '%AIX%' and UnixServerStatus Like '%成功%'");
                List<Policy_Item> AIX_Police = new List<Policy_Item>();
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_MaxHistories", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_MaxHistories") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_MaxWeeks", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_MaxWeeks") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_MinWeeks", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_MinWeeks") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_MinLength", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_MinLength") });
                //AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_warn_time", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_warn_time") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_retries", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_retries") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_histexpire", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_histexpire") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_minother", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_minother") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_minalpha", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_minalpha") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_mindigit", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_mindigit") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_minupperalpha", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_minupperalpha") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_minloweralpha", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_minloweralpha") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_mindiff", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_mindiff") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_dictionlist", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_dictionlist") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_pwd_algo_info", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_pwd_algo_info") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_umask", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_umask") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_logininterval", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_logininterval") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_logindisable", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_logindisable") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_loginreenable", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_loginreenable") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_logintimeout", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_logintimeout") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_logindelay", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_logindelay") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_tmout", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_tmout") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_auditstart", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_auditstart") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_auditshutdown", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_auditshutdown") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_ignorerhosts", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_ignorerhosts") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_binmode", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_binmode") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_ip_forward", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_ip_forward") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_send_redirects", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_send_redirects") });
                //AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_guest", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_guest") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_superuser", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_superuser") });
                AIX_Police.Add(new Policy_Item() { Policy_Name = "AIX_NonAuditSuperuser", Policy_Value = DtGetPolicySetPoint(Policy, "AIX_NonAuditSuperuser") });
                CreateTable(doc1, AIXResult, AIX_Police);
                #endregion
            }

            if(osType == OsType.SUSE)
            {
                #region SUSE
                DataRow[] SUSEResult = data_source.Select("UnixOSName like '%SUSE%' and UnixServerStatus Like '%成功%'");
                List<Policy_Item> SUSE_Police = new List<Policy_Item>();
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_MaxHistories", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_MaxHistories") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_MaxDays", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_MaxDays") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_MinDays", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_MinDays") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_MinLength", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_MinLength") });
                //SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_warn_time", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_warn_time") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_retries", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_retries") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_dcredit", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_dcredit") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_ucredit", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_ucredit") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_lcredit", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_lcredit") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_difok", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_difok") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_dictpath", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_dictpath") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_pwd_algo_info", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_pwd_algo_info") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_umask", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_umask") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_fail_interval", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_fail_interval") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_deny", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_deny") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_unlock_time", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_unlock_time") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_LOGIN_TIMEOUT", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_LOGIN_TIMEOUT") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_delay", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_delay") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_tmout", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_tmout") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_ignorerhosts", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_ignorerhosts") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_martians", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_martians") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_ip_forward", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_ip_forward") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_send_redirects", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_send_redirects") });
                SUSE_Police.Add(new Policy_Item() { Policy_Name = "SUSE_superuser", Policy_Value = DtGetPolicySetPoint(Policy, "SUSE_superuser") });
                CreateTable(doc1, SUSEResult, SUSE_Police);
                #endregion
            }

            if (osType == OsType.Solaris)
            {
                #region Solaris
                DataRow[] SolarisResult = data_source.Select("UnixOSName like '%Solaris%' and UnixServerStatus Like '%成功%'");
                List<Policy_Item> Solaris_Police = new List<Policy_Item>();
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_MaxHistories", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_MaxHistories") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_MaxWeeks", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_MaxWeeks") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_MinWeeks", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_MinWeeks") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_MinLength", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_MinLength") });
                //Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_warn_time", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_warn_time") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_retries", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_retries") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_min_nonalpha", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_min_nonalpha") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_min_alpha", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_min_alpha") });
                //Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_min_digit", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_min_digit") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_min_upper", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_min_upper") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_min_lower", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_min_lower") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_min_diff", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_min_diff") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_dictionlist", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_dictionlist") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_pwd_algo_info", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_pwd_algo_info") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_umask", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_umask") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_disabletime", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_disabletime") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_logingracetime", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_logingracetime") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_sleeptime", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_sleeptime") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_clientaliveinterval", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_clientaliveinterval") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_ignorerhosts", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_ignorerhosts") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_forward_src_routed", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_forward_src_routed") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_send_redirects", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_send_redirects") });
                Solaris_Police.Add(new Policy_Item() { Policy_Name = "Solaris_superuser", Policy_Value = DtGetPolicySetPoint(Policy, "Solaris_superuser") });
                CreateTable(doc1, SolarisResult, Solaris_Police);
                #endregion
            }

            if (osType == OsType.Linux)
            {
                #region Linux
                DataRow[] LinuxResult = data_source.Select(" UnixOSName Not Like '%AIX%' and UnixOSName Not Like '%SUSE%' and  UnixOSName Not Like '%Solaris%' and UnixServerStatus Like '%成功%'");
                List<Policy_Item> Linux_Police = new List<Policy_Item>();
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_MaxHistories", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_MaxHistories") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_MaxDays", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_MaxDays") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_MinDays", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_MinDays") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_MinLength", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_MinLength") });
                //Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_warn_time", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_warn_time") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_retries", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_retries") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_dcredit", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_dcredit") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_ucredit", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_ucredit") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_lcredit", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_lcredit") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_difok", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_difok") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_dictpath", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_dictpath") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_pwd_algo_info", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_pwd_algo_info") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_umask", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_umask") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_fail_interval", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_fail_interval") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_deny", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_deny") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_unlock_time", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_unlock_time") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_ServerAliveInterval", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_ServerAliveInterval") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_delay", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_delay") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_tmout", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_tmout") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_ignorerhosts", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_ignorerhosts") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_martians", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_martians") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_ip_forward", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_ip_forward") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_send_redirects", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_send_redirects") });
                Linux_Police.Add(new Policy_Item() { Policy_Name = "Linux_superuser", Policy_Value = DtGetPolicySetPoint(Policy, "Linux_superuser") });
                CreateTable(doc1, LinuxResult, Linux_Police);

                #endregion
            }

            // 產生結尾
            PdfPTable retval_END = null;
            //20個
            retval_END = new PdfPTable(new float[] { 40,40,40,40,40,40,40,40,40,40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40 });
            retval_END.TotalWidth = 802f;
            retval_END.LockedWidth = true;

            var cell_END1 = CreateCell(CellType.Empty, "備註:");
            cell_END1.Colspan = 20;
            cell_END1.HorizontalAlignment = Element.ALIGN_LEFT;
            retval_END.AddCell(cell_END1);

            var cell_END2 = CreateCell(CellType.Body, "符號顯示");
            cell_END2.Colspan = 2;
            cell_END2.HorizontalAlignment = Element.ALIGN_CENTER;
            retval_END.AddCell(cell_END2);

            var cell_END2_1 = CreateCell(CellType.Body, "符號說明");
            cell_END2_1.Colspan = 5;
            cell_END2_1.HorizontalAlignment = Element.ALIGN_LEFT;
            retval_END.AddCell(cell_END2_1);

            AddEmptyCell(retval_END, 13);

            var cell_END3 = CreateCell(CellType.Body, "=");
            cell_END3.Colspan = 2;
            cell_END3.HorizontalAlignment = Element.ALIGN_CENTER;
            retval_END.AddCell(cell_END3);

            var cell_END3_1 = CreateCell(CellType.Body, "與合規值相符");
            cell_END3_1.Colspan = 5;
            cell_END3_1.HorizontalAlignment = Element.ALIGN_LEFT;
            retval_END.AddCell(cell_END3_1);

            AddEmptyCell(retval_END, 13);

            var cell_END4 = CreateCell(CellType.Body, "", IsAbnormal: true);
            cell_END4.Colspan = 2;
            cell_END4.HorizontalAlignment = Element.ALIGN_CENTER;
            retval_END.AddCell(cell_END4);

            var cell_END4_1 = CreateCell(CellType.Body, "未設定，請修改");
            cell_END4_1.Colspan = 5;
            cell_END4_1.HorizontalAlignment = Element.ALIGN_LEFT;
            retval_END.AddCell(cell_END4_1);

            AddEmptyCell(retval_END, 13);

            var cell_END5 = CreateCell(CellType.Body, "數值",IsAbnormal: true);
            cell_END5.Colspan = 2;
            cell_END5.HorizontalAlignment = Element.ALIGN_CENTER;
            retval_END.AddCell(cell_END5);

            var cell_END5_1 = CreateCell(CellType.Body, "不相符，請修改  或  說明不修改原因");
            cell_END5_1.Colspan = 5;
            cell_END5_1.HorizontalAlignment = Element.ALIGN_LEFT;
            retval_END.AddCell(cell_END5_1);

            AddEmptyCell(retval_END, 13);


            retval_END.AddCell(CreateCell(CellType.Empty, ""));
            retval_END.AddCell(CreateCell(CellType.Empty, ""));
            retval_END.AddCell(CreateCell(CellType.Empty, ""));
            retval_END.AddCell(CreateCell(CellType.Empty, ""));
            retval_END.AddCell(CreateCell(CellType.Empty, ""));
            retval_END.AddCell(CreateCell(CellType.Empty, ""));
            retval_END.AddCell(CreateCell(CellType.Empty, ""));
            retval_END.AddCell(CreateCell(CellType.Empty, ""));
            retval_END.AddCell(CreateCell(CellType.Empty, "副科長:"));
            retval_END.AddCell(CreateCell(CellType.Empty, ""));
            retval_END.AddCell(CreateCell(CellType.Empty, ""));
            retval_END.AddCell(CreateCell(CellType.Empty, ""));
            retval_END.AddCell(CreateCell(CellType.Empty, "科長:"));
            retval_END.AddCell(CreateCell(CellType.Empty, ""));
            retval_END.AddCell(CreateCell(CellType.Empty, ""));
            retval_END.AddCell(CreateCell(CellType.Empty, ""));
            var cell_END6 = CreateCell(CellType.Empty, "歸檔人員:");
            cell_END6.Colspan = 4;
            cell_END6.HorizontalAlignment = Element.ALIGN_LEFT;
            retval_END.AddCell(cell_END6);

            Paragraph p_end = new Paragraph();
            p_end.IndentationLeft = 5f;
            p_end.Alignment = Element.ALIGN_LEFT;
            p_end.Add(retval_END);
            doc1.Add(p_end);
            //

            doc1.Close();

            return Memory;
            
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    private void AddEmptyCell(PdfPTable retval,int Num)
    {
        for (int i = 0; i < Num; i++)
        {
            retval.AddCell(CreateCell(CellType.Empty, ""));
        }
    }
    private float[] GetFloat(int DataCount,float HeadFloat = 20, float DataFloat = 10)
    {
        //表示頭(電腦名稱、IP、核心版本、發行版本)和尾(異動案號、檢視、複合)
        int floatHead = 7;
        float[] R = new float[floatHead + DataCount];

        for (int i = 0; i < 4; i++)
        {
            R[i] = HeadFloat;
        }

        for (int i = 4; i < R.Count(); i++)
        {
            R[i] = DataFloat;
        }

        return R;
    }

    public enum OsType
    {
        AIX,
        Linux,
        SUSE,
        Solaris
    }
    public DataTable dt_Layout;

    private enum CellType { Header, Body, Empty }

    private PdfPCell CreateCell(CellType Type, string CellValue, bool IsAbnormal = false, float size = 10)
    {
        PdfPCell retval = null;
        string fontPath = Environment.GetFolderPath(Environment.SpecialFolder.System) + @"\..\Fonts\kaiu.ttf";
        BaseFont bfChinese = BaseFont.CreateFont(
            fontPath,
            BaseFont.IDENTITY_H, //橫式中文
            BaseFont.NOT_EMBEDDED
            );

        Font ChFont = new Font(bfChinese, size);
        Font ChAbnormal = new Font(bfChinese, size, Font.NORMAL, Color.RED);

        Font font;
        if (IsAbnormal)
        {
            font = ChAbnormal;
            if (string.IsNullOrEmpty(CellValue))
            {
                CellValue = "???";
            }
            else
            {
                CellValue = "***" + CellValue;
            }
        }
        else
        {
            font = ChFont;
        }
        retval = new PdfPCell(new Phrase(CellValue, font))
        {
            MinimumHeight = 20f,
            VerticalAlignment = Element.ALIGN_MIDDLE,
            HorizontalAlignment = Element.ALIGN_CENTER
        };

        if (Type == CellType.Header)
            retval.BackgroundColor = new Color(222, 225, 231);

        if (Type == CellType.Empty)
            retval.Border = Rectangle.NO_BORDER;

        return retval;
    }
    private class Policy_Item
    {
        public string Policy_Name { get; set; }

        public string Policy_Value { get; set; }
    }
    private void CreateTable(Document document, DataRow[] SearchResult, List<Policy_Item> policy_Items, int HeadSize = 7)
    {

        PdfPTable retval = null;
        try
        {
            // 產生Head
            retval = new PdfPTable(GetFloat(policy_Items.Count()));
            retval.TotalWidth = 802f;
            retval.LockedWidth = true;

            retval.AddCell(CreateCell(CellType.Header, "主機名稱"));
            retval.AddCell(CreateCell(CellType.Header, "主機IP"));
            retval.AddCell(CreateCell(CellType.Header, "核心版本"));
            retval.AddCell(CreateCell(CellType.Header, "發行版本"));

            //將標頭加入，若字太多可考慮調整字體大小。
            foreach (var policy_Item in policy_Items)
            {
                switch (policy_Item.Policy_Name)
                {
                    case "AIX_histexpire":
                    case "AIX_auditstart":
                    case "AIX_auditshutdown":
                    case "AIX_send_redirects":
                    case "Linux_send_redirects":
                    case "SUSE_send_redirects":
                    case "Solaris_send_redirects":
                        retval.AddCell(CreateCell(CellType.Header, ReportRex.GetString(policy_Item.Policy_Name), size: 5));
                        break;
                    default:
                        retval.AddCell(CreateCell(CellType.Header, ReportRex.GetString(policy_Item.Policy_Name), size: HeadSize));
                        break;
                }
            }
            retval.AddCell(CreateCell(CellType.Header, "不符合之說明 / 異動案號", size: HeadSize));
            retval.AddCell(CreateCell(CellType.Header, "檢視人員", size: HeadSize));
            retval.AddCell(CreateCell(CellType.Header, "覆核人員", size: HeadSize));

            // 產生合規值
            var cell = CreateCell(CellType.Body, "合規值");
            cell.Colspan = 4;
            retval.AddCell(cell);
            foreach (var policy_Item in policy_Items)
            {
                retval.AddCell(CreateCell(CellType.Body, policy_Item.Policy_Value));
            }
            retval.AddCell(CreateCell(CellType.Body, ""));
            retval.AddCell(CreateCell(CellType.Body, ""));
            retval.AddCell(CreateCell(CellType.Body, ""));

            // 產生 Body
            //因需要排序，需先判斷有問題數量再加入CELL

            List<List<object>> Result = new List<List<object>>();
            foreach (DataRow row in SearchResult)
            {
                string Data = Convert.ToString(row["UnixData"]);
                string[] DataS = Data.Split('\n');
                //Utility.Write(System.Diagnostics.TraceEventType.Information, Data); //看資料log
                List<Result> R = new List<Result>();
                int i = 0;
                foreach (var policy_Item in policy_Items)
                {
                    R.Add(new Result() { Policy = policy_Item.Policy_Name
                        , Value = DataS.Length > i ? DataS[i] : "DataError"
                        , std_Value = policy_Item.Policy_Value });
                    i++;
                }

                Result.Add(CreateData(R, Convert.ToString(row["ServerIP"]), Convert.ToString(row["UnixHostName"]), Convert.ToString(row["UName"]), Convert.ToString(row["UnixOSName"])));
            }

            printData(retval, Result);

            var cell_total = CreateCell(CellType.Body, string.Format("總台數:{0}", SearchResult.Count()));
            cell_total.BorderWidth = 0;
            cell_total.Colspan = policy_Items.Count + 5;
            cell_total.HorizontalAlignment = Element.ALIGN_LEFT;
            retval.AddCell(cell_total);
        }
        catch (Exception ex)
        {
            throw ex;
        }

        Paragraph p = new Paragraph();
        p.IndentationLeft = 5f;
        p.Alignment = Element.ALIGN_LEFT;
        p.Add(retval);
        document.Add(p);
    }

    private List<object> CreateData(List<Result> R,string ServerIP,string UnixHostName, string UName, string UnixOSName)
    {
        List<object> RowResult = new List<object>();
        string abnormal_options = "";
        int abnormal_count = 0;
        RowResult.Add(CreateCell(CellType.Body, UnixHostName));
        RowResult.Add(CreateCell(CellType.Body, ServerIP));
        RowResult.Add(CreateCell(CellType.Body, UName));
        RowResult.Add(CreateCell(CellType.Body, UnixOSName));
        foreach (var item in R)
        {
            bool isAbnormal = CommonInfo.GCB_isAbnormal(item.Value, item.std_Value, item.Policy);
            if (isAbnormal)
            {
                abnormal_count++;
                abnormal_options += ReportRex.GetString(item.Policy) + "\n";
            }
            RowResult.Add(CreateCell(CellType.Body, isAbnormal ? item.Value : "=", isAbnormal));
        }
        RowResult.Add(abnormal_count);
        return RowResult;
    }

    private void printData(PdfPTable retval, List<List<object>> Result)
    {
        Result.Sort((x, y) => { return -((int)x.Last()).CompareTo((int)y.Last()); });

        foreach (List<object> item in Result)
        {
            //-1 為不符數量
            for (int i = 0; i < item.Count - 1; i++)
            {
                retval.AddCell((PdfPCell)item[i]);
            }

            //為後面3個欄位
            retval.AddCell(CreateCell(CellType.Body, ""));
            retval.AddCell(CreateCell(CellType.Body, ""));
            retval.AddCell(CreateCell(CellType.Body, ""));
        }

    }
    private string GetPolicySetPoint(string PolicyName)
    {
        var retval = "";
        var da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
        ParameterCollection objParams = new ParameterCollection();

        string strQuery = "SELECT SetPoint FROM PolicyNecessaryU WHERE Policy = @Policy";
        objParams.Add("Policy", DbType.String, PolicyName);

        var dt = da.ExecuteDataTable(strQuery, objParams);

        if (dt.Rows.Count > 0)
            retval = Convert.ToString(dt.Rows[0]["SetPoint"]);

        return retval;
    }

    private DataTable GetPolicySetPoint()
    {
        var da = new DataAccess(ConfigurationManager.AppSettings["DataBaseName_CHB"]);
        ParameterCollection objParams = new ParameterCollection();

        string strQuery = "SELECT * FROM PolicyNecessaryU ";

        var dt = da.ExecuteDataTable(strQuery, objParams);

        return dt;
    }
    private string DtGetPolicySetPoint(DataTable dt,string Policy)
    {
        return dt.AsEnumerable().Where(x => x.Field<string>("Policy") == Policy).Select(x => x.Field<string>("SetPoint")).FirstOrDefault();
    }
    private class Result
    {
        public string Policy { get; set; }
        public string Value { get; set; }
        public string std_Value { get; set; }
    }
}