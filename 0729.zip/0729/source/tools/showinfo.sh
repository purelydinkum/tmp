call_sh=`ps -p $$ -ocomm=`
test_bash=`echo ${call_sh} | grep bash`
test_ksh=`echo ${call_sh} | grep ksh`
if [ -z "${test_bash}" ] && [ -z "${test_ksh}" ]; then
  if [ -f "/bin/bash" ]; then
    exec bash "$0" "$@"
  fi
  if [ -f "/bin/ksh" ]; then
    exec ksh "$0" "$@"
  fi
fi

# Oracle Linux
os_ol_5="EnterpriseLinux_5"
os_ol_7="OracleLinux_7"

# Solaris
os_solaris_11="Solaris_11"
os_solaris_10="Solaris_10"

# Red Hat Enterprise Linux
os_rhel_7="RedHat_7"
os_rhel_6="RedHat_6"

# SUSE Linux Enterprise Server 
os_suse_15="SUSE_15"
os_suse_11="SUSE_11"

# CentOS
os_centos_7="CentOS_7"

# IBM AIX
os_aix_7_5="AIX_7_5"

os_ol=${os_ol_7}
os_solaris=${os_solaris_11}
os_rh=${os_rhel_7}
os_suse=${os_suse_15}
os_centos=${os_centos_7}
os_aix=${os_aix_7_5}

# release file
rel_ol=/etc/oracle-release
rel_osol=/etc/release
rel_rh=/etc/redhat-release
rel_suse=/etc/SuSE-release
rel_centos=/etc/centos-release
rel_common=/etc/os-release

# system configs
syscfg_etc_hosts=/etc/hosts
syscfg_etc_hostsallow=/etc/hosts.allow
syscfg_etc_hostsdeny=/etc/hosts.deny
syscfg_etc_resolvconf=/etc/resolv.conf
syscfg_etc_inittab=/etc/inittab
syscfg_etc_passwd=/etc/passwd
syscfg_etc_shadow=/etc/shadow
syscfg_etc_group=/etc/group
syscfg_etc_gshadow=/etc/gshadow
syscfg_etc_logindefs=/etc/login.defs
syscfg_var_log_cron=/var/log/cron
syscfg_var_log_lastlog=/var/log/lastlog
syscfg_var_log_messages=/var/log/messages
syscfg_var_log_secure=/var/log/secure
syscfg_var_log_wtmp=/var/log/wtmp

# web server directory browsing
httpd_ws=/usr/IBM/HTTPServer/conf/httpd.conf
httpd_apache1=/usr/local/apache2/conf/httpd.conf
httpd_apache2=/etc/httpd/conf/httpd.conf
httpd_apache3=/etc/apache2/httpd.conf

awk_cmd="awk"
ip_cmd="ifconfig -a"
grep_cmd="grep"
os=""

gen_sys_info(){
  os_name=""
  os_info_file=""
  if [ -f "${rel_osol}" ]; then
    os_info_file="${rel_osol}"
    os_name=$(echo $(cat ${os_info_file} | head -n 1))
    if [ ! -z "$(echo ${os_name} | ${grep_cmd} ' 10')" ]; then
      os=${os_solaris_10}
      awk_cmd="nawk"
    else
      os=${os_solaris}
      awk_cmd="gawk"
    fi
    grep_cmd="egrep"
  elif [ -f "${rel_ol}" ]; then
    os_info_file="${rel_ol}"
    os_name=$(echo $(cat ${os_info_file} | head -n 1))
    os=${os_ol}
  elif [ -f "${rel_rh}" ]; then
    os_info_file="${rel_rh}"
    os_name=$(echo $(cat ${os_info_file} | head -n 1))
    if [ ! -z "$(echo ${os_name} | ${grep_cmd} ' 6.')" ]; then
      os=${os_rhel_6}
    else
      os=${os_rh}
      ip_cmd="ip addr "
    fi
  elif [ -f "${rel_suse}" ]; then
    os_info_file="${rel_suse}"
    os_name=$(echo $(cat ${os_info_file} | head -n 1))
    if [ ! -z "$(echo ${os_name} | ${grep_cmd} ' 11 ')" ]; then
      os=${os_suse_11}
    else
      os=${os_suse}
    fi
    ip_cmd="ip addr "
  elif [ -f "${rel_centos}" ]; then
    os_info_file="${rel_centos}"
    os_name=$(echo $(cat ${os_info_file} | head -n 1))
    os=${os_centos}
  elif [ -f "${rel_common}" ]; then
    os_info_file="${rel_common}"
    os=""
  else
    os_info_file=""
    os=""
  fi
  if [ ! -z "${os_info_file}" ]; then
    if [ -z "${os_name}" ]; then
      os_name=$(cat ${os_info_file} | ${grep_cmd} PRETTY_NAME | ${awk_cmd} -F'"' '{print $2}')
      if [ ! -z "$(echo ${os_name} | ${grep_cmd} 'SUSE Linux Enterprise Server')" ]; then
        if [ ! -z "$(echo ${os_name} | ${grep_cmd} ' 11 ')" ]; then
          os=${os_suse_11}
        else
          os=${os_suse}
        fi
        ip_cmd="ip addr "
      elif [ ! -z "$(echo ${os_name} | ${grep_cmd} 'Enterprise Linux Enterprise Linux Server')" ]; then
        if [ ! -z "$(echo ${os_name} | ${grep_cmd} ' 5.')" ]; then
          os=${os_ol_5}
        else
          os=${os_ol}
        fi
      elif [ ! -z "$(echo ${os_name} | ${grep_cmd} 'Oracle Linux')" ]; then
        os=${os_ol}
      elif [ ! -z "$(echo ${os_name} | ${grep_cmd} 'Red Hat Enterprise Linux')" ]; then
        if [ ! -z "$(echo ${os_name} | ${grep_cmd} ' 6.')" ]; then
          os=${os_rhel_6}
        else
          os=${os_rh}
        fi
      elif [ ! -z "$(echo ${os_name} | ${grep_cmd} 'CentOS Linux')" ]; then
        os=${os_centos}
      else
        echo "[SYS] release info found, but disto is unrecognized."
        echo "[SYS] os_name: ${os_name}"
        exit 1
      fi
    fi
  else
    os_name=$(uname -s)
    if [ ! -z $(echo ${os_name} | ${grep_cmd} 'AIX') ]; then
      os_name=$(echo "${os_name} $(oslevel)")
      os=${os_aix}
    else
      printf "[SYS] release info not found."
      exit 1
    fi
  fi
  if [ "${os}" = "${os_rhel_6}" ] || [ "${os}" = "${os_ol_5}" ]; then
    ipaddrs=$(echo $(${ip_cmd} | ${grep_cmd} 'inet ' | ${awk_cmd} -F' ' '{print $2}' | ${grep_cmd} -v 127.0.0.1 | cut -d ":" -f 2) | sed 's/ /,/')
  else
    ipaddrs=$(echo $(${ip_cmd} | ${grep_cmd} 'inet ' | ${awk_cmd} -F' ' '{print $2}' | ${grep_cmd} -v 127.0.0.1) | sed 's/ /,/')
  fi
  printf "  <SysInfo>\n"
  printf "    <HostName>$(hostname)</HostName>\n"
  printf "    <IPAddress>${ipaddrs}</IPAddress>\n"
  printf "    <OSName>${os_name}</OSName>\n"
  printf "    <CallShell>${call_sh}</CallShell>\n"
  printf "  </SysInfo>\n"
}
gen_disk_info(){
  printf "  <Disks>\n"
  if [ "${os}" = "${os_aix}" ]; then
    mountpt_list=$(df | tail +2 | ${grep_cmd} -v "^/proc " | ${awk_cmd} -F' ' '{print $(NF)}') 
    for mountpt_name in ${mountpt_list}
    do
      size=$(df ${mountpt_name} | tail +2 | ${awk_cmd} -F' ' '{print $2}')
      free=$(df ${mountpt_name} | tail +2 | ${awk_cmd} -F' ' '{print $3}')
      usedpcnt=$(df ${mountpt_name} | tail +2 | ${awk_cmd} -F' ' '{print $4}' | cut -d'%' -f 1)
      filesystem=$(df ${mountpt_name} | tail +2 | ${awk_cmd} -F' ' '{print $1}')
      fstype=$(lsfs | ${grep_cmd} " ${mountpt_name} " | tail +2 | ${awk_cmd} -F' ' '{print $4}')
      printf "    <Disk name='${filesystem}' fstype='${fstype}' total='${size}' free='${free}' usedpcnt='${usedpcnt}' mountpt='${mountpt_name}'></Disk>\n"
    done
  elif [ "${os}" = "${os_solaris}" ] || [ "${os}" = "${os_solaris_10}" ]; then
    mountpt_list=$(df -k | tail +2 | ${awk_cmd} -F' ' '{print $(NF)}')
    for mountpt_name in ${mountpt_list}
    do
      size=$(df -k | ${grep_cmd} " ${mountpt_name}$" | ${awk_cmd} -F' ' '{print $2}')
      free=$(df -k | ${grep_cmd} " ${mountpt_name}$" | ${awk_cmd} -F' ' '{print $4}')
      usedpcnt=$(df -k | ${grep_cmd} " ${mountpt_name}$" | ${awk_cmd} -F' ' '{print $5}' | cut -d'%' -f 1)
      filesystem=$(df -k | ${grep_cmd} " ${mountpt_name}$" | ${awk_cmd} -F' ' '{print $1}')
      fstype=$(df -n | ${grep_cmd} " ${mountpt_name}$" | ${awk_cmd} -F' ' '{print $(NF)}')
      printf "    <Disk name='${filesystem}' fstype='${fstype}' total='${size}' free='${free}' usedpcnt='${usedpcnt}' mountpt='${mountpt_name}'></Disk>\n"
    done
  else
    mountpt_list=$(df -P| tail -n +2 | ${grep_cmd} -v "^tmpfs \|^devtmpfs " | ${awk_cmd} -F' ' '{print $(NF)}')
    for mountpt_name in ${mountpt_list}
    do
      size=$(df -kP | ${grep_cmd} " ${mountpt_name}$" | ${awk_cmd} -F' ' '{print $2}')
      free=$(df -kP | ${grep_cmd} " ${mountpt_name}$" | ${awk_cmd} -F' ' '{print $4}')
      usedpcnt=$(df -kP | ${grep_cmd} " ${mountpt_name}$" | ${awk_cmd} -F' ' '{print $5}' | cut -d'%' -f 1)
      filesystem=$(df -kP | ${grep_cmd} " ${mountpt_name}$" | ${awk_cmd} -F' ' '{print $1}')
      fstype=$(df -TP | ${grep_cmd} " ${mountpt_name}$" | ${awk_cmd} -F' ' '{print $2}')
      printf "    <Disk name='${filesystem}' fstype='${fstype}' total='${size}' free='${free}' usedpcnt='${usedpcnt}' mountpt='${mountpt_name}'></Disk>\n"
    done
  fi
  printf "  </Disks>\n"
}
gen_svc_info(){
  printf "  <Services>\n"
  if [ "${os}" = "${os_aix}" ]; then
    svc_list=$(lssrc -a | tail +2 | ${awk_cmd} -F' ' '{print $1}')
    for svc_name in ${svc_list}
    do
      desc=""
      runtype=$(lssrc -a | ${grep_cmd} "^ ${svc_name} " | ${awk_cmd} -F' ' '{print $(NF)}')
      printf "    <Service name='${svc_name}' desc='${desc}' runtype='${runtype}'></Service>\n"
    done
  elif [ "${os}" = "${os_solaris}" ] || [ "${os}" = "${os_solaris_10}" ]; then
    svc_list=$(svcs -a | tail +2 | ${grep_cmd} -v "^legacy_run" | ${awk_cmd} -F' ' '{print $(NF)}')
    for svc_name in ${svc_list}
    do
      desc=$(svcs -l ${svc_name} | ${grep_cmd} "^name " | ${awk_cmd} -F' ' '{$1="";print substr($0,2)}')
      runtype=$(svcs -l ${svc_name} | ${grep_cmd} "^state " | ${awk_cmd} -F' ' '{print $2}')
      printf "    <Service name='${svc_name}' desc='${desc}' runtype='${runtype}'></Service>\n"
    done
  elif [ "${os}" = "${os_rhel_6}" ] || [ "${os}" = "${os_suse_11}" ] || [ "${os}" = "${os_ol_5}" ];then
    on_svc_list=$(chkconfig --list | grep 5:on | awk -F' ' '{print $1}')
    for on_svc_name in ${on_svc_list}
    do
      desc=""
      printf "    <Service name='${on_svc_name}' desc='${desc}' runtype='on'></Service>\n"
    done
    off_svc_list=$(chkconfig --list | grep 5:off | awk -F' ' '{print $1}')
    for off_svc_name in ${off_svc_list}
    do
      desc=""
      printf "    <Service name='${off_svc_name}' desc='${desc}' runtype='off'></Service>\n"
    done
  else
    svc_list=$(systemctl list-units --type service --all --no-pager --no-legend | ${awk_cmd} -F' ' '{print $1}')
    for svc_name in ${svc_list}
    do
      #desc=$(systemctl show --property Description --value ${svc_name})
      desc=$(systemctl show --property Description ${svc_name} | cut -d'=' -f 2)
      desc=$(echo "${desc}" | sed 's/&/\&amp;/g; s/</\&lt;/g; s/>/\&gt;/g; s/"/\&quot;/g; s/'"'"'/\&#39;/g' )
      #runtype=$(systemctl show --property ActiveState --value ${svc_name})
      runtype=$(systemctl show --property ActiveState ${svc_name} | cut -d'=' -f 2)
      printf "    <Service name='${svc_name}' desc='${desc}' runtype='${runtype}'></Service>\n"
    done
    if [ -x "$(command -v chkconfig)" ]; then
      on_svc_list=$(chkconfig --list | grep 5:on | awk -F' ' '{print $1}')
      for on_svc_name in ${on_svc_list}
      do
        desc=""
        printf "    <Service name='${on_svc_name}' desc='${desc}' runtype='on'></Service>\n"
      done
      off_svc_list=$(chkconfig --list | grep 5:off | awk -F' ' '{print $1}')
      for off_svc_name in ${off_svc_list}
      do
        desc=""
        retval=$(chkconfig -l ${off_svc_name} | grep ':[ ]*on')
        if [ -z "${retval}" ]; then
          printf "    <Service name='${off_svc_name}' desc='${desc}' runtype='off'></Service>\n"
        else
          printf "    <Service name='${off_svc_name}' desc='${desc}' runtype='on'></Service>\n"
        fi
      done
    fi
  fi
  printf "  </Services>\n"
}
gen_schd_info(){
  printf "  <Schedule>\n"
  if [ -f /etc/crontab ]; then
    job_list=$(cat /etc/crontab | ${grep_cmd} -v "^ *#")
    oldIFS=$IFS
    IFS=$'
'
    for job_cfg in ${job_list}
    do
      schd_min=$(echo "${job_cfg}" | ${awk_cmd} -F' ' '{print $1}')
      schd_hr=$(echo "${job_cfg}" | ${awk_cmd} -F' ' '{print $2}')
      schd_day=$(echo "${job_cfg}" | ${awk_cmd} -F' ' '{print $3}')
      schd_mon=$(echo "${job_cfg}" | ${awk_cmd} -F' ' '{print $4}')
      schd_dow=$(echo "${job_cfg}" | ${awk_cmd} -F' ' '{print $5}')
      if [ -z "${schd_min}" ] || [ -z "${schd_hr}" ] || [ -z "${schd_day}" ] || [ -z "${schd_mon}" ] || [ -z "${schd_dow}" ]; then
        continue;
      fi
      schd_acc=$(echo "${job_cfg}" | ${awk_cmd} -F' ' '{print $6}')
      schd_cmd=$(echo "${job_cfg}" | ${awk_cmd} -F' ' '{$1=$2=$3=$4=$5=$6="";print substr($0,7)}')
      schd_cmd=$(echo "${schd_cmd}" | sed 's/&/\&amp;/g; s/</\&lt;/g; s/>/\&gt;/g; s/"/\&quot;/g; s/'"'"'/\&#39;/g' )
      printf "    <Task exectime='${schd_min} ${schd_hr} ${schd_day} ${schd_mon} ${schd_dow}' cmds='${schd_cmd}' owner='${schd_acc}'></Task>\n"
    done
    IFS=$oldIFS
  fi
  if [ "${os}" = "${os_solaris}" ] || [ "${os}" = "${os_solaris_10}" ] || [ "${os}" = "${os_aix}" ]; then
    job_list=$(crontab -l root 2>/dev/null | ${grep_cmd} -v "^ *#")
  else
    job_list=$(crontab -u root -l 2>/dev/null | ${grep_cmd} -v "^ *#")
  fi
  if [ $? -eq 0 ]; then
    oldIFS=$IFS
    IFS=$'
'
    for job_cfg in ${job_list}
    do
      schd_min=$(echo "${job_cfg}" | ${awk_cmd} -F' ' '{print $1}')
      schd_hr=$(echo "${job_cfg}" | ${awk_cmd} -F' ' '{print $2}')
      schd_day=$(echo "${job_cfg}" | ${awk_cmd} -F' ' '{print $3}')
      schd_mon=$(echo "${job_cfg}" | ${awk_cmd} -F' ' '{print $4}')
      schd_dow=$(echo "${job_cfg}" | ${awk_cmd} -F' ' '{print $5}')
      schd_cmd=$(echo "${job_cfg}" | ${awk_cmd} -F' ' '{$1=$2=$3=$4=$5="";print substr($0,6)}')
      schd_cmd=$(echo "${schd_cmd}" | sed 's/&/\&amp;/g; s/</\&lt;/g; s/>/\&gt;/g; s/"/\&quot;/g; s/'"'"'/\&#39;/g')
      printf "    <Task exectime='${schd_min} ${schd_hr} ${schd_day} ${schd_mon} ${schd_dow}' cmds='${schd_cmd}' owner='root'></Task>\n"
    done
    IFS=$oldIFS
  fi
  printf "  </Schedule>\n"
}
gen_proc_info(){
  printf "  <Processes>\n"
  if [ "${os}" = "${os_solaris}" ] || [ "${os}" = "${os_solaris_10}" ] || [ "${os}" = "${os_aix}" ]; then
    cmd_list=$(ps -ef -o args=COMMAND | tail +2 | ${grep_cmd} -v "ps -ef" | ${grep_cmd} -v "tail +2")
  else
    cmd_list=$(ps -e --format cmd | tail -n +2 | ${grep_cmd} -v "ps -e --format" | ${grep_cmd} -v "tail -n +2")
  fi
  oldIFS=$IFS
  IFS=$'
'
  for exec_cmd in ${cmd_list}
  do
    runcmd=$(echo "${exec_cmd}" | sed 's/&/\&amp;/g; s/</\&lt;/g; s/>/\&gt;/g; s/"/\&quot;/g; s/'"'"'/\&#39;/g')
    echo "    <Process runcmd='${runcmd}'></Process>"
  done
  IFS=$oldIFS
  printf "  </Processes>\n"
}
gen_syscfg_access_info(){
  printf "  <SystemConfigs>\n"
  for syscfg in "${syscfg_etc_hosts}" "${syscfg_etc_hostsallow}" "${syscfg_etc_hostsdeny}" \
    "${syscfg_etc_resolvconf}" "${syscfg_etc_inittab}" "${syscfg_etc_passwd}" "${syscfg_etc_shadow}" \
    "${syscfg_etc_group}" "${syscfg_etc_gshadow}" "${syscfg_etc_logindefs}" "${syscfg_var_log_cron}" \
    "${syscfg_var_log_lastlog}" "${syscfg_var_log_messages}" "${syscfg_var_log_secure}" "${syscfg_var_log_wtmp}";
  do
    if [ -f "${syscfg}" ]; then
      if [ "${os}" = "${os_aix}" ]; then
        access=$(echo $(istat ${syscfg} | ${grep_cmd} Protection | ${awk_cmd} -F': ' '{print $2}'))
        owner=$(echo $(istat ${syscfg} | ${grep_cmd} Owner | ${awk_cmd} -F'[()]' '{print $2}'))
      else
        access=$(ls -l "${syscfg}" | ${awk_cmd} -F' ' '{print $1}' | cut -c2-10)
        owner=$(ls -l "${syscfg}" | ${awk_cmd} -F' ' '{print $3}')
      fi
      printf "    <File path='${syscfg}' access='${access}' owner='${owner}'></File>\n"
    fi
  done
  printf "  </SystemConfigs>\n"
}
gen_pkg_info(){
  printf "  <Packages>\n"
  if [ "${os}" = "${os_aix}" ]; then
    lslpp -cL | ${awk_cmd}  -v q="'" -F':' '{print "    <Package name=" q$2q " ver=" q$3q "></Package>"}'
  elif [ "${os}" = "${os_solaris}" ] || [ "${os}" = "${os_solaris_10}" ]; then
    pkg_list=$(pkginfo | ${awk_cmd} -F' ' '{print $2}')
    for pkg_name in ${pkg_list}
    do
      pkg_ver=$(echo $(pkginfo -l ${pkg_name} | ${grep_cmd} VERSION | ${awk_cmd} -F'[:,]' '{print $2}'))
      printf "    <Package name='${pkg_name}' ver='${pkg_ver}'></Package>\n"
    done
  else
    rpm -qa --qf "    <Package name='%{NAME}' ver='%{VERSION}'></Package>\n"
  fi
  printf "  </Packages>\n"
}
gen_policies_info(){
  if [ "${os}" = "${os_aix}" ]; then
    max_histories=$(echo $(lssec -f /etc/security/user -s default -a histsize | ${awk_cmd} -F'=' '{print $2}'))
    max_days=$(echo $(lssec -f /etc/security/user -s default -a maxage | ${awk_cmd} -F'=' '{print $2}'))
    min_days=$(echo $(lssec -f /etc/security/user -s default -a minage | ${awk_cmd} -F'=' '{print $2}'))
    min_len=$(echo $(lssec -f /etc/security/user -s default -a minlen | ${awk_cmd} -F'=' '{print $2}'))
    warn_time=$(echo $(lssec -f /etc/security/user -s default -a pwdwarntime | ${awk_cmd} -F'=' '{print $2}'))
    retries=$(echo $(lssec -f /etc/security/user -s default -a loginretries | ${awk_cmd} -F'=' '{print $2}'))
    AIX_histexpire=$(echo $(lssec -f /etc/security/user -s default -a histexpire | ${awk_cmd} -F'=' '{print $2}'))
    AIX_minother=$(echo $(lssec -f /etc/security/user -s default -a minother | ${awk_cmd} -F'=' '{print $2}'))
    AIX_minalpha=$(echo $(lssec -f /etc/security/user -s default -a minalpha | ${awk_cmd} -F'=' '{print $2}'))
    AIX_mindiff=$(echo $(lssec -f /etc/security/user -s default -a mindiff | ${awk_cmd} -F'=' '{print $2}'))
    AIX_mindigit=$(echo $(lssec -f /etc/security/user -s default -a mindigit | ${awk_cmd} -F'=' '{print $2}'))
    AIX_minupperalpha=$(echo $(lssec -f /etc/security/user -s default -a minupperalpha | ${awk_cmd} -F'=' '{print $2}'))
    AIX_minloweralpha=$(echo $(lssec -f /etc/security/user -s default -a minloweralpha | ${awk_cmd} -F'=' '{print $2}'))
    AIX_dictionlist=$(echo $(lssec -f /etc/security/user -s default -a dictionlist | ${awk_cmd} -F'=' '{print $2}'))

    AIX_pwd_algo_info=$(echo $(cat /etc/security/login.cfg | ${grep_cmd} -v "^ *\*" | ${grep_cmd} pwd_algorithm | ${grep_cmd} = | ${awk_cmd} -F'=' '{print $2}'))
    AIX_logininterval=$(echo $(cat /etc/security/login.cfg | ${grep_cmd} -v "^ *\*" | ${grep_cmd} logininterval  | ${grep_cmd} = | ${awk_cmd} -F'=' '{print $2}'))
    AIX_loginreenable=$(echo $(cat /etc/security/login.cfg | ${grep_cmd} -v "^ *\*" | ${grep_cmd} loginreenable  | ${grep_cmd} = | ${awk_cmd} -F'=' '{print $2}'))
    AIX_logindisable=$(echo $(cat /etc/security/login.cfg | ${grep_cmd} -v "^ *\*" | ${grep_cmd} logindisable  | ${grep_cmd} = | ${awk_cmd} -F'=' '{print $2}'))
    AIX_logintimeout=$(echo $(cat /etc/security/login.cfg | ${grep_cmd} -v "^ *\*" | ${grep_cmd} logintimeout  | ${grep_cmd} = | ${awk_cmd} -F'=' '{print $2}'))
    AIX_logindelay=$(echo $(cat /etc/security/login.cfg | ${grep_cmd} -v "^ *\*" | ${grep_cmd} logindelay  | ${grep_cmd} = | ${awk_cmd} -F'=' '{print $2}'))
    AIX_tmout=$(echo $(cat /etc/profile | ${grep_cmd} -v "^ *#" | ${grep_cmd} TMOUT  | ${grep_cmd} = | ${awk_cmd} -F'[=;&]' '{print $2}' | ${awk_cmd} '{print $1}'))
    AIX_auditstart=$(echo $(cat /etc/inittab | ${grep_cmd} -v "^ *#" | ${grep_cmd} -v "^ *:" | ${grep_cmd} -e "audit:2:once:/home/SCOMUser/scom/audit.sh" -e "audit:2:once:/usr/sbin/audit start 1>&- 2>&-"))
    if [ -z "${AIX_auditstart}" ]; then
      AIX_auditstart=$(echo false)
    else
      AIX_auditstart=$(echo true)
    fi
    AIX_auditshutdown=$(echo $(cat /etc/rc.shutdown | ${grep_cmd} -v "^ *#" | ${grep_cmd} /usr/sbin/audit | ${awk_cmd} -F' ' '{print $2}'))
    AIX_ignorerhosts=$(echo $(cat /etc/ssh/sshd_config | ${grep_cmd} -v "^ *#" | ${grep_cmd} IgnoreRhosts | ${awk_cmd} -F' ' '{print $2}'))
    AIX_binmode=$(echo $(cat /etc/security/audit/config | ${grep_cmd} binmode | ${awk_cmd} -F'=' '{print $2}'),$(cat /etc/security/audit/config | ${grep_cmd} streammode | ${awk_cmd} -F'=' '{print $2}'))
    guest_user=$(cat /etc/passwd | ${grep_cmd} -v "^ *#" | ${awk_cmd} -F':' '{print $1}' | ${grep_cmd} "guest")
    if [ -z "${guest_user}" ]; then
      AIX_guest_account_locked=$(echo true)
    else
      AIX_guest_account_locked=$(echo $(lssec -f /etc/security/user -s guest -a account_locked | ${awk_cmd} -F'=' '{print $2}'))
    fi
    AIX_ip_forward=$(echo $(no -a | ${grep_cmd} ipforwarding | ${awk_cmd} -F'= ' '{print $2}'))
    AIX_send_redirects=$(echo $(no -a | ${grep_cmd} ipsendredirects | ${awk_cmd} -F'= ' '{print $2}'))
    AIX_guest_login=$(echo $(lssec -f /etc/security/user -s guest -a login | ${awk_cmd} -F'=' '{print $2}'))
    AIX_guest_rlogin=$(echo $(lssec -f /etc/security/user -s guest -a rlogin | ${awk_cmd} -F'=' '{print $2}'))
    AIX_guest=$(echo $AIX_guest_account_locked,$AIX_guest_login,$AIX_guest_rlogin)
    umask=$(echo $(lssec -f /etc/security/user -s default -a umask | ${awk_cmd} -F'=' '{print $2}'))
    if [ ${#umask} = 1 ]; then
    umask=$(echo 00${umask})
    elif [ ${#umask} = 2 ]; then
    umask=$(echo 0${umask})
    fi
    root_pw_expired=$(echo $(lssec -f /etc/security/user -s root -a maxage | ${awk_cmd} -F'=' '{print $2}'))
    if [ -z "${root_pw_expired}" ]; then
      root_pw_expired=${max_days}
    fi
    root_pw_inactive=$(echo $(lssec -f /etc/security/user -s root -a account_locked | ${awk_cmd} -F':' '{print $2}'))
    if [ -z "${root_pw_inactive}" ]; then
      root_pw_inactive=$(echo $(lssec -f /etc/security/user -s default -a account_locked | ${awk_cmd} -F':' '{print $2}'))
    fi
    root_acc_expired=$(echo $(lssec -f /etc/security/user -s root -a expires | ${awk_cmd} -F'=' '{print $2}'))
    if [ -z "${root_acc_expired}" ]; then
      root_acc_expired=$(echo $(lssec -f /etc/security/user -s default -a expires | ${awk_cmd} -F'=' '{print $2}'))
    fi
    superuser_list=$(cat /etc/passwd | ${grep_cmd} -v "^ *#" | ${awk_cmd} -F':' '{print $1","$3}' | ${grep_cmd} ",0" | ${awk_cmd} -F',' '{print $1}')
    superuser=$(echo "${superuser_list}" | ${awk_cmd} '{print}' ORS=',' | sed '$s/.$//')
    NonAuditSuperuser=''
      for usr_name in ${superuser_list}
      do
        audit_tmp=$(echo $(cat /etc/security/audit/config | ${grep_cmd} "${usr_name} ="))
        if [ -z "${audit_tmp}" ]; then
          NonAuditSuperuser=$(echo ${NonAuditSuperuser},${usr_name})
        fi
      done
    if [ -z "${NonAuditSuperuser}"  ]; then
      NonAuditSuperuser=$(echo true)
    else 
      NonAuditSuperuser=$(echo ${NonAuditSuperuser} | sed 's/^.//')
    fi
  elif [ -f "${rel_osol}" ]; then
    max_histories=$(echo $(cat /etc/default/passwd | ${grep_cmd} -v "^ *#" | ${grep_cmd} HISTORY | ${awk_cmd} -F'=' '{print $2}'))
    max_days=$(echo $(cat /etc/default/passwd | ${grep_cmd} -v "^ *#" | ${grep_cmd} MAXWEEKS | ${awk_cmd} -F'=' '{print $2}'))
    min_days=$(echo $(cat /etc/default/passwd | ${grep_cmd} -v "^ *#" | ${grep_cmd} MINWEEKS | ${awk_cmd} -F'=' '{print $2}'))
    min_len=$(echo $(cat /etc/default/passwd | ${grep_cmd} -v "^ *#" | ${grep_cmd} PASSLENGTH | ${awk_cmd} -F'=' '{print $2}'))
    warn_time=$(echo $(cat /etc/default/passwd | ${grep_cmd} -v "^ *#" | ${grep_cmd} WARNWEEKS | ${awk_cmd} -F'=' '{print $2}'))
    min_diff=$(echo $(cat /etc/default/passwd | ${grep_cmd} -v "^ *#" | ${grep_cmd} MINDIFF | ${awk_cmd} -F'=' '{print $2}'))
    min_alpha=$(echo $(cat /etc/default/passwd | ${grep_cmd} -v "^ *#" | ${grep_cmd} MINALPHA | ${awk_cmd} -F'=' '{print $2}'))
    min_digit=$(echo $(cat /etc/default/passwd | ${grep_cmd} -v "^ *#" | ${grep_cmd} MINDIGIT | ${awk_cmd} -F'=' '{print $2}'))
    min_upper=$(echo $(cat /etc/default/passwd | ${grep_cmd} -v "^ *#" | ${grep_cmd} MINUPPER | ${awk_cmd} -F'=' '{print $2}'))
    min_lower=$(echo $(cat /etc/default/passwd | ${grep_cmd} -v "^ *#" | ${grep_cmd} MINLOWER | ${awk_cmd} -F'=' '{print $2}'))
    retries=$(echo $(cat /etc/default/login | ${grep_cmd} -v "^ *#" | ${grep_cmd} RETRIES | ${awk_cmd} -F'=' '{print $2}'))
    umask_ALL=$(cat /etc/profile | ${grep_cmd} -v "^ *#" | ${grep_cmd} umask | ${awk_cmd} -F' ' '{print $2}')
    umask_uniq=$(echo $(echo "${umask_ALL}" | sort | uniq))
    if [ ${#umask_uniq} -eq 3 ]; then
    umask=${umask_uniq}
    else
    umask=$(echo ${umask_ALL})
    fi

    root_pw_expired=$(echo $(cat /etc/shadow | ${grep_cmd} -v "^ *#" | ${grep_cmd} root | ${awk_cmd} -F':' '{print $5}'))
    if [ -z "${root_pw_expired}" ]; then
      root_pw_expired=${max_days}
    fi
    root_pw_inactive=$(echo $(cat /etc/shadow | ${grep_cmd} -v "^ *#" | ${grep_cmd} root | ${awk_cmd} -F':' '{print $7}'))
    root_acc_expired=$(echo $(cat /etc/shadow | ${grep_cmd} -v "^ *#" | ${grep_cmd} root | ${awk_cmd} -F':' '{print $8}'))
    superuser_list=$(cat /etc/passwd | ${grep_cmd} -v "^ *#" | ${awk_cmd} -F':' '{print $1","$3}' | ${grep_cmd} ",0" | ${awk_cmd} -F',' '{print $1}')
    superuser=$(echo $(echo "${superuser_list}" | ${awk_cmd} 'BEGIN{ORS=","}1') | sed '$s/.$//')

    Solaris_min_nonalpha=$(echo $(cat /etc/default/passwd | ${grep_cmd} -v "^ *#" | ${grep_cmd} MINNONALPHA | ${awk_cmd} -F'=' '{print $2}'))
    Solaris_dictionlist=$(echo $(cat /etc/default/passwd | ${grep_cmd} -v "^ *#" | ${grep_cmd} DICTIONLIST | ${awk_cmd} -F'=' '{print $2}'))
    Solaris_pwd_algo_info=$(echo $(cat /etc/security/policy.conf | ${grep_cmd} -v "^ *#" | ${grep_cmd} CRYPT_DEFAULT | ${awk_cmd} -F'=' '{print $2}'))
    Solaris_disabletime=$(echo $(cat /etc/default/login | ${grep_cmd} -v "^ *#" | ${grep_cmd} DISABLETIME | ${awk_cmd} -F'=' '{print $2}'))
    Solaris_logingracetime=$(echo $(cat /etc/ssh/sshd_config | ${grep_cmd} -v "^ *#" | ${grep_cmd} LoginGraceTime | ${awk_cmd} -F' ' '{print $2}'))
    Solaris_sleeptime=$(echo $(cat /etc/default/login | ${grep_cmd} -v "^ *#" | ${grep_cmd} SLEEPTIME | ${awk_cmd} -F'=' '{print $2}'))
    Solaris_clientaliveinterval=$(echo $(cat /etc/ssh/sshd_config | ${grep_cmd} -v "^ *#" | ${grep_cmd} ClientAliveInterval | ${awk_cmd} -F' ' '{print $2}'))
    Solaris_ignorerhosts=$(echo $(cat /etc/ssh/sshd_config | ${grep_cmd} -v "^ *#" | ${grep_cmd} IgnoreRhosts | ${awk_cmd} -F' ' '{print $2}'))
    Solaris_forward_src_routed=$(echo $(ipadm show-prop -p _forward_src_routed ipv4 | ${grep_cmd} _forward_src_routed | ${awk_cmd} -F' ' '{print $4}'))
    if [ -z "${Solaris_forward_src_routed}" ]; then
      Solaris_forward_src_routed=$(echo $(ndd /dev/ip ip_forward_src_routed))
    fi
    Solaris_ignore_redirect=$(echo $(ipadm show-prop -p _ignore_redirect ipv4 | ${grep_cmd} _ignore_redirect | ${awk_cmd} -F' ' '{print $4}'))
    if [ -z "${Solaris_ignore_redirect}" ]; then
      Solaris_ignore_redirect=$(echo $(ndd /dev/ip ip_ignore_redirect))
    fi
    Solaris_redirects=$(echo $(ipadm show-prop -p send-redirects ipv4 | ${grep_cmd} send-redirects | ${awk_cmd} -F' ' '{print $4}'))
    if [ -z "${Solaris_redirects}" ] || [ "${Solaris_redirects}" = "?" ] || [ "${Solaris_redirects}" = "y" ]; then
      Solaris_redirects=$(echo $(ipadm show-prop -p send_redirects ipv4 | ${grep_cmd} send_redirects | ${awk_cmd} -F' ' '{print $4}'))
    fi
    if [ -z "${Solaris_redirects}" ] || [ "${Solaris_redirects}" = "?" ] || [ "${Solaris_redirects}" = "y" ]; then
      Solaris_redirects=$(echo $(ndd /dev/ip ip_send_redirects))
    fi
    Solaris_send_redirects=$(echo ${Solaris_ignore_redirect},${Solaris_redirects})
  elif [ -f "${rel_suse}" ]; then
    max_histories=$(echo $(cat /etc/pam.d/common-password | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "remember=[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    max_histories_is_duplicate=$(echo $(echo ${max_histories} | tr ' ' '\n' | ${grep_cmd} -v '^$' | sort | uniq -c | sort -k1,1nr)| ${awk_cmd} -F' ' '{print $3}')
    if [ -z "${max_histories_is_duplicate}" ]; then
      max_histories=$(echo ${max_histories} | ${awk_cmd} -F' ' '{print $1}')
    fi
    max_days=$(echo $(cat /etc/login.defs | ${grep_cmd} -v "^\s*#" | ${grep_cmd} PASS_MAX_DAYS | ${awk_cmd} -F' ' '{print $2}'))
    min_days=$(echo $(cat /etc/login.defs | ${grep_cmd} -v "^\s*#" | ${grep_cmd} PASS_MIN_DAYS | ${awk_cmd} -F' ' '{print $2}'))
    min_len=$(echo $(cat /etc/pam.d/common-password | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "minlen=[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    if [ -z "${min_len}" ]; then
      min_len=$(echo $(cat /etc/security/pwquality.conf | ${grep_cmd} "^\s*minlen" | ${grep_cmd} -o "minlen=[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    fi
    if [ -z "${min_len}" ]; then
      min_len=$(echo $(cat /etc/login.defs | ${grep_cmd} -v "^\s*#" | ${grep_cmd} PASS_MIN_LEN | ${awk_cmd} -F' ' '{print $2}'))
    fi
    warn_time=$(echo $(cat /etc/login.defs | ${grep_cmd} -v "^\s*#" | ${grep_cmd} PASS_WARN_AGE | ${awk_cmd} -F' ' '{print $2}'))
    retries=$(echo $(cat /etc/pam.d/common-password | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "retry=[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    retries_is_duplicate=$(echo $(echo ${retries} | tr ' ' '\n' | ${grep_cmd} -v '^$' | sort | uniq -c | sort -k1,1nr)| ${awk_cmd} -F' ' '{print $3}')
    if [ -z "${retries_is_duplicate}" ]; then
      retries=$(echo ${retries} | ${awk_cmd} -F' ' '{print $1}')
    fi
    umask_ALL=$(cat /etc/login.defs | ${grep_cmd} -v "^ *#" | ${grep_cmd} UMASK | ${awk_cmd} -F' ' '{print $2}')
    if [ -z "${umask_ALL}" ]; then
      umask_ALL=$(cat /etc/profile | ${grep_cmd} -v "^ *#" | ${grep_cmd} umask | ${awk_cmd} -F' ' '{print $2}')
    fi
    umask_uniq=$(echo $(echo "${umask_ALL}" | sort | uniq))
    if [ ${#umask_uniq} -eq 3 ]; then
    umask=${umask_uniq}
    else
    umask=$(echo ${umask_ALL})
    fi

    root_pw_expired=$(echo $(cat /etc/shadow | ${grep_cmd} -v "^\s*#" | ${grep_cmd} root | ${awk_cmd} -F':' '{print $5}'))
    root_pw_inactive=$(echo $(cat /etc/shadow | ${grep_cmd} -v "^\s*#" | ${grep_cmd} root | ${awk_cmd} -F':' '{print $7}'))
    root_acc_expired=$(echo $(cat /etc/shadow | ${grep_cmd} -v "^\s*#" | ${grep_cmd} root | ${awk_cmd} -F':' '{print $8}'))
    superuser_list=$(cat /etc/passwd | ${grep_cmd} -v "^ *#" | ${awk_cmd} -F':' '{print $1","$3}' | ${grep_cmd} ",0" | ${awk_cmd} -F',' '{print $1}')
    superuser=$(echo "${superuser_list}" | ${awk_cmd} '{print}' ORS=',' | sed '$s/.$//')

    SUSE_dcredit=$(echo $(cat /etc/pam.d/common-password | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "dcredit=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    SUSE_ucredit=$(echo $(cat /etc/pam.d/common-password | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "ucredit=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    SUSE_lcredit=$(echo $(cat /etc/pam.d/common-password | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "lcredit=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    SUSE_difok=$(echo $(cat /etc/pam.d/common-password | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "difok=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    SUSE_dictpath=$(echo $(cat /etc/security/pwquality.conf | ${grep_cmd} -v "^\s*#" | ${grep_cmd} dictpath | ${awk_cmd} -F'=' '{print $2}'))
    SUSE_pwd_algo_info=$(echo $(cat /etc/login.defs | ${grep_cmd} -v "^\s*#" | ${grep_cmd} "ENCRYPT_METHOD " | ${awk_cmd} -F' ' '{print $2}'))
    SUSE_fail_interval=$(echo $(cat /etc/pam.d/common-auth | ${grep_cmd} "^\s*auth" | ${grep_cmd} -o "fail_interval=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    SUSE_deny=$(echo $(cat /etc/pam.d/common-auth | ${grep_cmd} "^\s*auth" | ${grep_cmd} -o "deny=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    SUSE_unlock_time=$(echo $(cat /etc/pam.d/common-auth | ${grep_cmd} "^\s*auth" | ${grep_cmd} -o "unlock_time=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    SUSE_LOGIN_TIMEOUT=$(echo $(cat /etc/login.defs | ${grep_cmd} -v "^\s*#" | ${grep_cmd} "LOGIN_TIMEOUT" | ${awk_cmd} -F' ' '{print $2}'))
    SUSE_delay=$(echo $(cat /etc/login.defs | ${grep_cmd} -v "^\s*#" | ${grep_cmd} "FAIL_DELAY" | ${awk_cmd} -F' ' '{print $2}'))
    SUSE_tmout=$(echo $(cat /etc/ssh/sshd_config | ${grep_cmd} -v "^\s*#" | ${grep_cmd} "ClientAliveInterval" | ${awk_cmd} -F' ' '{print $2}'))
    SUSE_ignorerhosts=$(echo $(cat /etc/ssh/sshd_config | ${grep_cmd} -v "^\s*#" | ${grep_cmd} "IgnoreRhosts" | ${awk_cmd} -F' ' '{print $2}'))
    SUSE_martians=$(echo $(cat /proc/sys/net/ipv4/conf/all/log_martians))
    SUSE_ip_forward=$(echo $(cat /proc/sys/net/ipv4/ip_forward))
    SUSE_send_redirects=$(echo $(cat /proc/sys/net/ipv4/conf/default/send_redirects))
  else
    max_histories=$(echo $(cat /etc/pam.d/system-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "remember=[0-9]*" | ${awk_cmd} -F'=' '{print $2}' ))
    if [ -z "${max_histories}" ]; then
      max_histories=$(echo $(cat /etc/pam.d/password-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "remember=[0-9]*" | ${awk_cmd} -F'=' '{print $2}' ))
    fi
    max_days=$(echo $(cat /etc/login.defs | ${grep_cmd} -v "^\s*#" | ${grep_cmd} PASS_MAX_DAYS | ${awk_cmd} -F' ' '{print $2}'))
    min_days=$(echo $(cat /etc/login.defs | ${grep_cmd} -v "^\s*#" | ${grep_cmd} PASS_MIN_DAYS | ${awk_cmd} -F' ' '{print $2}'))
    min_len=$(echo $(cat /etc/pam.d/system-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "minlen=[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    if [ -z "${min_len}" ]; then
      min_len=$(echo $(cat /etc/security/pwquality.conf | ${grep_cmd} "^\s*minlen" | ${grep_cmd} -o "minlen=[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    fi
    if [ -z "${min_len}" ]; then
      min_len=$(echo $(cat /etc/pam.d/password-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "minlen=[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    fi
    if [ -z "${min_len}" ]; then
      min_len=$(echo $(cat /etc/login.defs | ${grep_cmd} -v "^\s*#" | ${grep_cmd} PASS_MIN_LEN | ${awk_cmd} -F' ' '{print $2}'))
    fi
    warn_time=$(echo $(cat /etc/login.defs | ${grep_cmd} -v "^\s*#" | ${grep_cmd} PASS_WARN_AGE | ${awk_cmd} -F' ' '{print $2}'))
    retries=$(echo $(cat /etc/pam.d/system-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "retry=[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    if [ -z "${retries}" ]; then
      retries=$(echo $(cat /etc/pam.d/password-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "retry=[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    fi
    umask=$(echo $(cat /etc/bashrc | ${grep_cmd} -v "^ *#" | ${grep_cmd} umask | ${awk_cmd} -F' ' '{print $2}'))
    
    dcredit=$(echo $(cat /etc/pam.d/system-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "dcredit=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    if [ -z "${dcredit}" ]; then
      dcredit=$(echo $(cat /etc/pam.d/password-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "dcredit=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}' ))
    fi
    ucredit=$(echo $(cat /etc/pam.d/system-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "ucredit=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    if [ -z "${ucredit}" ]; then
      ucredit=$(echo $(cat /etc/pam.d/password-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "ucredit=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}' ))
    fi
    lcredit=$(echo $(cat /etc/pam.d/system-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "lcredit=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    if [ -z "${lcredit}" ]; then
      lcredit=$(echo $(cat /etc/pam.d/password-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "lcredit=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}' ))
    fi
    martians=$(echo $(cat /etc/sysctl.conf | ${grep_cmd} -v "^ *#" | ${grep_cmd}  net.ipv4.conf.all.log_martians | ${awk_cmd} -F'=' '{print $2}'))
    ip_forward=$(echo $(cat /etc/sysctl.conf | ${grep_cmd} -v "^ *#" | ${grep_cmd}  net.ipv4.ip_forward | ${awk_cmd} -F'=' '{print $2}'))
    send_redirects=$(echo $(cat /etc/sysctl.conf | ${grep_cmd} -v "^ *#" | ${grep_cmd}  net.ipv4.conf.default.send_redirects | ${awk_cmd} -F'=' '{print $2}'))
    
    root_pw_expired=$(echo $(cat /etc/shadow | ${grep_cmd} -v "^\s*#" | ${grep_cmd} root | ${awk_cmd} -F':' '{print $5}'))
    root_pw_inactive=$(echo $(cat /etc/shadow | ${grep_cmd} -v "^\s*#" | ${grep_cmd} root | ${awk_cmd} -F':' '{print $7}'))
    root_acc_expired=$(echo $(cat /etc/shadow | ${grep_cmd} -v "^\s*#" | ${grep_cmd} root | ${awk_cmd} -F':' '{print $8}'))
    superuser_list=$(cat /etc/passwd | ${grep_cmd} -v "^ *#" | ${awk_cmd} -F':' '{print $1","$3}' | ${grep_cmd} ",0" | ${awk_cmd} -F',' '{print $1}')
    superuser=$(echo "${superuser_list}" | ${awk_cmd} '{print}' ORS=',' | sed '$s/.$//')

    Linux_difok=$(echo $(cat /etc/pam.d/system-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "difok=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    if [ -z "${Linux_difok}" ]; then
      Linux_difok=$(echo $(cat /etc/pam.d/password-auth | ${grep_cmd} "^\s*password" | ${grep_cmd} -o "difok=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}' ))
    fi
    
    Linux_fail_interval=$(echo $(cat /etc/pam.d/system-auth | ${grep_cmd} "^\s*auth" | ${grep_cmd} -o "fail_interval=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    if [ -z "${Linux_fail_interval}" ]; then
      Linux_fail_interval=$(echo $(cat /etc/pam.d/password-auth | ${grep_cmd} "^\s*auth" | ${grep_cmd} -o "fail_interval=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}' ))
    fi
    Linux_fail_interval_is_duplicate=$(echo $(echo ${Linux_fail_interval} | tr ' ' '\n' | ${grep_cmd} -v '^$' | sort | uniq -c | sort -k1,1nr)| ${awk_cmd} -F' ' '{print $3}')
    if [ -z "${Linux_fail_interval_is_duplicate}" ]; then
      Linux_fail_interval=$(echo ${Linux_fail_interval} | ${awk_cmd} -F' ' '{print $1}')
    fi
    
    Linux_deny=$(echo $(cat /etc/pam.d/system-auth | ${grep_cmd} "^\s*auth" | ${grep_cmd} -o "deny=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    if [ -z "${Linux_deny}" ]; then
      Linux_deny=$(echo $(cat /etc/pam.d/password-auth | ${grep_cmd} "^\s*auth" | ${grep_cmd} -o "deny=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}' ))
    fi
    Linux_deny_is_duplicate=$(echo $(echo ${Linux_deny} | tr ' ' '\n' | ${grep_cmd} -v '^$' | sort | uniq -c | sort -k1,1nr)| ${awk_cmd} -F' ' '{print $3}')
    if [ -z "${Linux_deny_is_duplicate}" ]; then
      Linux_deny=$(echo ${Linux_deny} | ${awk_cmd} -F' ' '{print $1}')
    fi
    
    Linux_unlock_time=$(echo $(cat /etc/pam.d/system-auth | ${grep_cmd} "^\s*auth" | ${grep_cmd} -o "unlock_time=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    if [ -z "${Linux_unlock_time}" ]; then
      Linux_unlock_time=$(echo $(cat /etc/pam.d/password-auth | ${grep_cmd} "^\s*auth" | ${grep_cmd} -o "unlock_time=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}' ))
    fi
    Linux_unlock_time_is_duplicate=$(echo $(echo ${Linux_unlock_time} | tr ' ' '\n' | ${grep_cmd} -v '^$' | sort | uniq -c | sort -k1,1nr)| ${awk_cmd} -F' ' '{print $3}')
    if [ -z "${Linux_unlock_time_is_duplicate}" ]; then
      Linux_unlock_time=$(echo ${Linux_unlock_time} | ${awk_cmd} -F' ' '{print $1}')
    fi
    
    Linux_delay=$(echo $(cat /etc/pam.d/system-auth | ${grep_cmd} "^\s*auth" | ${grep_cmd} -o "delay=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}'))
    if [ -z "${Linux_delay}" ]; then
      Linux_delay=$(echo $(cat /etc/pam.d/password-auth | ${grep_cmd} "^\s*auth" | ${grep_cmd} -o "delay=.[0-9]*" | ${awk_cmd} -F'=' '{print $2}' ))
    fi
    Linux_dictpath=$(echo $(cat /etc/security/pwquality.conf | ${grep_cmd} -v "^\s*#" | ${grep_cmd} dictpath | ${awk_cmd} -F'=' '{print $2}'))
    Linux_pwd_algo_info=$(echo $(cat /etc/login.defs | ${grep_cmd} -v "^\s*#" | ${grep_cmd} ENCRYPT_METHOD | ${awk_cmd} -F' ' '{print $2}'))
    Linux_ServerAliveInterval=$(echo $(cat /etc/ssh/ssh_config | ${grep_cmd} -v "^\s*#" | ${grep_cmd} ServerAliveInterval | ${awk_cmd} -F' ' '{print $2}'))
    Linux_tmout=$(echo $(cat /etc/ssh/sshd_config | ${grep_cmd} -v "^\s*#" | ${grep_cmd} ClientAliveInterval | ${awk_cmd} -F' ' '{print $2}'))
    Linux_ignorerhosts=$(echo $(cat /etc/ssh/sshd_config | ${grep_cmd} -v "^\s*#" | ${grep_cmd} IgnoreRhosts | ${awk_cmd} -F' ' '{print $2}'))
  fi
  if [ -z "${root_pw_expired}" ]; then
    root_pw_expired="never"
  fi
  if [ -z "${root_pw_inactive}" ]; then
    root_pw_inactive="never"
  fi
  if [ -z "${root_acc_expired}" ]; then
    root_acc_expired="never"
  fi
  printf "  <Policies>\n"
  printf "    <Policy type='root' name='PasswdExpired' value='${root_pw_expired}'></Policy>\n"
  printf "    <Policy type='root' name='PasswdInactive' value='${root_pw_inactive}'></Policy>\n"
  printf "    <Policy type='root' name='AccountExpired' value='${root_acc_expired}'></Policy>\n"
  if [ "${os}" = "${os_aix}" ]; then
    printf "    <Policy type='important' name='AIX_MaxHistories' value='${max_histories}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_MaxWeeks' value='${max_days}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_MinWeeks' value='${min_days}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_MinLength' value='${min_len}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_WarnTime' value='${warn_time}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_retries' value='${retries}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_histexpire' value='${AIX_histexpire}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_minother' value='${AIX_minother}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_minalpha' value='${AIX_minalpha}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_mindigit' value='${AIX_mindigit}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_minupperalpha' value='${AIX_minupperalpha}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_minloweralpha' value='${AIX_minloweralpha}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_mindiff' value='${AIX_mindiff}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_dictionlist' value='${AIX_dictionlist}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_pwd_algo_info' value='${AIX_pwd_algo_info}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_umask' value='${umask}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_logininterval' value='${AIX_logininterval}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_logindisable' value='${AIX_logindisable}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_loginreenable' value='${AIX_loginreenable}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_logintimeout' value='${AIX_logintimeout}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_logindelay' value='${AIX_logindelay}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_tmout' value='${AIX_tmout}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_auditstart' value='${AIX_auditstart}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_auditshutdown' value='${AIX_auditshutdown}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_ignorerhosts' value='${AIX_ignorerhosts}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_binmode' value='${AIX_binmode}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_ip_forward' value='${AIX_ip_forward}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_send_redirects' value='${AIX_send_redirects}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_superuser' value='${superuser}'></Policy>\n"
    printf "    <Policy type='important' name='AIX_NonAuditSuperuser' value='${NonAuditSuperuser}'></Policy>\n"
    printf "    <Policy type='guest' name='AIX_guest' value='${AIX_guest}'></Policy>\n"
  elif [ -f "${rel_osol}" ]; then
    printf "    <Policy type='important' name='Solaris_MaxHistories' value='${max_histories}'></Policy>\n"
    printf "    <Policy type='important' name='Solaris_MaxWeeks' value='${max_days}'></Policy>\n"
    printf "    <Policy type='important' name='Solaris_MinWeeks' value='${min_days}'></Policy>\n"
    printf "    <Policy type='important' name='Solaris_MinLength' value='${min_len}'></Policy>\n"
    printf "    <Policy type='important' name='Solaris_WarnTime' value='${warn_time}'></Policy>\n"
    printf "    <Policy type='important' name='Solaris_retries' value='${retries}'></Policy>\n"
    printf "    <Policy type='important' name='Solaris_min_nonalpha' value='${Solaris_min_nonalpha}'></Policy>\n"
    printf "    <Policy type='important' name='Solaris_min_alpha' value='${min_alpha}'></Policy>\n"
#    printf "    <Policy type='important' name='Solaris_min_digit' value='${min_digit}'></Policy>\n"
    printf "    <Policy type='important' name='Solaris_min_upper' value='${min_upper}'></Policy>\n"
    printf "    <Policy type='important' name='Solaris_min_lower' value='${min_lower}'></Policy>\n"
    printf "    <Policy type='important' name='Solaris_min_diff' value='${min_diff}'></Policy>\n"
    printf "    <Policy type='important' name='Solaris_dictionlist' value='${Solaris_dictionlist}'></Policy>\n"
    printf "    <Policy type='important' name='Solaris_pwd_algo_info' value='${Solaris_pwd_algo_info}'></Policy>\n"
    printf "    <Policy type='important' name='Solaris_umask' value='${umask}'></Policy>\n"
    printf "    <Policy type='important' name='Solaris_disabletime' value='${Solaris_disabletime}'></Policy>\n"
    printf "    <Policy type='important' name='Solaris_logingracetime' value='${Solaris_logingracetime}'></Policy>\n"
    printf "    <Policy type='important' name='Solaris_sleeptime' value='${Solaris_sleeptime}'></Policy>\n"
    printf "    <Policy type='important' name='Solaris_clientaliveinterval' value='${Solaris_clientaliveinterval}'></Policy>\n"
    printf "    <Policy type='important' name='Solaris_ignorerhosts' value='${Solaris_ignorerhosts}'></Policy>\n"
    printf "    <Policy type='important' name='Solaris_forward_src_routed' value='${Solaris_forward_src_routed}'></Policy>\n"
    printf "    <Policy type='important' name='Solaris_send_redirects' value='${Solaris_send_redirects}'></Policy>\n"
    printf "    <Policy type='important' name='Solaris_superuser' value='${superuser}'></Policy>\n"
  elif [ -f "${rel_suse}" ]; then
    printf "    <Policy type='important' name='SUSE_MaxHistories' value='${max_histories}'></Policy>\n"
    printf "    <Policy type='important' name='SUSE_MaxDays' value='${max_days}'></Policy>\n"
    printf "    <Policy type='important' name='SUSE_MinDays' value='${min_days}'></Policy>\n"
    printf "    <Policy type='important' name='SUSE_MinLength' value='${min_len}'></Policy>\n"
    printf "    <Policy type='important' name='SUSE_WarnTime' value='${warn_time}'></Policy>\n"
    printf "    <Policy type='important' name='SUSE_retries' value='${retries}'></Policy>\n"
    printf "    <Policy type='important' name='SUSE_dcredit' value='${SUSE_dcredit}'></Policy>\n"
    printf "    <Policy type='important' name='SUSE_ucredit' value='${SUSE_ucredit}'></Policy>\n"
    printf "    <Policy type='important' name='SUSE_lcredit' value='${SUSE_lcredit}'></Policy>\n"
    printf "    <Policy type='important' name='SUSE_difok' value='${SUSE_difok}'></Policy>\n"
    printf "    <Policy type='important' name='SUSE_dictpath' value='${SUSE_dictpath}'></Policy>\n"
    printf "    <Policy type='important' name='SUSE_pwd_algo_info' value='${SUSE_pwd_algo_info}'></Policy>\n"
    printf "    <Policy type='important' name='SUSE_umask' value='${umask}'></Policy>\n"
    printf "    <Policy type='important' name='SUSE_fail_interval' value='${SUSE_fail_interval}'></Policy>\n"
    printf "    <Policy type='important' name='SUSE_deny' value='${SUSE_deny}'></Policy>\n"
    printf "    <Policy type='important' name='SUSE_unlock_time' value='${SUSE_unlock_time}'></Policy>\n"
    printf "    <Policy type='important' name='SUSE_LOGIN_TIMEOUT' value='${SUSE_LOGIN_TIMEOUT}'></Policy>\n"
    printf "    <Policy type='important' name='SUSE_delay' value='${SUSE_delay}'></Policy>\n"
    printf "    <Policy type='important' name='SUSE_tmout' value='${SUSE_tmout}'></Policy>\n"
    printf "    <Policy type='important' name='SUSE_ignorerhosts' value='${SUSE_ignorerhosts}'></Policy>\n"
    printf "    <Policy type='important' name='SUSE_martians' value='${SUSE_martians}'></Policy>\n"
    printf "    <Policy type='important' name='SUSE_ip_forward' value='${SUSE_ip_forward}'></Policy>\n"
    printf "    <Policy type='important' name='SUSE_send_redirects' value='${SUSE_send_redirects}'></Policy>\n"
    printf "    <Policy type='important' name='SUSE_superuser' value='${superuser}'></Policy>\n"
  else
    printf "    <Policy type='important' name='Linux_MaxHistories' value='${max_histories}'></Policy>\n"
    printf "    <Policy type='important' name='Linux_MaxDays' value='${max_days}'></Policy>\n"
    printf "    <Policy type='important' name='Linux_MinDays' value='${min_days}'></Policy>\n"
    printf "    <Policy type='important' name='Linux_MinLength' value='${min_len}'></Policy>\n"
    printf "    <Policy type='important' name='Linux_WarnTime' value='${warn_time}'></Policy>\n"
    printf "    <Policy type='important' name='Linux_retries' value='${retries}'></Policy>\n"
    printf "    <Policy type='important' name='Linux_dcredit' value='${dcredit}'></Policy>\n"
    printf "    <Policy type='important' name='Linux_ucredit' value='${ucredit}'></Policy>\n"
    printf "    <Policy type='important' name='Linux_lcredit' value='${lcredit}'></Policy>\n"
    printf "    <Policy type='important' name='Linux_difok' value='${Linux_difok}'></Policy>\n"
    printf "    <Policy type='important' name='Linux_dictpath' value='${Linux_dictpath}'></Policy>\n"
    printf "    <Policy type='important' name='Linux_pwd_algo_info' value='${Linux_pwd_algo_info}'></Policy>\n"
    printf "    <Policy type='important' name='Linux_umask' value='${umask}'></Policy>\n"
    printf "    <Policy type='important' name='Linux_fail_interval' value='${Linux_fail_interval}'></Policy>\n"
    printf "    <Policy type='important' name='Linux_deny' value='${Linux_deny}'></Policy>\n"
    printf "    <Policy type='important' name='Linux_unlock_time' value='${Linux_unlock_time}'></Policy>\n"
    printf "    <Policy type='important' name='Linux_ServerAliveInterval' value='${Linux_ServerAliveInterval}'></Policy>\n"
    printf "    <Policy type='important' name='Linux_delay' value='${Linux_delay}'></Policy>\n"
    printf "    <Policy type='important' name='Linux_tmout' value='${Linux_tmout}'></Policy>\n"
    printf "    <Policy type='important' name='Linux_ignorerhosts' value='${Linux_ignorerhosts}'></Policy>\n"
    printf "    <Policy type='important' name='Linux_martians' value='${martians}'></Policy>\n"
    printf "    <Policy type='important' name='Linux_ip_forward' value='${ip_forward}'></Policy>\n"
    printf "    <Policy type='important' name='Linux_send_redirects' value='${send_redirects}'></Policy>\n"
    printf "    <Policy type='important' name='Linux_superuser' value='${superuser}'></Policy>\n"
  fi
  printf "  </Policies>\n"
}
gen_usr_info(){
  printf "  <Users>\n"
  usr_list=$(cat /etc/passwd | ${awk_cmd} -F':' '{print $1}')
  for usr_name in ${usr_list}
  do
    usr_id=$(echo $(cat /etc/passwd | ${grep_cmd} "^${usr_name}:" | ${awk_cmd} -F':' '{print $3}'))
    usr_sh=$(echo $(cat /etc/passwd | ${grep_cmd} "^${usr_name}:" | ${awk_cmd} -F':' '{print $(NF)}'))
    if [ "${os}" = "${os_aix}" ]; then
      usr_grps=$(echo $(groups ${usr_name} | ${awk_cmd} -F": " '{print $2}'))
    else
      usr_grps=$(echo $(groups ${usr_name} | cut -d':' -f 2))
    fi
    printf "    <User name='${usr_name}' id='${usr_id}' sh='${usr_sh}' grps='${usr_grps}'></User>\n"
  done
  printf "  </Users>\n"
}
gen_grp_info(){
  printf "  <Groups>\n"
  grp_list=$(cat /etc/group | ${awk_cmd} -F':' '{print $1}')
  for grp_name in ${grp_list}
  do
    grp_id=$(echo $(cat /etc/group | ${grep_cmd} "^${grp_name}:" | ${awk_cmd} -F':' '{print $3}'))
    grp_usrs=$(echo $(cat /etc/group | ${grep_cmd} "^${grp_name}:" | ${awk_cmd} -F':' '{print $(NF)}') \
                    $(cat /etc/passwd | ${awk_cmd} -F':' '{print $1 ":" $4}' | ${grep_cmd} ":${grp_id}$" | cut -d':' -f 1) | sed 's/ /,/g')
    grp_usrs=$(echo $(echo ${grp_usrs} | tr ',' '\n' | sort | uniq ) | sed 's/ /,/g')
    printf "    <Group name='${grp_name}' id='${grp_id}' users='${grp_usrs}'></Group>\n"
  done
  printf "  </Groups>\n"
}
gen_root_access_info(){
  curr_dir=$(pwd)
  cd /
  printf "  <RootAccess>\n"
  files=$(ls -a)
  for fname in ${files}
  do
    name=$(echo ${fname} | sed 's/\./\\./g')
    finfo=$(ls -la / | ${grep_cmd} " ${name} ->")
    if [ -z "${finfo}" ]; then
      finfo=$(ls -la / | ${grep_cmd} " ${name}$")
    fi
    type=$(echo ${finfo} | ${awk_cmd} -F' ' '{print $1}' | cut -c1)
    if [ "${type}" = "d" ]; then
      type="Directory"
    elif [ "${type}" = "-" ]; then
      type="File"
    elif [ "${type}" = "b" ]; then
      type="Block"
    elif [ "${type}" = "s" ]; then
      type="Socket"
    elif [ "${type}" = "c" ]; then
      type="Character"
    elif [ "${type}" = "p" ]; then
      type="Pipe"
    elif [ "${type}" = "l" ]; then
      type="Link"
    fi
    access=$(echo ${finfo} | ${awk_cmd} -F' ' '{print $1}' | cut -c2-10)
    owner=$(echo ${finfo} | ${awk_cmd} -F' ' '{print $3}')
    printf "    <File name='${fname}' type='${type}' access='${access}' owner='${owner}'></File>\n"
  done
  printf "  </RootAccess>\n"
  cd ${curr_dir}
}
gen_webserv_info(){
  printf "  <WebServerInfo>\n"
  if [ -f "${httpd_ws}" ]; then
    find_indexes=$(cat ${httpd_ws} | ${grep_cmd} -v "^ *#" | ${grep_cmd} "^ *Options " | ${grep_cmd} " Indexes")
    if [ -z "${find_indexes}" ]; then
      find_indexes=N
    else
      find_indexes=Y
    fi
    printf "    <WebServer type='WebSphere' options='indexes' value='${find_indexes}' conf='${httpd_ws}'></WebServer>\n"
    find_indexes=
  fi
  
  if [ -f "${httpd_apache1}" ]; then
    find_indexes=$(cat ${httpd_apache1} | ${grep_cmd} -v "^ *#" | ${grep_cmd} "^ *Options " | ${grep_cmd} " Indexes")
    if [ -z "${find_indexes}" ]; then
      find_indexes=N
    else
      find_indexes=Y
    fi
    printf "    <WebServer type='Apache' options='indexes' value='${find_indexes}' conf='${httpd_apache1}'></WebServer>\n"
    find_indexes=
  fi
  
  if [ -f "${httpd_apache2}" ]; then
    find_indexes=$(cat ${httpd_apache2} | ${grep_cmd} -v "^ *#" | ${grep_cmd} "^ *Options " | ${grep_cmd} " Indexes")
    if [ -z "${find_indexes}" ]; then
      find_indexes=N
    else
      find_indexes=Y
    fi
    printf "    <WebServer type='Apache' options='indexes' value='${find_indexes}' conf='${httpd_apache2}'></WebServer>\n"
    find_indexes=
  fi
  
  if [ -f "${httpd_apache3}" ]; then
    find_indexes=$(cat ${httpd_apache3} | ${grep_cmd} -v "^ *#" | ${grep_cmd} "^ *Options " | ${grep_cmd} " Indexes")
    if [ -z "${find_indexes}" ]; then
      find_indexes=N
    else
      find_indexes=Y
    fi
    printf "    <WebServer type='Apache' options='indexes' value='${find_indexes}' conf='${httpd_apache2}'></WebServer>\n"
    find_indexes=
  fi
  printf "  </WebServerInfo>\n"
}
gen_xml_header(){
  printf "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n"
  printf "<root>\n"
}
gen_xml_tail(){
  printf "</root>\n"
}
create_system_info(){
  gen_xml_header
  gen_sys_info
  gen_disk_info
  gen_svc_info
  gen_schd_info
  gen_proc_info
  gen_syscfg_access_info
  gen_pkg_info
  gen_policies_info
  gen_usr_info
  gen_grp_info
  gen_root_access_info
  gen_webserv_info
  gen_xml_tail
}
create_system_info